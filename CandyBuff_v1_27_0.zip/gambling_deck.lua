-- Candy Buff: Gambling Deck (added in v1.26.8, stake-based since v1.26.9)
--
-- v1.26.10: a weaker "Shop Slot" with its own button in the shop (see the SHOP SLOT section).
-- Idea: after every Boss Blind a Slot Machine opens. YOU choose what to gamble:
--   * Cash            (a part of your money, or all of it)
--   * Interest cap    (the "$25" cap on interest, 5 / 10 / 25 of it)
--   * First hand X    (the X Mult this deck gives to your first hand each round)
--   * One of your Jokers (10 / 25 / 50 % of its values, Hot Potato style)
-- then you pull the lever. The 3 reels decide a multiplier from the paytable shown on screen
-- (3 Crowns = X10, 3 Sixes = X0.25 ...). The staked amount is multiplied by it:
--   new value = value - stake + stake * multiplier
--
-- How it hooks in (written from reading Steamodded / Cryptid / Multiplayer source; it could NOT be
-- run inside the game when this file was written, so test it and send the Lovely log):
--   * G.FUNCS.evaluate_round is wrapped (same pattern Cryptid, Talisman and Multiplayer use).
--     When a Boss was just beaten on this deck, the popup opens FIRST and the original
--     evaluate_round runs when the popup closes, so money and Interest-cap results count for
--     the cash-out screen that follows.
--   * G.FUNCS.exit_overlay_menu is wrapped so that ANY way of closing the popup still finishes
--     the round-eval (no soft-lock).
--   * Everything is inside pcall. If something fails, the log says "[CandyBuff] gambling" and
--     the game continues without the popup.
--   * The deck's own first-hand X Mult is NOT returned from Back.calculate any more. Returning it
--     made Steamodded fire a post_trigger context whose other_card was the Back object (it has no
--     .ability), and The Cracker Pack crashed on it (main.lua:646). It is now applied through
--     SMODS.calculate_effect on a real scoring card instead.

local MOD = SMODS.current_mod
local CFG = MOD.config or {}
MOD.config = CFG

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] gambling: ' .. msg, 'CandyBuff') end
end

-- ===================================================================
-- Tunables (edit here, or slot_fast in config.lua)
-- ===================================================================
if CFG.slot_fast == nil then CFG.slot_fast = false end            -- true = shorter spin
if CFG.shop_slot_enabled == nil then CFG.shop_slot_enabled = true end -- the shop button
if CFG.shop_slot_all_decks == nil then CFG.shop_slot_all_decks = false end -- false = Gambling Deck only
if CFG.shop_slot_style == nil then CFG.shop_slot_style = 'icon' end    -- 'icon' (floating, right of the shop) or 'column' (next to Reroll)
CFG.shop_slot_cost = math.max(1, math.floor(tonumber(CFG.shop_slot_cost) or 3))

local DECK_KEY = 'b_cbuf_gambling_deck'     -- class prefix 'b' + mod prefix 'cbuf' + 'gambling_deck'
local ATLAS_KEY = 'cbuf_slot_symbols'

-- THE PAYTABLE. frame = column in slot_symbols.png (row 0 sharp, row 1 motion-blur).
--   c3 / c2 = chance in % that the spin lands on 3 / on a pair of this symbol
--   m3 / m2 = multiplier applied to the stake for 3 / for a pair
-- No match = whatever percent is left, multiplier NO_MATCH_MULT.
local SYMBOLS = {
    { id = 'cherry',  frame = 0, label = 'Cherry', plural = 'Cherries',  c3 = 5.0, m3 = 1.5,  c2 = 8, m2 = 0.7 },
    { id = 'crown',   frame = 1, label = 'Crown', plural = 'Crowns',   c3 = 1.0, m3 = 10,   c2 = 2, m2 = 2 },
    { id = 'star',    frame = 2, label = 'Star', plural = 'Stars',    c3 = 2.5, m3 = 3,    c2 = 5, m2 = 1.25 },
    { id = 'seven',   frame = 3, label = 'Seven', plural = 'Sevens',   c3 = 1.5, m3 = 5,    c2 = 4, m2 = 1.5 },
    { id = 'diamond', frame = 4, label = 'Diamond', plural = 'Diamonds', c3 = 3.5, m3 = 2.5,  c2 = 6, m2 = 1.0 },
    { id = 'heart',   frame = 5, label = 'Heart', plural = 'Hearts',   c3 = 4.0, m3 = 2,    c2 = 7, m2 = 0.9 },
    { id = 'six',     frame = 6, label = 'Six', plural = 'Sixes',     c3 = 4.0, m3 = 0.25, c2 = 8, m2 = 0.4 },
}
local NO_MATCH_MULT = 0.4

-- SHOP SLOT (the weaker version opened from a button in the shop, modelled on Hot Potato's Plinko:
-- you pay a cost per pull, the cost goes up every few pulls and resets every ante).
-- sm3 / sm2 / SHOP_NO_MATCH are the shop multipliers; the chances are the same as above.
-- Average return is about X0.83 (the Boss Blind version is about X1.03), so it is the weaker one.
local SHOP_NO_MATCH = 0.4
local SHOP_MULTS = {          -- [symbol id] = { triple, pair }
    cherry = { 1.25, 0.5 }, crown = { 6, 1.5 }, star = { 2.5, 1 }, seven = { 4, 1.25 },
    diamond = { 2, 0.75 }, heart = { 1.5, 0.6 }, six = { 0.25, 0.25 },
}
local SHOP_COST_EVERY = 3     -- +$1 after every 3 pulls (like Plinko's rolls_to_up_cost)

-- Stake choices per category.
local MONEY_LEVELS = { 5, 10, 25, 50 }        -- plus "all your money"
local CAP_LEVELS = { 5, 10, 25 }
local FIRST_LEVELS = { 0.25, 0.5, 1 }
local JOKER_LEVELS = { 10, 25, 50 }           -- percent of the Joker's values

local CAP_MAX = 200
local FIRST_MIN, FIRST_MAX = 0.1, 10

-- ===================================================================
-- Small helpers
-- ===================================================================
local function round2(x) return math.floor(x * 100 + 0.5) / 100 end

local function fmt_num(x)
    local s = ('%.2f'):format(x)
    s = s:gsub('0+$', '')
    s = s:gsub('%.$', '')
    return s
end

local function to_num(x)
    if type(to_number) == 'function' then
        local ok, v = pcall(to_number, x)
        if ok and type(v) == 'number' then return v end
    end
    return tonumber(x) or 0
end

local function rand01(seed)
    if type(pseudorandom) == 'function' and G and G.GAME and G.GAME.pseudorandom then
        local ok, v = pcall(pseudorandom, seed)
        if ok and type(v) == 'number' then return v end
    end
    return math.random()
end

local function deck_active()
    local b = G and G.GAME and G.GAME.selected_back
    local c = b and b.effect and b.effect.center
    return (c and c.key == DECK_KEY) and true or false
end

local function boss_beaten()
    local bl = G and G.GAME and G.GAME.blind
    if not bl then return false end
    if bl.boss then return true end
    if type(bl.get_type) == 'function' then
        local ok, t = pcall(bl.get_type, bl)
        return ok and t == 'Boss'
    end
    return false
end

-- lowest / highest multiplier on the paytable (used for the "worst / best" preview)
local MIN_MULT, MAX_MULT = NO_MATCH_MULT, NO_MATCH_MULT
for _, s in ipairs(SYMBOLS) do
    MIN_MULT = math.min(MIN_MULT, s.m3, s.m2)
    MAX_MULT = math.max(MAX_MULT, s.m3, s.m2)
end

-- Multiplier of a symbol for the current popup mode ('boss' or 'shop').
local function sym_mult(s, shop, pair)
    if shop then
        local t = SHOP_MULTS[s.id] or { s.m3, s.m2 }
        return pair and t[2] or t[1]
    end
    return pair and s.m2 or s.m3
end

-- ===================================================================
-- Rolling (pure logic: no UI)
-- ===================================================================
-- returns reels {i1,i2,i3}, count (3 / 2 / 0), winning symbol index or nil, multiplier
local function roll_outcome(shop)
    local r = rand01('cbuf_slot_outcome') * 100
    for idx, s in ipairs(SYMBOLS) do
        r = r - s.c3
        if r < 0 then return { idx, idx, idx }, 3, idx, sym_mult(s, shop, false) end
    end
    for idx, s in ipairs(SYMBOLS) do
        r = r - s.c2
        if r < 0 then
            local others = {}
            for j = 1, #SYMBOLS do
                if j ~= idx then others[#others + 1] = j end
            end
            local k = math.floor(rand01('cbuf_slot_third') * #others) + 1
            if k > #others then k = #others end
            local order = { idx, idx, others[k] }
            local pos = math.floor(rand01('cbuf_slot_pos') * 3) + 1
            if pos > 3 then pos = 3 end
            order[3], order[pos] = order[pos], order[3]
            return order, 2, idx, sym_mult(s, shop, true)
        end
    end
    local pool = {}
    for j = 1, #SYMBOLS do pool[j] = j end
    local order = {}
    for n = 1, 3 do
        local i = math.floor(rand01('cbuf_slot_d' .. n) * #pool) + 1
        if i > #pool then i = #pool end
        order[n] = table.remove(pool, i)
    end
    return order, 0, nil, shop and SHOP_NO_MATCH or NO_MATCH_MULT
end

-- ---- Joker values (the thing you can stake) ----
local TOP_KEYS = { mult = true, h_mult = true, t_mult = true, chips = true, h_chips = true, t_chips = true,
                   x_mult = true, x_chips = true }
local function is_x_key(k)
    return k == 'x_mult' or k == 'xmult' or k == 'Xmult' or k == 'x_chips' or k == 'xchips'
end
local BAD_WORDS = { 'odds', 'chance', 'used', 'pos', 'round', 'remain', 'count', 'hand', 'size', 'slot', 'discard' }
local function extra_key_ok(k)
    if type(k) ~= 'string' then return false end
    local l = k:lower()
    for _, w in ipairs(BAD_WORDS) do
        if l:find(w, 1, true) then return false end
    end
    return (l:find('mult', 1, true) or l:find('chip', 1, true) or l:find('gain', 1, true)
        or l:find('mod', 1, true) or l:find('xmult', 1, true)) and true or false
end

-- f = 1 - stake + stake * multiplier (a plain factor). X values only scale the part above X1.
local function scale_value(k, v, f)
    if is_x_key(k) then
        return math.max(1, round2(1 + (v - 1) * f))
    end
    local nv = v * f
    if v == math.floor(v) then
        return math.max(1, math.floor(nv + 0.5))
    end
    return math.max(0.01, round2(nv))
end

local function boostable_slots(card)
    local slots = {}
    local ab = card and card.ability
    if type(ab) ~= 'table' then return slots end
    for k in pairs(TOP_KEYS) do
        local v = ab[k]
        if type(v) == 'number' and v > 0 and not (is_x_key(k) and v <= 1) then slots[#slots + 1] = { ab, k } end
    end
    if type(ab.extra) == 'table' then
        for k, v in pairs(ab.extra) do
            if type(v) == 'number' and v > 0 and extra_key_ok(k) and not (is_x_key(k) and v <= 1) then
                slots[#slots + 1] = { ab.extra, k }
            end
        end
    end
    -- stable order so the preview always shows the same value first
    table.sort(slots, function(a, b) return tostring(a[2]) < tostring(b[2]) end)
    return slots
end

local function joker_name(card)
    local ok, name = pcall(function()
        return localize { type = 'name_text', set = 'Joker', key = card.config.center.key }
    end)
    if ok and type(name) == 'string' and name ~= '' and name ~= 'ERROR' then return name end
    return (card and card.config and card.config.center and card.config.center.name) or 'Joker'
end

-- ===================================================================
-- Stakes: what the player can choose to gamble
-- ===================================================================
local function build_stakes()
    local list = {}
    local dollars = math.floor(to_num(G.GAME.dollars or 0))
    if dollars >= 1 then
        local lv = {}
        for _, v in ipairs(MONEY_LEVELS) do
            if v < dollars then lv[#lv + 1] = v end
        end
        lv[#lv + 1] = dollars     -- the last choice is always "all your money"
        list[#list + 1] = { kind = 'money', name = 'Cash', levels = lv }
    end
    local cap = to_num(G.GAME.interest_cap or 25)
    do
        local lv = {}
        for _, v in ipairs(CAP_LEVELS) do
            if v <= cap then lv[#lv + 1] = v end
        end
        if #lv > 0 then list[#list + 1] = { kind = 'cap', name = 'Interest cap', levels = lv } end
    end
    local x = to_num(G.GAME.cbuf_first_x or 1)
    do
        local lv = {}
        for _, v in ipairs(FIRST_LEVELS) do
            if v <= x + 0.0001 then lv[#lv + 1] = v end
        end
        if #lv > 0 then list[#list + 1] = { kind = 'first', name = 'First hand X', levels = lv } end
    end
    if G.jokers and G.jokers.cards then
        for _, c in ipairs(G.jokers.cards) do
            if #boostable_slots(c) > 0 then
                list[#list + 1] = { kind = 'joker', name = joker_name(c), card = c, levels = JOKER_LEVELS }
            end
        end
    end
    for _, st in ipairs(list) do
        st.pick = math.min(2, #st.levels)    -- start on the middle-ish stake
    end
    return list
end

-- before / after value of a stake for a given multiplier m
local function calc(st, level, m)
    if st.kind == 'money' then
        local d = math.floor(to_num(G.GAME.dollars or 0))
        return d, d - level + math.floor(level * m + 0.5)
    elseif st.kind == 'cap' then
        local cap = to_num(G.GAME.interest_cap or 25)
        local part = math.floor(level * m / 5 + 0.5) * 5
        return cap, math.max(0, math.min(CAP_MAX, cap - level + part))
    elseif st.kind == 'first' then
        local x = to_num(G.GAME.cbuf_first_x or 1)
        return x, math.max(FIRST_MIN, math.min(FIRST_MAX, round2(x - level + level * m)))
    else
        local slot = boostable_slots(st.card)[1]
        if not slot then return 0, 0 end
        local v = slot[1][slot[2]]
        local p = level / 100
        return v, scale_value(slot[2], v, 1 - p + p * m)
    end
end

local function fmt_value(st, v)
    if st.kind == 'money' or st.kind == 'cap' then return '$' .. fmt_num(v) end
    if st.kind == 'first' then return 'X' .. fmt_num(v) end
    return fmt_num(v)
end

local function stake_label(st, level)
    if st.kind == 'money' then return '$' .. fmt_num(level) end
    if st.kind == 'cap' then return '$' .. fmt_num(level) .. ' of the cap' end
    if st.kind == 'first' then return 'X' .. fmt_num(level) end
    return fmt_num(level) .. '% of its values'
end

local function info_text(st)
    if st.kind == 'money' then
        return 'You have ' .. fmt_value(st, math.floor(to_num(G.GAME.dollars or 0)))
    elseif st.kind == 'cap' then
        return 'Interest cap is ' .. fmt_value(st, to_num(G.GAME.interest_cap or 25))
    elseif st.kind == 'first' then
        return 'First hand is ' .. fmt_value(st, to_num(G.GAME.cbuf_first_x or 1))
    end
    local slot = boostable_slots(st.card)[1]
    if not slot then return ' ' end
    return tostring(slot[2]) .. ' = ' .. fmt_num(slot[1][slot[2]])
end

-- ===================================================================
-- Popup state
-- ===================================================================
local SLOT = { active = false, text = {}, mode = 'boss' }
local SHOP_STAKE = { kind = 'shop', name = 'Cash' }

local function now()
    return (G and G.TIMERS and G.TIMERS.REAL) or 0
end

local function speed()
    return CFG.slot_fast and 0.55 or 1
end

local function add_tick(delay, fn)
    G.E_MANAGER:add_event(Event({
        trigger = 'after', delay = delay, blocking = false, blockable = false, timer = 'REAL',
        func = function() fn(); return true end,
    }))
end

local function play(snd, pitch, vol)
    if type(play_sound) == 'function' then pcall(play_sound, snd, pitch, vol) end
end

-- ---- Shop Slot cost: starts at $3, +$1 every 3 pulls, back to $3 each new ante ----
local SHOP_MIN, SHOP_MAX = SHOP_NO_MATCH, SHOP_NO_MATCH
for _, m in pairs(SHOP_MULTS) do
    SHOP_MIN = math.min(SHOP_MIN, m[1], m[2])
    SHOP_MAX = math.max(SHOP_MAX, m[1], m[2])
end

local function shop_cost()
    local ante = G.GAME.round_resets and G.GAME.round_resets.ante
    if G.GAME.cbuf_shop_ante ~= ante then
        G.GAME.cbuf_shop_ante = ante
        G.GAME.cbuf_shop_pulls = 0
    end
    return CFG.shop_slot_cost + math.floor((G.GAME.cbuf_shop_pulls or 0) / SHOP_COST_EVERY)
end

local function shop_can_afford(cost)
    return to_num(G.GAME.dollars or 0) - to_num(G.GAME.bankrupt_at or 0) >= cost
end

local function refresh_shop_text()
    local cost = shop_cost()
    SLOT.text.kind = 'COST: $' .. cost
    SLOT.text.stake = ('Pays $%d to $%d'):format(math.floor(cost * SHOP_MIN + 0.5), math.floor(cost * SHOP_MAX + 0.5))
    SLOT.text.info = 'You have $' .. math.floor(to_num(G.GAME.dollars or 0))
    SLOT.text.range = ('Cost +$1 every %d pulls, resets each ante'):format(SHOP_COST_EVERY)
    SLOT.text.button = shop_can_afford(cost) and ('PULL $' .. cost) or 'NO MONEY'
end

local function refresh_pick_text()
    local st = SLOT.stakes and SLOT.stakes[SLOT.kind_i]
    if not st then return end
    local level = st.levels[st.pick]
    SLOT.text.kind = st.name .. '  (' .. SLOT.kind_i .. '/' .. #SLOT.stakes .. ')'
    SLOT.text.stake = 'Stake: ' .. stake_label(st, level) .. ((st.kind == 'money' and st.pick == #st.levels) and ' (all)' or '')
    SLOT.text.info = info_text(st)
    local _, lo = calc(st, level, MIN_MULT)
    local _, hi = calc(st, level, MAX_MULT)
    SLOT.text.range = ('Worst X%s: %s   Best X%s: %s'):format(fmt_num(MIN_MULT), fmt_value(st, lo), fmt_num(MAX_MULT), fmt_value(st, hi))
end

local function apply_result()
    if SLOT.applied then return end
    SLOT.applied = true
    local st = SLOT.stake
    if not (st and SLOT.after ~= nil) then return end     -- no spin happened: nothing was staked
    if SLOT.mode == 'shop' then
        -- the cost was already paid when the lever was pulled; this is the payout
        if SLOT.after > 0 and type(ease_dollars) == 'function' then ease_dollars(SLOT.after, true) end
        return
    end
    if st.kind == 'money' then
        local delta = SLOT.after - SLOT.before
        if delta ~= 0 and type(ease_dollars) == 'function' then ease_dollars(delta, true) end
    elseif st.kind == 'cap' then
        G.GAME.interest_cap = SLOT.after
    elseif st.kind == 'first' then
        G.GAME.cbuf_first_x = SLOT.after
    else
        local card = st.card
        if card and card.ability then
            local p = SLOT.level / 100
            local f = 1 - p + p * SLOT.m
            for _, slot in ipairs(boostable_slots(card)) do
                slot[1][slot[2]] = scale_value(slot[2], slot[1][slot[2]], f)
            end
            local msg = 'X' .. fmt_num(SLOT.m)
            local good = SLOT.m >= 1
            G.E_MANAGER:add_event(Event({
                trigger = 'after', delay = 0.3,
                func = function()
                    if card_eval_status_text then
                        pcall(card_eval_status_text, card, 'extra', nil, nil, nil,
                            { message = msg, colour = good and G.C.GOLD or G.C.RED })
                    end
                    if card.juice_up then card:juice_up(0.6, 0.3) end
                    return true
                end,
            }))
        end
    end
end

local function finish()
    if not SLOT.active then return end
    SLOT.active = false
    local ref = SLOT.ref
    SLOT.ref = nil
    local ok, err = pcall(apply_result)
    if not ok then log('error', 'applying result failed: ' .. tostring(err)) end
    if type(ref) == 'function' then
        -- Small delay so the overlay finishes closing before the cash-out rows are built.
        G.E_MANAGER:add_event(Event({
            trigger = 'after', delay = 0.2,
            func = function()
                local ok2, err2 = pcall(ref)
                if not ok2 then log('error', 'evaluate_round failed: ' .. tostring(err2)) end
                return true
            end,
        }))
    end
end

-- ===================================================================
-- Reel animation
-- ===================================================================
local function set_frame(i, frame, blurred)
    local sp = SLOT.sprites and SLOT.sprites[i]
    if sp and sp.set_sprite_pos then sp:set_sprite_pos({ x = frame, y = blurred and 1 or 0 }) end
end

local function title_for(m)
    if m >= 5 then return 'JACKPOT!' end
    if m >= 2 then return 'BIG WIN!' end
    if m > 1 then return 'SMALL WIN' end
    if m == 1 then return 'BREAK EVEN' end
    return 'OUCH...'
end

local function reveal_results()
    SLOT.phase = 'result'
    local step = 0.45 * speed()
    local st = SLOT.stake
    local line1
    if SLOT.count == 3 then
        line1 = ('3 %s: X%s'):format(SYMBOLS[SLOT.win_sym].plural, fmt_num(SLOT.m))
    elseif SLOT.count == 2 then
        line1 = ('2 %s: X%s'):format(SYMBOLS[SLOT.win_sym].plural, fmt_num(SLOT.m))
    else
        line1 = ('No match: X%s'):format(fmt_num(SLOT.m))
    end
    local line2 = ('%s: %s to %s'):format(st.name, fmt_value(st, SLOT.before), fmt_value(st, SLOT.after))
    if SLOT.mode == 'shop' then
        line2 = ('Paid $%d, won $%d'):format(SLOT.before, SLOT.after)
        if SLOT.after > SLOT.before then line2 = line2 .. ' (+$' .. (SLOT.after - SLOT.before) .. ')' end
    end
    add_tick(step, function()
        if not SLOT.active then return end
        SLOT.text.line1 = line1
        play('generic1', 1, 0.6)
        for i = 1, 3 do
            if SLOT.win_sym and SLOT.result[i] == SLOT.win_sym and SLOT.sprites[i] and SLOT.sprites[i].juice_up then
                SLOT.sprites[i]:juice_up(0.35, 0.15)
            end
        end
    end)
    add_tick(step * 2, function()
        if not SLOT.active then return end
        SLOT.text.line2 = line2
        play('generic1', 1.2, 0.6)
    end)
    add_tick(step * 3, function()
        if not SLOT.active then return end
        SLOT.text.title = title_for(SLOT.m)
        local m = SLOT.m
        if m >= 2 then
            -- big win / jackpot
            play('win', 1, 0.9)
            if m >= 5 then add_tick(0.25, function() play('timpani', 1.2, 0.7) end) end
            if G.ROOM then G.ROOM.jiggle = (G.ROOM.jiggle or 0) + (m >= 5 and 1.4 or 0.7) end
            for i = 1, 3 do if SLOT.sprites[i] and SLOT.sprites[i].juice_up then SLOT.sprites[i]:juice_up(0.6, 0.3) end end
        elseif m > 1 then
            -- mid win (between X1 and X2): coin + mult tick
            play('coin3', 0.85 + 0.15 * m, 0.7)
            add_tick(0.12, function() play('multhit1', 1, 0.5) end)
        elseif m == 1 then
            -- break even: a neutral double tick
            play('chips1', 1, 0.7)
            add_tick(0.12, function() play('generic1', 1.3, 0.5) end)
        else
            -- loss: low "wrong" buzz, a falling second note, a third one when it is a heavy loss
            play('negative', 0.75, 0.9)
            add_tick(0.18, function() play('cancel', 0.7, 0.8) end)
            if m <= 0.4 then add_tick(0.4, function() play('negative', 0.55, 0.8) end) end
            if G.ROOM then G.ROOM.jiggle = (G.ROOM.jiggle or 0) + 0.3 end
        end
        SLOT.phase = 'done'
        SLOT.text.button = 'COLLECT'
        if SLOT.mode == 'shop' then
            -- pay out now so the next pull can use the winnings, then offer another pull
            local okp, errp = pcall(apply_result)
            if not okp then log('error', 'shop payout failed: ' .. tostring(errp)) end
            SLOT.text.cancel = 'BACK'
            add_tick(0.3, function()
                if SLOT.active and SLOT.phase == 'done' then
                    local cost = shop_cost()
                    SLOT.text.info = 'You have $' .. math.floor(to_num(G.GAME.dollars or 0))
                    SLOT.text.button = shop_can_afford(cost) and ('AGAIN $' .. cost) or 'NO MONEY'
                    SLOT.text.kind = 'COST: $' .. cost
                end
            end)
        end
    end)
end

local function tick_reel(i)
    if not SLOT.active or SLOT.phase ~= 'spinning' then return end
    local remain = SLOT.stop_at[i] - now()
    if remain <= 0 then
        set_frame(i, SYMBOLS[SLOT.result[i]].frame, false)
        local sp = SLOT.sprites[i]
        if sp and sp.juice_up then sp:juice_up(0.3, 0.15) end
        play('chips2', 0.85 + 0.1 * i, 0.7)
        if G.ROOM then G.ROOM.jiggle = (G.ROOM.jiggle or 0) + 0.25 end
        SLOT.stopped = SLOT.stopped + 1
        if SLOT.stopped >= 3 then reveal_results() end
        return
    end
    local slow = remain < 0.55 * speed()
    -- Cosmetic only: plain math.random, so the run's seeded RNG (and its save file) is not touched.
    local f = SYMBOLS[math.random(1, #SYMBOLS)].frame
    set_frame(i, f, not slow)
    play('highlight1', 0.9 + 0.05 * i, 0.15)
    local d
    if not slow then d = 0.05 elseif remain > 0.3 * speed() then d = 0.11 else d = 0.18 end
    add_tick(d, function() tick_reel(i) end)
end

local function start_spin()
    if SLOT.phase ~= 'pick' then return end
    if SLOT.mode == 'shop' then
        local cost = shop_cost()
        if not shop_can_afford(cost) then play('cancel', 1, 0.6); return end
        G.GAME.cbuf_shop_pulls = (G.GAME.cbuf_shop_pulls or 0) + 1
        if type(ease_dollars) == 'function' then ease_dollars(-cost, true) end
        SLOT.result, SLOT.count, SLOT.win_sym, SLOT.m = roll_outcome(true)
        SLOT.stake = SHOP_STAKE
        SLOT.level = cost
        SLOT.before = cost
        SLOT.after = math.floor(cost * SLOT.m + 0.5)
        SLOT.applied = false
    else
        local st = SLOT.stakes[SLOT.kind_i]
        if not st then return end
        -- the result is decided the moment the lever is pulled, using the stake that is on screen
        SLOT.result, SLOT.count, SLOT.win_sym, SLOT.m = roll_outcome(false)
        SLOT.stake = st
        SLOT.level = st.levels[st.pick]
        SLOT.before, SLOT.after = calc(st, SLOT.level, SLOT.m)
    end
    SLOT.phase = 'spinning'
    SLOT.text.button = 'SKIP'
    SLOT.text.title = 'GOOD LUCK!'
    SLOT.text.arrL, SLOT.text.arrR, SLOT.text.cancel = ' ', ' ', ' '
    local t, s = now(), speed()
    SLOT.stop_at = { t + 1.1 * s, t + 1.8 * s, t + 2.5 * s }
    -- Near-miss tension: if the first two reels match, the last one takes longer to stop.
    if SLOT.result[1] == SLOT.result[2] then SLOT.stop_at[3] = SLOT.stop_at[3] + 0.9 * s end
    SLOT.stopped = 0
    play('cardSlide1', 0.8, 0.9)
    if G.ROOM then G.ROOM.jiggle = (G.ROOM.jiggle or 0) + 0.4 end
    for i = 1, 3 do
        local idx = i
        add_tick(0.02 * i, function() tick_reel(idx) end)
    end
end

local function skip_spin()
    if SLOT.phase ~= 'spinning' then return end
    local t = now()
    for i = 1, 3 do
        SLOT.stop_at[i] = math.min(SLOT.stop_at[i], t + 0.12 * i)
    end
end

local function cycle_kind(d)
    if not (SLOT.active and SLOT.phase == 'pick') then return end
    local n = #SLOT.stakes
    if n < 1 then return end
    SLOT.kind_i = ((SLOT.kind_i - 1 + d) % n) + 1
    refresh_pick_text()
    play('cardSlide1', 1.1, 0.5)
end

local function cycle_level(d)
    if not (SLOT.active and SLOT.phase == 'pick') then return end
    local st = SLOT.stakes[SLOT.kind_i]
    if not st then return end
    local n = #st.levels
    st.pick = ((st.pick - 1 + d) % n) + 1
    refresh_pick_text()
    play('chips1', 0.9 + 0.1 * st.pick, 0.5)
end

local PANEL_COL, LAMP_OFF

G.FUNCS = G.FUNCS or {}
G.FUNCS.cbuf_slot_press = function(e)
    if not SLOT.active then return end
    if SLOT.phase == 'pick' then
        start_spin()
    elseif SLOT.phase == 'spinning' then
        skip_spin()
    elseif SLOT.phase == 'result' then
        -- Reveal is quick; ignore presses so lines are never skipped by accident.
    elseif SLOT.phase == 'done' then
        if SLOT.mode == 'shop' then
            -- pull again (start_spin checks the money and charges the new cost)
            local cost = shop_cost()
            if not shop_can_afford(cost) then play('cancel', 1, 0.6); return end
            SLOT.phase = 'pick'
            SLOT.text.title = 'SLOT MACHINE'
            SLOT.text.line1, SLOT.text.line2 = ' ', ' '
            start_spin()
        else
            G.FUNCS.exit_overlay_menu()
        end
    end
end
G.FUNCS.cbuf_kind_prev = function() cycle_kind(-1) end
G.FUNCS.cbuf_kind_next = function() cycle_kind(1) end
G.FUNCS.cbuf_level_prev = function() cycle_level(-1) end
G.FUNCS.cbuf_level_next = function() cycle_level(1) end
G.FUNCS.cbuf_slot_cancel = function()
    if not SLOT.active then return end
    local boss_ok = SLOT.mode == 'boss' and SLOT.phase == 'pick'
    local shop_ok = SLOT.mode == 'shop' and (SLOT.phase == 'pick' or SLOT.phase == 'done')
    if not (boss_ok or shop_ok) then return end
    G.FUNCS.exit_overlay_menu()      -- nothing was staked, finish() applies nothing
end

-- Buttons only work (and only show their background) while you are choosing the stake.
G.FUNCS.cbuf_pick_state = function(e)
    pcall(function()
        PANEL_COL = PANEL_COL or HEX('1d1633')
        local c = e.config
        local on
        if not SLOT.active then
            on = false
        elseif c.cbuf_role == 'cancel' then
            on = (SLOT.mode == 'boss' and SLOT.phase == 'pick')
                or (SLOT.mode == 'shop' and (SLOT.phase == 'pick' or SLOT.phase == 'done'))
        else
            on = SLOT.mode == 'boss' and SLOT.phase == 'pick'     -- the < > arrows
        end
        if on then
            c.button = c.cbuf_btn
            c.colour = c.cbuf_col
            c.shadow = true
        else
            c.button = nil
            c.colour = PANEL_COL
            c.shadow = false
        end
    end)
end

-- Paytable: the row of the symbol that just paid glows while the result is on screen.
G.FUNCS.cbuf_pay_row = function(e)
    pcall(function()
        local hit = SLOT.active and (SLOT.phase == 'result' or SLOT.phase == 'done')
            and SLOT.win_sym ~= nil and SLOT.win_sym == e.config.cbuf_sym
        if hit then
            e.config.colour = (math.floor(now() * 3) % 2 == 0) and HEX('4a3a10') or HEX('362a0c')
        else
            e.config.colour = G.C.CLEAR
        end
    end)
end

-- Marquee lamps around the machine: slow chase while idle, fast flicker while spinning,
-- all flashing on a big win.
G.FUNCS.cbuf_lamp = function(e)
    pcall(function()
        LAMP_OFF = LAMP_OFF or HEX('5a4414')
        local i = e.config.cbuf_i or 0
        local t = now()
        local on
        if not SLOT.active then
            on = false
        elseif SLOT.phase == 'spinning' then
            on = (math.floor(t * 12) + i) % 2 == 0
        elseif SLOT.phase == 'result' or SLOT.phase == 'done' then
            if SLOT.m and SLOT.m >= 2 then on = math.floor(t * 6) % 2 == 0 else on = (SLOT.m or 0) >= 1 end
        else
            on = (math.floor(t * 3) + i) % 4 == 0
        end
        e.config.colour = on and G.C.GOLD or LAMP_OFF
    end)
end

-- ===================================================================
-- UI
-- ===================================================================
local function make_sprite(frame, size)
    local atlas = G.ASSET_ATLAS and G.ASSET_ATLAS[ATLAS_KEY]
    if not atlas then return nil end
    local sp = Sprite(0, 0, size, size, atlas, { x = frame, y = 0 })
    if sp.states then
        sp.states.drag.can = false
        sp.states.hover.can = false
        sp.states.collide.can = false
    end
    return sp
end

local function text_row(key, scale, colour, minw)
    return { n = G.UIT.R, config = { align = 'cm', minw = minw or 6.2, minh = 0.4 }, nodes = {
        { n = G.UIT.T, config = { ref_table = SLOT.text, ref_value = key, scale = scale, colour = colour, shadow = true } },
    } }
end

local function arrow_button(key, fn)
    return { n = G.UIT.C, config = {
        align = 'cm', minw = 0.6, minh = 0.5, padding = 0.04, r = 0.1, hover = true, shadow = true,
        colour = G.C.BLUE, button = fn, cbuf_btn = fn, cbuf_col = G.C.BLUE, cbuf_role = 'arrow', func = 'cbuf_pick_state',
    }, nodes = {
        { n = G.UIT.T, config = { ref_table = SLOT.text, ref_value = key, scale = 0.45, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
    } }
end

local function picker_row(value_key, left_fn, right_fn)
    return { n = G.UIT.R, config = { align = 'cm', padding = 0.03 }, nodes = {
        arrow_button('arrL', left_fn),
        { n = G.UIT.C, config = { align = 'cm', minw = 4.6 }, nodes = {
            { n = G.UIT.T, config = { ref_table = SLOT.text, ref_value = value_key, scale = 0.4, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
        } },
        arrow_button('arrR', right_fn),
    } }
end

local function paytable_column()
    local shop = SLOT.mode == 'shop'
    local rows = {
        { n = G.UIT.R, config = { align = 'cm', padding = 0.04 }, nodes = {
            { n = G.UIT.T, config = { text = shop and 'PAYTABLE (SHOP)' or 'PAYTABLE', scale = 0.42, colour = G.C.GOLD, shadow = true } },
        } },
        { n = G.UIT.R, config = { align = 'cm', padding = 0.02 }, nodes = {
            { n = G.UIT.T, config = { text = 'multiplies your stake', scale = 0.26, colour = G.C.UI.TEXT_INACTIVE, shadow = true } },
        } },
    }
    -- biggest payout first = rarest first
    local order = {}
    for i = 1, #SYMBOLS do order[i] = i end
    table.sort(order, function(a, b)
        local ma, mb = sym_mult(SYMBOLS[a], shop, false), sym_mult(SYMBOLS[b], shop, false)
        if ma ~= mb then return ma > mb end
        return SYMBOLS[a].c3 < SYMBOLS[b].c3
    end)
    for _, i in ipairs(order) do
        local s = SYMBOLS[i]
        local m3, m2 = sym_mult(s, shop, false), sym_mult(s, shop, true)
        local c3 = (m3 >= 3) and G.C.GOLD or ((m3 < 1) and G.C.RED or G.C.UI.TEXT_LIGHT)
        local c2 = (m2 < 1) and G.C.RED or G.C.UI.TEXT_LIGHT
        rows[#rows + 1] = { n = G.UIT.R, config = { align = 'cl', padding = 0.02, r = 0.06, colour = G.C.CLEAR, func = 'cbuf_pay_row', cbuf_sym = i }, nodes = {
            { n = G.UIT.C, config = { align = 'cm', minw = 0.6 }, nodes = {
                { n = G.UIT.O, config = { object = SLOT.pay_sprites[i] } },
            } },
            { n = G.UIT.C, config = { align = 'cl', minw = 1.95 }, nodes = {
                { n = G.UIT.T, config = { text = ('3x: X%s (%s%%)'):format(fmt_num(m3), fmt_num(s.c3)), scale = 0.3, colour = c3, shadow = true } },
            } },
            { n = G.UIT.C, config = { align = 'cl', minw = 1.0 }, nodes = {
                { n = G.UIT.T, config = { text = ('2x: X%s'):format(fmt_num(m2)), scale = 0.3, colour = c2, shadow = true } },
            } },
        } }
    end
    rows[#rows + 1] = { n = G.UIT.R, config = { align = 'cm', padding = 0.05 }, nodes = {
        { n = G.UIT.T, config = { text = ('No match: X%s'):format(fmt_num(shop and SHOP_NO_MATCH or NO_MATCH_MULT)), scale = 0.3, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
    } }
    return { n = G.UIT.C, config = { align = 'cm', padding = 0.1, r = 0.1, colour = HEX('120c20'), emboss = 0.05 }, nodes = rows }
end

local function build_definition()
    local lamps = {}
    for i = 1, 12 do
        lamps[#lamps + 1] = { n = G.UIT.C, config = { align = 'cm', padding = 0.03 }, nodes = {
            { n = G.UIT.B, config = { w = 0.2, h = 0.2, r = 0.06, colour = G.C.GOLD, func = 'cbuf_lamp', cbuf_i = i } },
        } }
    end
    local reel_cols = {}
    for i = 1, 3 do
        reel_cols[#reel_cols + 1] = { n = G.UIT.C, config = { align = 'cm', padding = 0.05 }, nodes = {
            { n = G.UIT.R, config = { align = 'cm', padding = 0.06, r = 0.08, colour = HEX('2b2326'), emboss = 0.05 }, nodes = {
                { n = G.UIT.O, config = { object = SLOT.sprites[i] } },
            } },
        } }
    end
    local machine = { n = G.UIT.R, config = { align = 'cm', padding = 0.09, r = 0.15, colour = HEX('f2b632'), emboss = 0.06 }, nodes = {
        { n = G.UIT.R, config = { align = 'cm' }, nodes = lamps },
        { n = G.UIT.R, config = { align = 'cm', padding = 0.12, r = 0.1, colour = HEX('160f26') }, nodes = {
            { n = G.UIT.R, config = { align = 'cm' }, nodes = reel_cols },
        } },
    } }
    local buttons = { n = G.UIT.R, config = { align = 'cm', padding = 0.06 }, nodes = {
        { n = G.UIT.C, config = {
            id = 'cbuf_slot_button', align = 'cm', minw = 3.0, minh = 0.7, padding = 0.1, r = 0.1, hover = true,
            colour = G.C.GREEN, button = 'cbuf_slot_press', shadow = true, focus_args = { nav = 'wide', snap_to = true },
        }, nodes = {
            { n = G.UIT.T, config = { ref_table = SLOT.text, ref_value = 'button', scale = 0.5, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
        } },
        { n = G.UIT.C, config = { minw = 0.2 } },
        { n = G.UIT.C, config = {
            align = 'cm', minw = 2.4, minh = 0.7, padding = 0.1, r = 0.1, hover = true, shadow = true,
            colour = G.C.RED, button = 'cbuf_slot_cancel', cbuf_btn = 'cbuf_slot_cancel', cbuf_col = G.C.RED, cbuf_role = 'cancel', func = 'cbuf_pick_state',
        }, nodes = {
            { n = G.UIT.T, config = { ref_table = SLOT.text, ref_value = 'cancel', scale = 0.4, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
        } },
    } }
    local right = { n = G.UIT.C, config = { align = 'cm', padding = 0.05 }, nodes = {
        machine,
        picker_row('kind', 'cbuf_kind_prev', 'cbuf_kind_next'),
        picker_row('stake', 'cbuf_level_prev', 'cbuf_level_next'),
        text_row('info', 0.32, G.C.UI.TEXT_INACTIVE, 6.2),
        text_row('range', 0.32, G.C.GOLD, 6.2),
        text_row('line1', 0.38, G.C.UI.TEXT_LIGHT, 6.2),
        text_row('line2', 0.38, G.C.UI.TEXT_LIGHT, 6.2),
        buttons,
    } }
    return create_UIBox_generic_options({
        no_back = true,
        colour = HEX('1d1633'),
        outline_colour = G.C.GOLD,
        contents = {
            { n = G.UIT.R, config = { align = 'cm', padding = 0.08 }, nodes = {
                { n = G.UIT.T, config = { ref_table = SLOT.text, ref_value = 'title', scale = 0.7, colour = G.C.GOLD, shadow = true } },
            } },
            { n = G.UIT.R, config = { align = 'cm', padding = 0.05 }, nodes = {
                paytable_column(),
                { n = G.UIT.C, config = { minw = 0.15 } },
                right,
            } },
        },
    })
end

local function init_sprites()
    SLOT.sprites, SLOT.pay_sprites = {}, {}
    for i = 1, 3 do
        local sp = make_sprite(SYMBOLS[((i - 1) % #SYMBOLS) + 1].frame, 1.15)
        if not sp then
            SLOT.active = false
            error('atlas ' .. ATLAS_KEY .. ' not found')
        end
        SLOT.sprites[i] = sp
    end
    for i, s in ipairs(SYMBOLS) do SLOT.pay_sprites[i] = make_sprite(s.frame, 0.5) end
end

-- returns true when the popup was opened
local function open_popup(ref)
    local stakes = build_stakes()
    if #stakes == 0 then return false end
    SLOT.mode = 'boss'
    SLOT.active = true
    SLOT.applied = false
    SLOT.ref = ref
    SLOT.phase = 'pick'
    SLOT.stakes = stakes
    SLOT.kind_i = 1
    SLOT.stake, SLOT.before, SLOT.after, SLOT.m, SLOT.level = nil, nil, nil, nil, nil
    SLOT.result = { 1, 2, 3 }
    SLOT.text = { title = 'GAMBLING DECK', button = 'PULL LEVER', cancel = 'NO THANKS', arrL = '<', arrR = '>',
                  kind = ' ', stake = ' ', info = ' ', range = ' ', line1 = ' ', line2 = ' ' }
    init_sprites()
    refresh_pick_text()
    G.GAME.cbuf_slot_round = G.GAME.round
    play('cardFan2', 1, 0.7)
    G.FUNCS.overlay_menu({ definition = build_definition(), config = { no_esc = true } })
    return true
end

-- ===================================================================
-- SHOP SLOT: the weaker slot machine, opened from a button in the shop
-- ===================================================================
local function open_shop_popup()
    SLOT.mode = 'shop'
    SLOT.active = true
    SLOT.applied = false
    SLOT.ref = nil
    SLOT.phase = 'pick'
    SLOT.stakes, SLOT.kind_i = {}, 1
    SLOT.stake, SLOT.before, SLOT.after, SLOT.m, SLOT.level = nil, nil, nil, nil, nil
    SLOT.result = { 1, 2, 3 }
    SLOT.text = { title = 'SLOT MACHINE', button = 'PULL', cancel = 'BACK', arrL = ' ', arrR = ' ',
                  kind = ' ', stake = ' ', info = ' ', range = ' ', line1 = ' ', line2 = ' ' }
    init_sprites()
    refresh_shop_text()
    play('cardFan2', 1, 0.7)
    G.FUNCS.overlay_menu({ definition = build_definition() })
    return true
end

local SHOPTXT = { cost = ' ' }
local SHOP_COL

local function shop_slot_allowed()
    if not CFG.shop_slot_enabled then return false end
    if not (G and G.GAME) then return false end
    return (CFG.shop_slot_all_decks or deck_active()) and true or false
end

-- ---- Lever: the shop button is a slot-machine lever. Clicking it pulls the handle down (4 frames),
-- holds for a moment with a click, lets it spring back up, and the slot window opens at the bottom of the pull.
local LEVER = { t0 = nil, frame = 0, sprite = nil }
local LEVER_DOWN, LEVER_HOLD, LEVER_UP = 0.22, 0.12, 0.30      -- seconds
local LEVER_FRAMES = 4

local function lever_frame(t)
    if t < LEVER_DOWN then return math.min(LEVER_FRAMES - 1, math.floor(t / LEVER_DOWN * LEVER_FRAMES)) end
    if t < LEVER_DOWN + LEVER_HOLD then return LEVER_FRAMES - 1 end
    local u = (t - LEVER_DOWN - LEVER_HOLD) / LEVER_UP
    if u < 1 then return math.max(0, LEVER_FRAMES - 1 - math.floor(u * LEVER_FRAMES)) end
    return 0
end

local function lever_tick()
    local sp = LEVER.sprite
    if not sp then return end
    local f = 0
    if LEVER.t0 then
        local t = now() - LEVER.t0
        if t > LEVER_DOWN + LEVER_HOLD + LEVER_UP then LEVER.t0 = nil else f = lever_frame(t) end
    end
    if f ~= LEVER.frame and type(sp.set_sprite_pos) == 'function' then
        LEVER.frame = f
        sp:set_sprite_pos({ x = f, y = 0 })
    end
end

G.FUNCS.cbuf_pull_lever = function(e)
    if SLOT.active or G.OVERLAY_MENU or LEVER.t0 then return end
    if G.STATE ~= G.STATES.SHOP then return end
    LEVER.t0 = now()
    play('chips1', 0.7, 0.6)                                   -- the pull
    add_tick(LEVER_DOWN, function() play('multhit1', 0.9, 0.5) end)   -- the lever locks in
    add_tick(LEVER_DOWN + LEVER_HOLD, function()
        play('cardFan2', 1, 0.5)
        local ok, err = pcall(G.FUNCS.cbuf_open_shop_slot, e)
        if not ok then log('error', 'lever: opening the slot failed: ' .. tostring(err)) end
    end)
end

G.FUNCS.cbuf_open_shop_slot = function(e)
    if SLOT.active or G.OVERLAY_MENU then return end
    if not (G.STATE == G.STATES.SHOP) then return end
    local ok, err = pcall(open_shop_popup)
    if not ok then
        log('error', 'shop slot failed to open: ' .. tostring(err))
        SLOT.active = false
        if G.OVERLAY_MENU then pcall(G.FUNCS.exit_overlay_menu) end
    end
end

-- Keeps the button's price label live and greys the button out while a popup is open.
G.FUNCS.cbuf_shop_btn_state = function(e)
    pcall(function()
        SHOP_COL = SHOP_COL or HEX('f2b632')
        local c = e.config
        SHOPTXT.cost = '$' .. shop_cost()
        lever_tick()
        if G.STATE == G.STATES.SHOP and not SLOT.active and not G.OVERLAY_MENU and not LEVER.t0 then
            c.button = c.cbuf_btn or 'cbuf_open_shop_slot'
            c.colour = c.cbuf_col or SHOP_COL
        else
            c.button = nil
            c.colour = G.C.UI.BACKGROUND_INACTIVE
        end
    end)
end

local function find_parent(node, id, seen)
    if type(node) ~= 'table' or seen[node] then return nil end
    seen[node] = true
    if type(node.nodes) == 'table' then
        for i, n in ipairs(node.nodes) do
            if type(n) == 'table' and type(n.config) == 'table' and n.config.id == id then return node.nodes, i end
        end
        for _, n in ipairs(node.nodes) do
            local arr, i = find_parent(n, id, seen)
            if arr then return arr, i end
        end
    end
    return nil
end

local function shop_button_node()
    local icon = make_sprite(1, 0.6)     -- the crown
    local inner = {}
    if icon then
        inner[#inner + 1] = { n = G.UIT.C, config = { align = 'cm', padding = 0.04 }, nodes = {
            { n = G.UIT.O, config = { object = icon } },
        } }
    end
    inner[#inner + 1] = { n = G.UIT.C, config = { align = 'cm', padding = 0.04 }, nodes = {
        { n = G.UIT.R, config = { align = 'cm' }, nodes = {
            { n = G.UIT.T, config = { text = 'SLOT', scale = 0.45, colour = G.C.UI.TEXT_DARK, shadow = false } },
        } },
        { n = G.UIT.R, config = { align = 'cm' }, nodes = {
            { n = G.UIT.T, config = { ref_table = SHOPTXT, ref_value = 'cost', scale = 0.4, colour = G.C.UI.TEXT_DARK, shadow = false } },
        } },
    } }
    return { n = G.UIT.R, config = { align = 'cm', padding = 0.05 }, nodes = {
        { n = G.UIT.R, config = {
            id = 'cbuf_shop_slot_button', align = 'cm', minw = 2.8, minh = 0.9, padding = 0.05, r = 0.15,
            colour = HEX('f2b632'), cbuf_col = HEX('f2b632'), button = 'cbuf_open_shop_slot', func = 'cbuf_shop_btn_state', hover = true, shadow = true,
        }, nodes = inner },
    } }
end

-- The lever button floating on the RIGHT side of the shop (a handle you must press; see LEVER above).
local SHOP_ICON, shop_icon_failed
local function make_lever_sprite(w, h)
    local atlas = G.ASSET_ATLAS and G.ASSET_ATLAS['cbuf_lever']
    if not atlas then return nil end
    local sp = Sprite(0, 0, w, h, atlas, { x = 0, y = 0 })
    if sp.states then
        sp.states.drag.can = false
        sp.states.hover.can = false
        sp.states.collide.can = false
    end
    return sp
end

local function shop_icon_definition()
    local lever = make_lever_sprite(0.8, 1.33)
    LEVER.sprite, LEVER.frame, LEVER.t0 = lever, 0, nil
    local col = { n = G.UIT.C, config = { align = 'cm' }, nodes = {} }
    if lever then
        col.nodes[#col.nodes + 1] = { n = G.UIT.R, config = { align = 'cm' }, nodes = {
            { n = G.UIT.O, config = { object = lever } },
        } }
    else
        -- atlas missing: still give a usable button
        col.nodes[#col.nodes + 1] = { n = G.UIT.R, config = { align = 'cm', minh = 1.0 }, nodes = {
            { n = G.UIT.T, config = { text = 'SLOT', scale = 0.4, colour = G.C.GOLD, shadow = true } },
        } }
    end
    col.nodes[#col.nodes + 1] = { n = G.UIT.R, config = { align = 'cm' }, nodes = {
        { n = G.UIT.T, config = { text = 'PULL', scale = 0.28, colour = G.C.GOLD, shadow = true } },
    } }
    return { n = G.UIT.ROOT, config = { align = 'cm', colour = G.C.CLEAR }, nodes = {
        { n = G.UIT.R, config = {
            id = 'cbuf_shop_slot_button', align = 'cm', minw = 1.05, minh = 1.85, padding = 0.06, r = 0.2,
            colour = HEX('2b2326'), cbuf_col = HEX('2b2326'), outline = 1.2, outline_colour = G.C.GOLD,
            button = 'cbuf_pull_lever', cbuf_btn = 'cbuf_pull_lever', func = 'cbuf_shop_btn_state', hover = true, shadow = true,
        }, nodes = { col } },
    } }
end

local function remove_shop_icon()
    local b = SHOP_ICON
    SHOP_ICON = nil
    LEVER.sprite, LEVER.t0 = nil, nil
    if b and type(b.remove) == 'function' then pcall(b.remove, b) end
end

local function ensure_shop_icon()
    if CFG.shop_slot_style == 'column' or SHOP_ICON or shop_icon_failed then return end
    if not (G.shop and G.STATE == G.STATES.SHOP and shop_slot_allowed()) then return end
    local h = (G.shop.T and G.shop.T.h) or 6
    local ok, box = pcall(function()
        return UIBox {
            definition = shop_icon_definition(),
            config = { align = 'cr', offset = { x = 0.25, y = -(h / 2) + 1.35 }, major = G.shop, bond = 'Weak' },
        }
    end)
    if ok and box then
        SHOP_ICON = box
    else
        shop_icon_failed = true
        log('error', 'shop icon button failed (set shop_slot_style = "column" in config.lua): ' .. tostring(box))
    end
end

local shop_warned = false
local function add_shop_button(def)
    if CFG.shop_slot_style ~= 'column' then return end     -- the default is the floating icon button
    if not shop_slot_allowed() then return end
    if find_parent(def, 'cbuf_shop_slot_button', {}) then return end     -- already added
    local arr, i = find_parent(def, 'next_round_button', {})
    if not arr then
        if not shop_warned then
            shop_warned = true
            log('warn', 'shop: next_round_button not found, the shop slot button was not added')
        end
        return
    end
    local at = i
    local nxt = arr[i + 1]
    if type(nxt) == 'table' and type(nxt.config) == 'table' and nxt.config.button == 'reroll_shop' then at = i + 1 end
    table.insert(arr, at + 1, shop_button_node())
end

-- G.UIDEF.shop is wrapped lazily, every time the shop is about to be built, so it still works when
-- another mod (e.g. Hot Potato's new shop) replaces it after this file was loaded.
local SHOP_WRAPPER
local function install_shop_hook()
    if not (G.UIDEF and type(G.UIDEF.shop) == 'function') then return end
    if G.UIDEF.shop == SHOP_WRAPPER then return end
    local under = G.UIDEF.shop
    SHOP_WRAPPER = function(...)
        local def = under(...)
        local ok, err = pcall(add_shop_button, def)
        if not ok then log('error', 'adding the shop button failed: ' .. tostring(err)) end
        return def
    end
    G.UIDEF.shop = SHOP_WRAPPER
end

if Game and type(Game.update_shop) == 'function' and not Game._cbuf_shop_hooked then
    local update_shop_ref = Game.update_shop
    Game.update_shop = function(self, ...)
        pcall(install_shop_hook)
        local r = update_shop_ref(self, ...)
        pcall(ensure_shop_icon)
        return r
    end
    Game._cbuf_shop_hooked = true
else
    log('warn', 'Game.update_shop not found, the shop slot button is disabled')
end

-- Remove the floating button when the shop closes (and on any other way of leaving the shop).
if type(G.FUNCS.toggle_shop) == 'function' and not G.FUNCS._cbuf_toggle_wrapped then
    local toggle_ref = G.FUNCS.toggle_shop
    G.FUNCS.toggle_shop = function(...)
        pcall(remove_shop_icon)
        return toggle_ref(...)
    end
    G.FUNCS._cbuf_toggle_wrapped = true
end
if Game and type(Game.update) == 'function' and not Game._cbuf_update_hooked then
    local update_ref = Game.update
    Game.update = function(self, ...)
        if SHOP_ICON and (G.STATE ~= G.STATES.SHOP or not G.shop) then pcall(remove_shop_icon) end
        return update_ref(self, ...)
    end
    Game._cbuf_update_hooked = true
end

-- ===================================================================
-- Hooks
-- ===================================================================
local function should_open()
    if not (G and G.GAME and deck_active()) then return false end
    if not boss_beaten() then return false end
    if G.GAME.cbuf_slot_round == G.GAME.round then return false end   -- once per round
    if G.OVERLAY_MENU then return false end   -- never replace another overlay (e.g. the win screen)
    if SLOT.active then return false end
    -- The ante-8 boss ends the run with the win screen: skip the popup once for that boss.
    local rr = G.GAME.round_resets
    local ante, win = rr and rr.ante, G.GAME.win_ante
    if ante and win and ante > win and not G.GAME.cbuf_final_boss_seen then
        G.GAME.cbuf_final_boss_seen = true
        return false
    end
    return true
end

if type(G.FUNCS.evaluate_round) == 'function' and not G.FUNCS._cbuf_eval_wrapped then
    local eval_ref = G.FUNCS.evaluate_round
    G.FUNCS.evaluate_round = function(...)
        local ok_check, want = pcall(should_open)
        if ok_check and want then
            local args = { ... }
            local unpack_fn = unpack or table.unpack
            local ok, opened = pcall(open_popup, function() return eval_ref(unpack_fn(args)) end)
            if ok and opened then return end
            if not ok then
                log('error', 'popup failed, continuing without it: ' .. tostring(opened))
                SLOT.active = false
                if G.OVERLAY_MENU then pcall(G.FUNCS.exit_overlay_menu) end
            end
        end
        return eval_ref(...)
    end
    G.FUNCS._cbuf_eval_wrapped = true
else
    log('warn', 'G.FUNCS.evaluate_round not found, the Gambling Deck popup is disabled')
end

if type(G.FUNCS.exit_overlay_menu) == 'function' and not G.FUNCS._cbuf_exit_wrapped then
    local exit_ref = G.FUNCS.exit_overlay_menu
    G.FUNCS.exit_overlay_menu = function(...)
        local r = exit_ref(...)
        if SLOT.active then finish() end
        return r
    end
    G.FUNCS._cbuf_exit_wrapped = true
end

-- ===================================================================
-- The deck itself
-- ===================================================================
SMODS.Atlas {
    key = 'cbuf_slot_symbols',
    path = 'slot_symbols.png',
    px = 32,
    py = 32,
    disable_mipmap = true,
}

SMODS.Atlas {
    key = 'cbuf_lever',
    path = 'lever.png',
    px = 24,
    py = 40,
    disable_mipmap = true,
}

SMODS.Atlas {
    key = 'cbuf_gambling_deck',
    path = 'gambling_deck.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

SMODS.Back {
    key = 'gambling_deck',
    name = 'Gambling Deck',
    atlas = 'cbuf_gambling_deck',
    pos = { x = 0, y = 0 },
    unlocked = true,
    discovered = true,
    config = {},
    loc_txt = {
        name = 'Gambling Deck',
        text = {
            'After each {C:attention}Boss Blind{}, play the',
            '{C:attention}Slot Machine{} and gamble your',
            '{C:money}cash{}, {C:attention}interest cap{}, {C:attention}first hand{}',
            'or a {C:attention}Joker{}',
            '{s:0.85}Shop Slot: {s:0.85,C:money}$3{s:0.85} per pull',
        },
    },
    apply = function(self, back)
        G.GAME.cbuf_first_x = 1
        G.GAME.cbuf_slot_round = nil
    end,
    -- IMPORTANT: this function must NOT `return { xmult = ... }`. Steamodded answers a returned effect
    -- with a post_trigger context whose other_card is this Back object (no .ability), which crashed
    -- The Cracker Pack (main.lua:646). The effect is applied on a real scoring card instead.
    calculate = function(self, back, context)
        if not (context.final_scoring_step and G.GAME and G.GAME.current_round
            and G.GAME.current_round.hands_played == 0) then
            return
        end
        local x = to_num(G.GAME.cbuf_first_x or 1)
        if math.abs(x - 1) < 0.0001 then return end
        local card = (context.scoring_hand and context.scoring_hand[1])
            or (G.play and G.play.cards and G.play.cards[1])
        if card and card.ability and type(SMODS.calculate_effect) == 'function' then
            local ok, err = pcall(SMODS.calculate_effect, { xmult = x }, card)
            if ok then return end
            log('warn', 'calculate_effect failed, applying X Mult directly: ' .. tostring(err))
        end
        -- Last resort: change the running score directly. No effect table is returned, so other
        -- mods never see this deck as a "card".
        pcall(function()
            if type(mult) == 'number' and type(mod_mult) == 'function' then
                mult = mod_mult(mult * x)
                if type(update_hand_text) == 'function' then update_hand_text({ delay = 0 }, { mult = mult }) end
            end
        end)
    end,
}

log('info', 'loaded')
