-- Candy Buff — entry point (v1.26.8)
--
-- Steamodded (including the experimental 1.0.0~BETA-1814a build used by the Experimental
-- Multiplayer pack) runs this file once after reading CandyBuff.json. The real code lives
-- in candy_core.lua and is loaded through SMODS.load_file, the documented way to load a mod's
-- own files. If anything fails, the reason is written to the Lovely log
-- (Mods/lovely/log/*.log, search for "CandyBuff") before the error is re-raised, so the crash
-- screen/log always names the exact line instead of a silent "does not work".
local MOD = SMODS.current_mod

-- Mod icon shown in the Mods menu (assets/1x/icon.png 34x34, assets/2x/icon.png 68x68).
if SMODS.Atlas then
    SMODS.Atlas { key = 'modicon', path = 'icon.png', px = 34, py = 34 }
end

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] ' .. msg, 'CandyBuff') end
end

local function mod_state(id)
    local m = SMODS.Mods and SMODS.Mods[id]
    if not m then return 'not installed' end
    return (m.can_load and 'loaded ' or 'NOT loaded ') .. tostring(m.version or '?')
end

log('info', ('starting v%s | Steamodded %s | CardSleeves: %s | Cryptid: %s | Experimental MP: %s'):format(
    tostring(MOD and MOD.version or '?'),
    tostring(SMODS.version or 'unknown'),
    mod_state('CardSleeves'),
    mod_state('Cryptid'),
    mod_state('MultiplayerExperimental')))

if type(SMODS.load_file) ~= 'function' then
    log('error', 'SMODS.load_file is missing: this Steamodded build is too old.')
    error('CandyBuff: SMODS.load_file is missing (Steamodded too old).')
end

local chunk, load_err = SMODS.load_file('candy_core.lua')
if not chunk then
    log('error', 'cannot read/compile candy_core.lua: ' .. tostring(load_err))
    error('CandyBuff: ' .. tostring(load_err))
end

local ok, run_err = xpcall(chunk, function(e) return debug.traceback(tostring(e), 2) end)
if not ok then
    log('error', 'failed while loading candy_core.lua:\n' .. tostring(run_err))
    error('CandyBuff failed to load (details in the Lovely log, search "CandyBuff"):\n' .. tostring(run_err), 0)
end

-- Gambling Deck (v1.26.29). Loaded separately and never allowed to stop the rest of the mod:
-- if it fails, the reason goes to the Lovely log (search "CandyBuff") and the other content still loads.
do
    local g_chunk, g_err = SMODS.load_file('gambling_deck.lua')
    if not g_chunk then
        log('error', 'cannot read/compile gambling_deck.lua: ' .. tostring(g_err))
    else
        local g_ok, g_run_err = xpcall(g_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not g_ok then log('error', 'gambling_deck.lua failed:\n' .. tostring(g_run_err)) end
    end
end

-- Sealed sticker + The Keeper spectral (v1.26.29), isolated the same way.
do
    local s_chunk, s_err = SMODS.load_file('sealed.lua')
    if not s_chunk then
        log('error', 'cannot read/compile sealed.lua: ' .. tostring(s_err))
    else
        local s_ok, s_run_err = xpcall(s_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not s_ok then log('error', 'sealed.lua failed:\n' .. tostring(s_run_err)) end
    end
end

-- Sagatro content (v1.26.33): only does anything when Sagatro is installed. Isolated the same way.
do
    local g_chunk, g_err = SMODS.load_file('sagatro.lua')
    if not g_chunk then
        log('error', 'cannot read/compile sagatro.lua: ' .. tostring(g_err))
    else
        local g_ok, g_run_err = xpcall(g_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not g_ok then log('error', 'sagatro.lua failed:\n' .. tostring(g_run_err)) end
    end
end

-- Booster packs (v1.26.29), isolated the same way.
do
    local p_chunk, p_err = SMODS.load_file('packs.lua')
    if not p_chunk then
        log('error', 'cannot read/compile packs.lua: ' .. tostring(p_err))
    else
        local p_ok, p_run_err = xpcall(p_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not p_ok then log('error', 'packs.lua failed:\n' .. tostring(p_run_err)) end
    end
end

-- Thenik (Epic Joker), the "Thenik's" sticker and the Epic wave background (v1.26.35), isolated the same way.
do
    local t_chunk, t_err = SMODS.load_file('thenik.lua')
    if not t_chunk then
        log('error', 'cannot read/compile thenik.lua: ' .. tostring(t_err))
    else
        local t_ok, t_run_err = xpcall(t_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not t_ok then log('error', 'thenik.lua failed:\n' .. tostring(t_run_err)) end
    end
end

-- Nol Had (Epic Joker, v1.26.36), isolated the same way.
do
    local n_chunk, n_err = SMODS.load_file('nolhad.lua')
    if not n_chunk then
        log('error', 'cannot read/compile nolhad.lua: ' .. tostring(n_err))
    else
        local n_ok, n_run_err = xpcall(n_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not n_ok then log('error', 'nolhad.lua failed:\n' .. tostring(n_run_err)) end
    end
end

-- Roundy (Rare Joker, v1.26.42), isolated the same way.
do
    local r_chunk, r_err = SMODS.load_file('roundy.lua')
    if not r_chunk then
        log('error', 'cannot read/compile roundy.lua: ' .. tostring(r_err))
    else
        local r_ok, r_run_err = xpcall(r_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not r_ok then log('error', 'roundy.lua failed:\n' .. tostring(r_run_err)) end
    end
end

-- Scratchy (Uncommon Joker, v1.26.50), isolated the same way.
do
    local s_chunk, s_err = SMODS.load_file('scratchy.lua')
    if not s_chunk then
        log('error', 'cannot read/compile scratchy.lua: ' .. tostring(s_err))
    else
        local s_ok, s_run_err = xpcall(s_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not s_ok then log('error', 'scratchy.lua failed:\n' .. tostring(s_run_err)) end
    end
end

-- Peven Steven (Common Joker, v1.26.50), isolated the same way.
do
    local p_chunk, p_err = SMODS.load_file('peven.lua')
    if not p_chunk then
        log('error', 'cannot read/compile peven.lua: ' .. tostring(p_err))
    else
        local p_ok, p_run_err = xpcall(p_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not p_ok then log('error', 'peven.lua failed:\n' .. tostring(p_run_err)) end
    end
end

-- Old Couch Card (Uncommon Joker, v1.26.51), isolated the same way.
do
    local c_chunk, c_err = SMODS.load_file('couch.lua')
    if not c_chunk then
        log('error', 'cannot read/compile couch.lua: ' .. tostring(c_err))
    else
        local c_ok, c_run_err = xpcall(c_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not c_ok then log('error', 'couch.lua failed:\n' .. tostring(c_run_err)) end
    end
end

-- Candle (Uncommon Joker) + Hot Wax Seal (v1.26.62), isolated the same way.
do
    local k_chunk, k_err = SMODS.load_file('candle.lua')
    if not k_chunk then
        log('error', 'cannot read/compile candle.lua: ' .. tostring(k_err))
    else
        local k_ok, k_run_err = xpcall(k_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not k_ok then log('error', 'candle.lua failed:\n' .. tostring(k_run_err)) end
    end
end

-- Menlod's Capsule (Uncommon Joker, v1.26.62), isolated the same way.
do
    local m_chunk, m_err = SMODS.load_file('menlod.lua')
    if not m_chunk then
        log('error', 'cannot read/compile menlod.lua: ' .. tostring(m_err))
    else
        local m_ok, m_run_err = xpcall(m_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not m_ok then log('error', 'menlod.lua failed:\n' .. tostring(m_run_err)) end
    end
end

-- Unlucky Cliff (Uncommon Joker, v1.26.62), isolated the same way.
do
    local u_chunk, u_err = SMODS.load_file('unlucky.lua')
    if not u_chunk then
        log('error', 'cannot read/compile unlucky.lua: ' .. tostring(u_err))
    else
        local u_ok, u_run_err = xpcall(u_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not u_ok then log('error', 'unlucky.lua failed:\n' .. tostring(u_run_err)) end
    end
end

-- Test Your Luck deck (v1.26.62), isolated the same way.
do
    local l_chunk, l_err = SMODS.load_file('luck_deck.lua')
    if not l_chunk then
        log('error', 'cannot read/compile luck_deck.lua: ' .. tostring(l_err))
    else
        local l_ok, l_run_err = xpcall(l_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not l_ok then log('error', 'luck_deck.lua failed:\n' .. tostring(l_run_err)) end
    end
end

-- Joker of Luck packs (v1.26.64) and Oops! All 6s Perishable + Rare (v1.26.68), isolated the same way. They load AFTER the Test Your Luck deck.
for _, name in ipairs({ 'luck_pack.lua', 'oops.lua', 'golden_seals.lua', 'pumpkin.lua', 'gym.lua', 'meat.lua', 'rubble.lua', 'files.lua', 'safety.lua' }) do
    local x_chunk, x_err = SMODS.load_file(name)
    if not x_chunk then
        log('error', 'cannot read/compile ' .. name .. ': ' .. tostring(x_err))
    else
        local x_ok, x_run_err = xpcall(x_chunk, function(e) return debug.traceback(tostring(e), 2) end)
        if not x_ok then log('error', name .. ' failed:\n' .. tostring(x_run_err)) end
    end
end

log('info', 'loaded OK')
