-- Candy Buff — Old Couch Card (Uncommon Joker) (v1.26.53)
--
--   * Takes no Joker slot (it adds one slot while you own it, like a Negative Joker, and can be bought
--     or picked from a pack even when your Joker slots are full). Shown as a "Takes 0 slots" box, like Negative.
--   * End of round: +$1 for each other Joker that carries a sticker (Eternal, Perishable, Rental and the
--     stickers of this mod and others), up to $5.
--   * When sold: removes every sticker from all your other Jokers.
--     It pays you for your stickers while you hold it, and cleans them up when you let it go.
--   * Every sticker removed this way makes the NEXT copies of the card cost $1 more for the rest of the run
--     (G.GAME.cbuf_couch_removed).
--
-- Safety: all hooks are inside pcall; failures go to the Lovely log (search "CandyBuff couch").

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] couch: ' .. msg, 'CandyBuff') end
end

local jd = _G.CBUF_API and _G.CBUF_API.jd   -- JokerDisplay helper from candy_core.lua

local KEY = 'j_cbuf_couch'
local PAY_EACH = 1
local PAY_MAX = 5

-- Every sticker key we know: the registered ones (vanilla Eternal / Perishable / Rental included).
local function sticker_keys()
    local keys, seen = {}, {}
    if SMODS and type(SMODS.Stickers) == 'table' then
        for k in pairs(SMODS.Stickers) do keys[#keys + 1] = k; seen[k] = true end
    end
    for _, k in ipairs({ 'eternal', 'perishable', 'rental' }) do
        if not seen[k] then keys[#keys + 1] = k end
    end
    return keys
end

local function has_sticker(card)
    local ab = card and card.ability
    if not ab then return false end
    for _, k in ipairs(sticker_keys()) do
        if ab[k] then return true end
    end
    return false
end

local function other_jokers(self_card)
    local list = {}
    if G and G.jokers and G.jokers.cards then
        for _, c in ipairs(G.jokers.cards) do
            if c ~= self_card then list[#list + 1] = c end
        end
    end
    return list
end

local function count_stickered(self_card)
    local n = 0
    for _, c in ipairs(other_jokers(self_card)) do
        if has_sticker(c) then n = n + 1 end
    end
    return n
end

local function strip_stickers(card)
    local removed = 0
    for _, k in ipairs(sticker_keys()) do
        if card.ability[k] then
            local done = false
            if type(card.remove_sticker) == 'function' then
                done = pcall(card.remove_sticker, card, k)
            end
            card.ability[k] = nil            -- also covers older Steamodded without remove_sticker
            removed = removed + 1
        end
    end
    if removed > 0 then
        card.ability.cbuf_spoiled_tally = nil
        card.ability.cbuf_spoiled_round = nil
        card.ability.cbuf_spoiled_rotten = nil
        card.ability.cbuf_glass_round = nil
        card.ability.cbuf_glass_breaking = nil
        pcall(function() card:set_cost() end)
        pcall(function()
            if SMODS and type(SMODS.recalc_debuff) == 'function' then SMODS.recalc_debuff(card) end
        end)
        pcall(function() card:juice_up(0.6, 0.6) end)
    end
    return removed
end

-- Info box next to the card (like Negative's): title "Old Couch", text "Takes 0 Joker slots".
local function install_loc()
    local ok = pcall(function()
        local loc = G and G.localization
        if not (loc and loc.descriptions) then return end
        loc.descriptions.Other = loc.descriptions.Other or {}
        local cur = loc.descriptions.Other.cbuf_couch_slot
        if cur and cur.text_parsed and cur.name_parsed then return end
        local entry = { name = 'Old Couch', text = { 'Takes {C:attention}0{} Joker slots' } }
        -- localize() reads the *_parsed tables, which the game only builds for entries that exist
        -- when it loads the language, so build them here (without them it crashes with "ipairs nil").
        if type(loc_parse_string) ~= 'function' then return end
        entry.name_parsed = { loc_parse_string(entry.name) }
        entry.text_parsed = {}
        for _, line in ipairs(entry.text) do
            entry.text_parsed[#entry.text_parsed + 1] = loc_parse_string(line)
        end
        loc.descriptions.Other.cbuf_couch_slot = entry
    end)
    return ok
end
install_loc()
if type(init_localization) == 'function' and not _G._cbuf_couch_loc then
    local ref = init_localization
    function init_localization(...)
        local r = ref(...)
        install_loc()
        return r
    end
    _G._cbuf_couch_loc = true
end

local function removed_total()
    return (G and G.GAME and G.GAME.cbuf_couch_removed) or 0
end

local function is_couch(card)
    return card and card.config and card.config.center and card.config.center.key == KEY
end

-- 71x95 card art (one static frame)
SMODS.Atlas { key = 'cbuf_couch', path = 'cbuf_couch.png', px = 71, py = 95, disable_mipmap = true }

SMODS.Joker {
    key = 'couch',
    atlas = 'cbuf_couch',
    pos = { x = 0, y = 0 },
    rarity = 2,
    cost = 5,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = { each = PAY_EACH, max = PAY_MAX } },
    -- JokerDisplay support (only used when the JokerDisplay mod is installed).
    joker_display_def = jd and jd('j_cbuf_couch', function(JokerDisplay)
        return {
            text = {
                { text = '$' },
                { ref_table = 'card.joker_display_values', ref_value = 'pay' },
            },
            text_config = { colour = G.C.GOLD },
            reminder_text = { { text = '(stickers)' } },
            calc_function = function(card)
                local n = math.min(PAY_MAX, count_stickered(card) * PAY_EACH)
                card.joker_display_values.pay = tostring(n)
            end,
        }
    end) or nil,
    loc_txt = {
        name = 'Old Couch Card',
        text = {
            '{C:money}+$#1#{} at end of round for each other',
            'Joker with a {C:attention}sticker{} (max {C:money}$#2#{})',
            'When sold, removes {C:attention}all stickers{} from your Jokers,',
            'each one makes the next copy cost {C:money}$1{} more',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = card.ability and card.ability.extra or {}
        -- only add the box when its text is really loaded (a missing entry would crash localize)
        local ent = G and G.localization and G.localization.descriptions
            and G.localization.descriptions.Other and G.localization.descriptions.Other.cbuf_couch_slot
        if ent and ent.text_parsed and ent.name_parsed then
            info_queue[#info_queue + 1] = { set = 'Other', key = 'cbuf_couch_slot' }
        end
        return { vars = { ex.each or PAY_EACH, ex.max or PAY_MAX } }
    end,
    -- no slot: +1 Joker slot while owned
    add_to_deck = function(self, card, from_debuff)
        if from_debuff or card.ability.cbuf_couch_slot then return end
        if G and G.jokers and G.jokers.config then
            G.jokers.config.card_limit = G.jokers.config.card_limit + 1
            card.ability.cbuf_couch_slot = true
        end
    end,
    remove_from_deck = function(self, card, from_debuff)
        if from_debuff or not card.ability.cbuf_couch_slot then return end
        if G and G.jokers and G.jokers.config then
            G.jokers.config.card_limit = G.jokers.config.card_limit - 1
            card.ability.cbuf_couch_slot = nil
        end
    end,
    calc_dollar_bonus = function(self, card)
        local ex = card.ability.extra or {}
        local n = math.min(ex.max or PAY_MAX, count_stickered(card) * (ex.each or PAY_EACH))
        if n > 0 then return n end
    end,
    calculate = function(self, card, context)
        if context.selling_self and not context.blueprint then
            local total = 0
            for _, c in ipairs(other_jokers(card)) do
                local ok, n = pcall(strip_stickers, c)
                if ok then total = total + (n or 0) end
            end
            if total > 0 and G and G.GAME then
                G.GAME.cbuf_couch_removed = removed_total() + total
                -- copies already in the shop get the new price right away
                pcall(function()
                    for _, area in ipairs({ G.shop_jokers, G.shop_booster }) do
                        if area and area.cards then
                            for _, c in ipairs(area.cards) do
                                if is_couch(c) then c:set_cost() end
                            end
                        end
                    end
                end)
            end
            if total > 0 and card_eval_status_text and G and G.C then
                pcall(card_eval_status_text, card, 'extra', nil, nil, nil,
                    { message = 'Cleaned!', colour = G.C.GREEN })
            end
        end
    end,
}

-- Price: +$1 per sticker this run's Old Couch Cards have removed, on every copy that is not yet owned.
if Card and type(Card.set_cost) == 'function' and not Card._cbuf_couch_cost then
    local ref = Card.set_cost
    function Card:set_cost(...)
        local r = ref(self, ...)
        if is_couch(self) and not self.added_to_deck then
            local extra = removed_total()
            if extra > 0 and type(self.cost) == 'number' then self.cost = self.cost + extra end
        end
        return r
    end
    Card._cbuf_couch_cost = true
end

-- Buying it (shop) or picking it (pack) never needs a free Joker slot.
if G and G.FUNCS and type(G.FUNCS.check_for_buy_space) == 'function' and not G.FUNCS._cbuf_couch_buy then
    local ref = G.FUNCS.check_for_buy_space
    G.FUNCS.check_for_buy_space = function(card, ...)
        if is_couch(card) then return true end
        return ref(card, ...)
    end
    G.FUNCS._cbuf_couch_buy = true
else
    log('warn', 'check_for_buy_space not found: it needs a free Joker slot to buy')
end

if G and G.FUNCS and type(G.FUNCS.can_select_card) == 'function' and not G.FUNCS._cbuf_couch_select then
    local ref = G.FUNCS.can_select_card
    G.FUNCS.can_select_card = function(e, ...)
        local res = ref(e, ...)
        local card = e and e.config and e.config.ref_table
        if is_couch(card) then
            e.config.colour = G.C.GREEN
            e.config.button = 'use_card'
        end
        return res
    end
    G.FUNCS._cbuf_couch_select = true
end

log('info', 'loaded')
