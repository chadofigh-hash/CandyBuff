-- Candy Buff — Peven Steven (Common Joker) (v1.26.53)
--
--   * Every played card of even rank (2, 4, 6, 8, 10) gives +4 Pult when it scores.
--   * "Pult" is purple Mult: it is added to the hand's Mult and shown in purple.
--
-- Safety: failures go to the Lovely log (search "CandyBuff peven").

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] peven: ' .. msg, 'CandyBuff') end
end

local jd = _G.CBUF_API and _G.CBUF_API.jd   -- JokerDisplay helper from candy_core.lua

local PULT = 4
local PURPLE = HEX and HEX('8E30B3') or (G and G.C and G.C.PURPLE)

local EVEN_RANKS = { [2] = true, [4] = true, [6] = true, [8] = true, [10] = true }

local function is_even(card)
    if not card or not card.get_id then return false end
    if SMODS and SMODS.has_no_rank and SMODS.has_no_rank(card) then return false end   -- Stone cards
    local ok, id = pcall(card.get_id, card)
    return ok and EVEN_RANKS[id] == true
end

-- 71x95 card art (one static frame)
SMODS.Atlas { key = 'cbuf_peven', path = 'cbuf_peven.png', px = 71, py = 95, disable_mipmap = true }

SMODS.Joker {
    key = 'peven',
    atlas = 'cbuf_peven',
    pos = { x = 0, y = 0 },
    rarity = 1,
    cost = 4,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = { pult = PULT } },
    -- JokerDisplay support (only used when the JokerDisplay mod is installed).
    joker_display_def = jd and jd('j_cbuf_peven', function(JokerDisplay)
        return {
            text = {
                { text = '+' },
                { ref_table = 'card.joker_display_values', ref_value = 'pult' },
            },
            text_config = { colour = PURPLE },
            reminder_text = { { text = '(2,4,6,8,10)' } },
            calc_function = function(card)
                local count = 0
                local ok, hand = pcall(function() return JokerDisplay.current_hand end)
                if ok and type(hand) == 'table' then
                    for _, c in ipairs(hand) do if is_even(c) then count = count + 1 end end
                end
                card.joker_display_values.pult = tostring(count * PULT)
            end,
        }
    end) or nil,
    loc_txt = {
        name = 'Peven Steven',
        text = {
            'Played cards with',
            '{C:attention}even{} rank give',
            '{X:purple,C:white}+#1#{} {C:purple}Pult{} when scored',
            '{C:inactive}(2, 4, 6, 8, 10){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = card.ability and card.ability.extra or {}
        return { vars = { ex.pult or PULT } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and is_even(context.other_card) then
            local amount = card.ability.extra and card.ability.extra.pult or PULT
            return {
                mult = amount,
                remove_default_message = true,   -- show the purple "Pult" text instead of the red Mult text
                message = '+' .. amount .. ' Pult',
                colour = PURPLE,
                message_card = context.other_card,
            }
        end
    end,
}

log('info', 'loaded')
