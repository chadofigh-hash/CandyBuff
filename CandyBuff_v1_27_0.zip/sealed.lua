-- Candy Buff — "Sealed" sticker and "The Keeper" spectral card (v1.26.21)
--
-- Sealed (sticker, Jokers and playing cards): nothing the card has earned is ever lost.
--   * Jokers: a tiny COUNTER, written in the sticker description (Chips / Mult / X Mult / X Chips / Retriggers). Whenever a
--     Joker's own scoring value drops (a reset like Ride the Bus, or a decay like Popcorn), the amount it
--     lost is added to the counter instead of disappearing, and the counter is scored every hand with
--     the Joker. Only a short fixed list of fields is watched (mult, chips, x_mult, h_mult ... at the top
--     of `ability` and of `ability.extra`, including s_mult / s_chips, x_chips and retrigger counts), checked once right after the Joker's own calculation. There is
--     no per-frame work and no tree walking, so no lag; unknown fields and Talisman big numbers are
--     simply ignored.
--   * Jokers that work their value out from the game instead of storing it (Blue Joker: cards left in the
--     deck, Banner: discards left) are measured from the game state: what they lose during the round is
--     banked when they score.
--   * Stacked X mult from kept editions / enhancements is ADDITIVE (1 + (a-1) + (b-1) ...), so many
--     layers never multiply into a run-breaking number. There is no limit on the number of layers.
--   * Editions: when a Sealed card gets a new edition, the old one is kept and keeps working (stacks).
--   * Playing cards: enhancements and seals that get replaced or removed are kept and keep working too
--     (chips / mult / X mult / held effects, Gold $, Red retrigger, Blue planet, Purple tarot).
-- The Keeper (Spectral): puts Sealed on 1, 2 or 3 random held cards or Jokers.
--
-- Safety: every hook and every calculation is inside pcall. A failure is written to the Lovely log
-- (search "CandyBuff sealed") and the card simply stops doing that part, it never crashes the run.
-- The stored state lives in card.ability.cbuf_sealed (saved with the run).

local MOD = SMODS.current_mod

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] sealed: ' .. msg, 'CandyBuff') end
end

local KEY = 'cbuf_sealed'          -- card.ability key (mod prefix + sticker key)
local NEW_CALC = type(SMODS.calculate_main_scoring) == 'function'   -- new Steamodded scoring contexts

-- ===================================================================
-- Atlases
-- ===================================================================
SMODS.Atlas { key = 'cbuf_sealed', path = 'cbuf_sealed.png', px = 71, py = 95, disable_mipmap = true }
SMODS.Atlas { key = 'cbuf_keeper', path = 'cbuf_keeper.png', px = 71, py = 95, disable_mipmap = true }

-- ===================================================================
-- Stored state helpers
-- ===================================================================
local function new_state()
    return { kc = 0, km = 0, kx = 0, kxc = 0, kr = 0, snap = {}, enh = {}, ed = {}, seal = {} }
end

local function state_of(card)
    local ab = card and card.ability
    local st = ab and ab[KEY]
    if type(st) ~= 'table' then return nil end
    st.snap = st.snap or {}
    st.kc = st.kc or 0
    st.km = st.km or 0
    st.kx = st.kx or 0
    st.kxc = st.kxc or 0
    st.kr = st.kr or 0
    st.enh = st.enh or {}
    st.ed = st.ed or {}
    st.seal = st.seal or {}
    return st
end

local function push(list, v)
    if v == nil then return end
    list[#list + 1] = v
end

local function layer_count(st)
    return #st.enh + #st.ed + #st.seal
end

-- ===================================================================
-- The sticker
-- ===================================================================
local EDITION_SKIP = { e_base = true, e_negative = true }       -- negative only adds a slot, nothing to stack

local function center_cfg(key)
    local c = G and G.P_CENTERS and G.P_CENTERS[key]
    return c and c.config or nil
end

local function num(v) return type(v) == 'number' and v or 0 end

-- chips / mult / x_mult stored in the editions that were replaced
-- returns chips, mult and the X mult BONUS (0 = nothing). X mult layers add up: x = 1 + bonus.
local function edition_sum(st)
    local chips, mult, xb = 0, 0, 0
    for _, key in ipairs(st.ed) do
        local c = center_cfg(key)
        if c and not EDITION_SKIP[key] then
            chips = chips + num(c.chips)
            mult = mult + num(c.mult)
            local xm = c.x_mult or c.Xmult or c.x_mult_mod
            if type(xm) == 'number' and xm > 1 then xb = xb + (xm - 1) end
        end
    end
    return chips, mult, xb
end

-- the counter of a Joker: banked losses + kept editions.
-- returns chips, mult, X mult BONUS, X chips BONUS (0 = nothing), retriggers
local function joker_totals(st)
    local ec, em, ex = edition_sum(st)
    return (st.kc or 0) + ec, (st.km or 0) + em, (st.kx or 0) + ex, (st.kxc or 0), (st.kr or 0)
end

-- numbers shown in the description (never random: a kept Lucky is left out)
local function display_totals(card)
    local st = state_of(card)
    if not st then return 0, 0, 0, 0, 0 end
    if card.ability.set == 'Joker' then return joker_totals(st) end
    local chips, mult, xb = edition_sum(st)
    local reps = 0
    for _, key in ipairs(st.enh) do
        local c = center_cfg(key)
        if c then
            chips = chips + num(c.bonus)
            if key ~= 'm_lucky' then mult = mult + num(c.mult) end
            local xm = c.Xmult or c.x_mult
            if type(xm) == 'number' and xm > 1 then xb = xb + (xm - 1) end
        end
    end
    for _, seal in ipairs(st.seal) do if seal == 'Red' then reps = reps + 1 end end
    return chips, mult, xb, 0, reps
end

-- Jokers whose value is not stored in a field but worked out from the game (Blue Joker = cards left in
-- the deck, Banner = discards left). Their loss is measured from the game state: a baseline is taken when
-- the blind starts, and every time the Joker scores, whatever it has lost since is added to the counter.
local function deck_count() return (G and G.deck and G.deck.cards and #G.deck.cards) or 0 end
local function per(card, default)
    local e = card.ability and card.ability.extra
    return type(e) == 'number' and e or default
end
local DYNAMIC = {
    j_blue_joker = function(card) return 'c', per(card, 2) * deck_count() end,
    j_banner = function(card)
        local d = G and G.GAME and G.GAME.current_round and G.GAME.current_round.discards_left or 0
        return 'c', per(card, 30) * d
    end,
}

local function bank_dynamic(card, st, at_start)
    local center = card.config and card.config.center
    local fn = center and DYNAMIC[center.key]
    if not fn then return end
    local kind, cur = fn(card)
    if type(cur) ~= 'number' then return end
    local snap = st.snap.dyn
    if at_start or snap == nil or cur > snap then
        st.snap.dyn = cur
    elseif cur < snap then
        local lost = snap - cur
        if kind == 'c' then st.kc = st.kc + lost else st.km = st.km + lost end
        st.snap.dyn = cur
    end
end

local function fmt(v)
    v = math.floor((tonumber(v) or 0) * 100 + 0.5) / 100
    return tostring(v)
end

local function add_consumable(set_name, key)
    if not (G and G.consumeables and G.GAME) then return false end
    local buffer = G.GAME.consumeable_buffer or 0
    if #G.consumeables.cards + buffer >= (G.consumeables.config.card_limit or 2) then return false end
    G.GAME.consumeable_buffer = buffer + 1
    G.E_MANAGER:add_event(Event({
        trigger = 'before', delay = 0.0,
        func = function()
            local ok, err = pcall(function()
                if key then
                    SMODS.add_card({ key = key })
                else
                    SMODS.add_card({ set = set_name, key_append = 'cbuf_sealed' })
                end
            end)
            if not ok then log('warn', 'seal consumable failed: ' .. tostring(err)) end
            G.GAME.consumeable_buffer = 0
            return true
        end,
    }))
    return true
end

local function last_hand_planet()
    local hand = G and G.GAME and G.GAME.last_hand_played
    if not hand or not (G.P_CENTER_POOLS and G.P_CENTER_POOLS.Planet) then return nil end
    for _, v in pairs(G.P_CENTER_POOLS.Planet) do
        if v.config and v.config.hand_type == hand then return v.key end
    end
    return nil
end

-- 1 in `odds` roll that respects probability modifiers (Oops! All 6s) on new and old Steamodded
local function lucky_roll(card, seed, odds)
    if SMODS and type(SMODS.pseudorandom_probability) == 'function' then
        local ok, r = pcall(SMODS.pseudorandom_probability, card, seed, 1, odds, seed)
        if ok then return r and true or false end
    end
    local mult = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return pseudorandom(seed) < mult / odds
end

local function sealed_calc(card, context)
    local st = state_of(card)
    if not st then return nil end
    local ab = card.ability
    if ab.set ~= 'Joker' and layer_count(st) == 0 then return nil end
    local ret = {}
    local function add(k, v)
        if v == nil or v == 0 then return end
        ret[k] = (ret[k] or 0) + v
    end
    local any = false

    -- ---- Jokers: the counter (banked losses + kept editions)
    if ab.set == 'Joker' then
        if context.setting_blind then
            pcall(bank_dynamic, card, st, true)
        elseif context.joker_main then
            pcall(bank_dynamic, card, st, false)
            local chips, mult, xb, xcb = joker_totals(st)
            if chips ~= 0 then add('chips', chips); any = true end
            if mult ~= 0 then add('mult', mult); any = true end
            if xb > 0 then ret.x_mult = 1 + xb; any = true end
            if xcb > 0 then ret.xchips = 1 + xcb; any = true end
        elseif context.repetition and context.cardarea == G.play then
            -- banked retriggers: every played card is retriggered that many more times
            local reps = math.floor(st.kr or 0)
            if reps > 0 then
                return { repetitions = reps, message = (type(localize) == 'function' and localize('k_again_ex')) or 'Again!' }
            end
        end
        return any and ret or nil
    end

    -- ---- Playing cards
    local scoring = NEW_CALC and context.main_scoring or (not NEW_CALC and context.individual)
    if scoring and context.cardarea == G.play then
        local chips, mult, xb = edition_sum(st)
        for _, key in ipairs(st.enh) do
            local c = center_cfg(key)
            if c then
                chips = chips + num(c.bonus)
                if key == 'm_lucky' then
                    -- Lucky effect without being a Lucky card: no lucky_trigger, so Lucky Cat and friends ignore it
                    if lucky_roll(card, 'cbuf_sealed_lucky_mult', 5) then mult = mult + num(c.mult) end
                    if lucky_roll(card, 'cbuf_sealed_lucky_money', 15) then add('dollars', num(c.p_dollars)); any = true end
                else
                    mult = mult + num(c.mult)
                end
                local xm = c.Xmult or c.x_mult
                if type(xm) == 'number' and xm > 1 then xb = xb + (xm - 1) end
            end
        end
        for _, seal in ipairs(st.seal) do
            if seal == 'Gold' then add('dollars', 3); any = true end
        end
        if chips ~= 0 then add('chips', chips); any = true end
        if mult ~= 0 then add('mult', mult); any = true end
        if xb > 0 then ret.x_mult = 1 + xb; any = true end
        return any and ret or nil
    end

    -- held in hand (Steel, Gold card style effects of the kept enhancements)
    local held = ((NEW_CALC and context.main_scoring) or (not NEW_CALC and context.individual))
        and context.cardarea == G.hand and not context.end_of_round
    if held then
        local xb = 0
        for _, key in ipairs(st.enh) do
            local c = center_cfg(key)
            if c then
                add('chips', num(c.h_chips))
                add('mult', num(c.h_mult))
                if type(c.h_x_mult) == 'number' and c.h_x_mult > 1 then xb = xb + (c.h_x_mult - 1) end
            end
        end
        if xb > 0 then ret.x_mult = 1 + xb end
        return next(ret) and ret or nil
    end

    -- Red seals kept: retrigger when played
    if context.repetition and context.cardarea == G.play then
        local n = 0
        for _, seal in ipairs(st.seal) do if seal == 'Red' then n = n + 1 end end
        if n > 0 then
            return { repetitions = n, message = (type(localize) == 'function' and localize('k_again_ex')) or 'Again!' }
        end
        return nil
    end

    -- end of round, card held in hand: Gold-style $ and Blue seals
    if context.end_of_round and context.individual and context.cardarea == G.hand then
        for _, key in ipairs(st.enh) do
            local c = center_cfg(key)
            if c then add('dollars', num(c.h_dollars)) end
        end
        for _, seal in ipairs(st.seal) do
            if seal == 'Blue' then add_consumable('Planet', last_hand_planet()) end
        end
        return next(ret) and ret or nil
    end

    -- Purple seals kept: discarding the card makes a Tarot
    if context.discard and context.other_card == card then
        for _, seal in ipairs(st.seal) do
            if seal == 'Purple' then add_consumable('Tarot', nil) end
        end
    end
    return nil
end

SMODS.Sticker {
    key = 'sealed',
    atlas = 'cbuf_sealed',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('4F7FD6'),
    rate = 0,
    needs_enable_flag = false,
    default_compat = true,
    sets = { Joker = true, Default = true, Enhanced = true },
    loc_txt = {
        name = 'Sealed',
        label = 'Sealed',
        text = {
            'Nothing is ever lost: losses',
            'are {C:attention}kept{}, layers {C:attention}stack{}',
            'Kept: {C:chips}+#1#{} Chips, {C:mult}+#2#{} Mult',
            '{X:mult,C:white} X#3# {} Mult, {X:chips,C:white} X#4# {} Chips',
            '{C:attention}+#5#{} Retriggers',
        },
    },
    loc_vars = function(self, info_queue, card)
        local c, m, x, xc, r = 0, 0, 0, 0, 0
        if card and card.ability then
            local ok, a1, a2, a3, a4, a5 = pcall(display_totals, card)
            if ok then c, m, x, xc, r = a1, a2, a3, a4, a5 end
        end
        return { vars = { fmt(c), fmt(m), fmt(1 + x), fmt(1 + xc), fmt(math.floor(r)) } }
    end,
    apply = function(self, card, val)
        if val then
            if type(card.ability[KEY]) ~= 'table' then card.ability[KEY] = new_state() end
        else
            card.ability[KEY] = nil
        end
    end,
    calculate = function(self, card, context)
        local ok, res = pcall(sealed_calc, card, context)
        if ok then return res end
        log('error', 'calculate failed: ' .. tostring(res))
        return nil
    end,
}

-- ===================================================================
-- Jokers: a loss is banked in the counter
-- ===================================================================
-- Fixed short list of fields (kind: c = chips, m = mult, x = X mult, xc = X chips, r = retriggers). Checked at the top of `ability`
-- and of `ability.extra`. Everything else is ignored on purpose (cheap and cannot crash).
local TRACK = {
    { 'mult', 'm' }, { 'h_mult', 'm' }, { 't_mult', 'm' }, { 's_mult', 'm' }, { 'current_mult', 'm' },
    { 'chips', 'c' }, { 'h_chips', 'c' }, { 't_chips', 'c' }, { 's_chips', 'c' }, { 'current_chips', 'c' },
    { 'x_mult', 'x' }, { 'xmult', 'x' }, { 'Xmult', 'x' }, { 'current_xmult', 'x' },
    { 'x_chips', 'xc' }, { 'xchips', 'xc' }, { 'Xchips', 'xc' },
    { 'repetitions', 'r' }, { 'retriggers', 'r' }, { 'retrigger', 'r' },
}

local function bank_scan(st, tbl, prefix)
    local snap = st.snap
    for i = 1, #TRACK do
        local k, kind = TRACK[i][1], TRACK[i][2]
        local v = tbl[k]
        if type(v) == 'number' then
            local id = prefix .. k
            local old = snap[id]
            if old == nil or v > old then
                snap[id] = v                          -- first look, or it grew: just remember it
            elseif v < old - 1e-9 then
                local lost = old - v                  -- it dropped: bank what was lost
                if kind == 'c' then st.kc = st.kc + lost
                elseif kind == 'm' then st.km = st.km + lost
                elseif kind == 'xc' then st.kxc = st.kxc + lost
                elseif kind == 'r' then st.kr = st.kr + lost
                else st.kx = st.kx + lost end
                snap[id] = v
            end
        end
    end
end

local function bank_joker(card)
    local st = state_of(card)
    if not st then return end
    local ab = card.ability
    bank_scan(st, ab, 't.')
    if type(ab.extra) == 'table' then bank_scan(st, ab.extra, 'e.') end
end

-- Right after a Joker's own calculation (that is when resets and decays happen).
if Card and type(Card.calculate_joker) == 'function' and not Card._cbuf_sealed_calc then
    local calc_ref = Card.calculate_joker
    Card.calculate_joker = function(self, ...)
        local r1, r2 = calc_ref(self, ...)
        local ab = self.ability
        if ab and ab[KEY] and ab.set == 'Joker' then pcall(bank_joker, self) end
        return r1, r2
    end
    Card._cbuf_sealed_calc = true
end

-- ===================================================================
-- History hooks: remember what a Sealed card loses
-- ===================================================================
if Card and type(Card.set_ability) == 'function' and not Card._cbuf_sealed_set_ability then
    local ref = Card.set_ability
    Card.set_ability = function(self, center, initial, ...)
        local keep = self.ability and self.ability[KEY]
        if keep and not initial then
            pcall(function()
                local old = self.config and self.config.center
                local new_key = type(center) == 'table' and center.key or center
                if old and old.set == 'Enhanced' and old.key ~= 'c_base' and old.key ~= new_key then
                    local st = state_of(self)
                    if st then push(st.enh, old.key) end
                end
            end)
        end
        local r = ref(self, center, initial, ...)
        if keep and self.ability and self.ability[KEY] == nil then self.ability[KEY] = keep end   -- the new ability table is rebuilt from scratch
        return r
    end
    Card._cbuf_sealed_set_ability = true
end

local function edition_key(e)
    if type(e) == 'string' then return e end
    if type(e) ~= 'table' then return nil end
    if e.key then return e.key end
    if e.type then return 'e_' .. tostring(e.type) end
    for k, v in pairs(e) do
        if v == true then return 'e_' .. tostring(k) end
    end
    return nil
end

if Card and type(Card.set_edition) == 'function' and not Card._cbuf_sealed_set_edition then
    local ref = Card.set_edition
    Card.set_edition = function(self, edition, ...)
        local st = state_of(self)
        if st and self.edition then
            pcall(function()
                local old = edition_key(self.edition)
                if old and old ~= edition_key(edition) then push(st.ed, old) end
            end)
        end
        return ref(self, edition, ...)
    end
    Card._cbuf_sealed_set_edition = true
end

if Card and type(Card.set_seal) == 'function' and not Card._cbuf_sealed_set_seal then
    local ref = Card.set_seal
    Card.set_seal = function(self, seal, ...)
        local st = state_of(self)
        if st and self.seal and self.seal ~= seal then
            pcall(function() push(st.seal, self.seal) end)
        end
        return ref(self, seal, ...)
    end
    Card._cbuf_sealed_set_seal = true
end

-- ===================================================================
-- The Keeper (Spectral)
-- ===================================================================
local function eligible()
    local t = {}
    if G and G.hand and G.hand.cards then
        for _, c in ipairs(G.hand.cards) do
            if c.ability and not c.ability[KEY] then t[#t + 1] = c end
        end
    end
    if G and G.jokers and G.jokers.cards then
        for _, c in ipairs(G.jokers.cards) do
            if c.ability and not c.ability[KEY] then t[#t + 1] = c end
        end
    end
    return t
end

local function seal_card(target)
    if type(target.add_sticker) == 'function' then
        target:add_sticker(KEY, true)
    elseif SMODS.Stickers and SMODS.Stickers[KEY] then
        SMODS.Stickers[KEY]:apply(target, true)
    end
end

SMODS.Consumable {
    key = 'keeper',
    set = 'Spectral',
    atlas = 'cbuf_keeper',
    pos = { x = 0, y = 0 },
    cost = 4,
    unlocked = true,
    discovered = true,
    config = {},
    loc_txt = {
        name = 'The Keeper',
        text = {
            'Puts {C:attention}Sealed{} on {C:attention}1{}, {C:attention}2{} or {C:attention}3{}',
            'random held cards',
            'or {C:attention}Jokers{}',
        },
    },
    can_use = function(self, card)
        return #eligible() > 0
    end,
    use = function(self, card, area, copier)
        local used = copier or card
        local pool = eligible()
        if #pool == 0 then return end
        local n = pseudorandom('cbuf_keeper_n', 1, 3)      -- 1, 2 or 3 cards / Jokers
        if type(pseudoshuffle) == 'function' and type(pseudoseed) == 'function' then
            pseudoshuffle(pool, pseudoseed('cbuf_keeper'))
        end

        G.E_MANAGER:add_event(Event({
            trigger = 'after', delay = 0.4,
            func = function()
                play_sound('tarot1')
                used:juice_up(0.3, 0.5)
                return true
            end,
        }))
        for i = 1, math.min(n, #pool) do
            local target = pool[i]
            G.E_MANAGER:add_event(Event({
                trigger = 'after', delay = 0.25,
                func = function()
                    local ok, err = pcall(seal_card, target)
                    if not ok then log('error', 'could not seal a card: ' .. tostring(err)) end
                    play_sound('gold_seal', 1.1, 0.5)
                    target:juice_up(0.4, 0.4)
                    return true
                end,
            }))
        end
        G.E_MANAGER:add_event(Event({
            trigger = 'after', delay = 0.2,
            func = function() return true end,
        }))
        delay(0.3)
    end,
}

log('info', 'loaded')
