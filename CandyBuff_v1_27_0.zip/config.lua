return {
    spawn_multiplier = 2,
    decay_percent = 20,
    licker_start = true,
    licker_hunger = 3,
    devour_chance = 50,
    fried_eggs_boost = 4,       -- extra pool copies of Fried Eggs once unlocked (0 = normal Uncommon chance)
    menos_duck = 'big',        -- Menos art: 'big' (duck pixels match the card's pixels) or 'small' (half that size)
    -- Gambling Deck slot machine
    slot_fast = false,          -- true = shorter spin animation
    shop_slot_enabled = true,   -- the weaker Slot button in the shop
    shop_slot_style = 'icon',   -- 'icon' = small button right of the shop, 'column' = yellow button next to Reroll
    shop_slot_cost = 3,         -- starting price per pull ($3, +$1 every 3 pulls, resets each ante)
    shop_slot_all_decks = false,-- true = the shop button appears on every deck, not only the Gambling Deck
}
