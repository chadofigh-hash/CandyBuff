-- Candy Buff — Candle (Uncommon Joker) + Hot Wax Seal (v1.26.58)
--
-- CANDLE
--   * Starts unlit. A single hand whose own score is above the blind's requirement ("on fire") LIGHTS it.
--   * Playing a hand while it is LIT snuffs the flame and drips Hot Wax on 2 scoring cards.
--   * While UNLIT, playing a High Card makes it absorb the Chips and Mult of the cards held in hand:
--     the Chips are stored (and paid every hand), the Mult is paid once.
--   * When it lights, it loses a share of its stored Chips equal to how far the hand beat the blind
--     (blind 300, hand ended at 400 = 33% over = loses 33% of the stored Chips).
--   * It melts (is destroyed) after lighting MELT_AFTER times.
--
-- HOT WAX SEAL (only comes from the Candle)
--   * Each time the card scores: its X Mult grows by +X0.1 and is applied.
--   * Then the wax may fall off: 1 in 6 the first time; every time it stays, the odds go up by 1/6.
--
-- Everything you may want to tweak is in CFG below.
-- Safety: failures go to the Lovely log (search "CandyBuff candle").

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] candle: ' .. msg, 'CandyBuff') end
end

local jd = _G.CBUF_API and _G.CBUF_API.jd   -- JokerDisplay helper from candy_core.lua

local CFG = {
    melt_after = 5,               -- the Candle melts after being lit this many times
    wax_cards = 2,                -- how many scoring cards get Hot Wax when the flame goes out
    wax_gain = 0.1,               -- X Mult the seal gains each time its card scores
    fall_odds = 6,                -- "1 in 6" ... the numerator rises by 1 every time the wax stays
}

local SEAL_KEY = 'cbuf_hot_wax'
local FLAME = HEX and HEX('F29D3A') or (G and G.C and G.C.ORANGE)
local WAX = HEX and HEX('D9C9A3') or (G and G.C and G.C.WHITE)

local function num(x)
    if type(x) == 'number' then return x end
    if type(to_number) == 'function' then
        local ok, v = pcall(to_number, x)
        if ok and type(v) == 'number' then return v end
    end
    local ok, v = pcall(tonumber, x)
    return (ok and v) or 0
end

-- ===================================================================
-- Hot Wax Seal
-- ===================================================================
SMODS.Atlas { key = 'cbuf_hot_wax', path = 'cbuf_hot_wax.png', px = 71, py = 95, disable_mipmap = true }

local function wax_state(card)
    card.ability.cbuf_wax = card.ability.cbuf_wax or { x = 1, survived = 0 }
    return card.ability.cbuf_wax
end

local function fall_roll(numerator)
    return pseudorandom('cbuf_wax_fall') < math.min(numerator, CFG.fall_odds) / CFG.fall_odds
end

SMODS.Seal {
    key = 'hot_wax',
    atlas = 'cbuf_hot_wax',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('C9B38A'),
    loc_txt = {
        label = 'Hot Wax',
        name = 'Hot Wax',
        text = {
            '{s:0.85,X:mult,C:white}X#1#{s:0.85} Mult, grows each score',
            '{s:0.85}The wax may fall off',
        },
    },
    loc_vars = function(self, info_queue, card)
        local st = card and card.ability and card.ability.cbuf_wax
        local x = st and st.x or 1
        local n = math.min(CFG.fall_odds, 1 + (st and st.survived or 0))
        return { vars = { x, CFG.wax_gain, n, CFG.fall_odds } }
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            local st = wax_state(card)
            st.x = math.floor((st.x + CFG.wax_gain) * 100 + 0.5) / 100
            local fell = fall_roll(1 + st.survived)
            if fell then
                G.E_MANAGER:add_event(Event({
                    trigger = 'after', delay = 0.4,
                    func = function()
                        pcall(function()
                            card:set_seal(nil, true)
                            card.ability.cbuf_wax = nil
                            card:juice_up(0.5, 0.5)
                            play_sound('tarot2', 0.8, 0.5)
                            card_eval_status_text(card, 'extra', nil, nil, nil,
                                { message = 'Wax fell!', colour = WAX })
                        end)
                        return true
                    end,
                }))
            else
                st.survived = st.survived + 1
            end
            return { x_mult = st.x }
        end
    end,
}

-- ===================================================================
-- Candle
-- ===================================================================
-- sheet: 5 melting stages (stage = times lit, 0..4), 3 columns each:
--   stage*3 + 0 = unlit, +1 = lit, +2 = lit (flame flicker)
SMODS.Atlas { key = 'cbuf_candle', path = 'cbuf_candle.png', px = 71, py = 95, disable_mipmap = true }

local function pick_wax_targets(scoring_hand)
    local pool = {}
    for _, c in ipairs(scoring_hand or {}) do
        if not c.seal and not c.debuff then pool[#pool + 1] = c end
    end
    local picked = {}
    for _ = 1, CFG.wax_cards do
        if #pool == 0 then break end
        local i = math.floor(pseudorandom('cbuf_wax_pick') * #pool) + 1
        picked[#picked + 1] = table.remove(pool, math.min(i, #pool))
    end
    return picked
end

-- How far this hand's own score is above the blind's requirement (0.33 = 33% over).
-- Returns nil when the hand's score alone is below the requirement.
local function overshoot(ex)
    local ok, ratio = pcall(function()
        local score
        if SMODS and type(SMODS.calculate_round_score) == 'function' then
            score = num(SMODS.calculate_round_score())
        else
            score = num(hand_chips) * num(mult)
        end
        local blind = num(G.GAME.blind and G.GAME.blind.chips)
        if blind <= 0 then return 0 end
        if score < blind then return nil end   -- this ONE hand must beat the blind's requirement
        return (score - blind) / blind
    end)
    if not ok then return nil end
    return ratio
end

SMODS.Joker {
    key = 'candle',
    atlas = 'cbuf_candle',
    pos = { x = 0, y = 0 },
    rarity = 2,
    cost = 6,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = false,
    config = { extra = { lit = false, snuffed = false, stored = 0, ignitions = 0, chips_before = 0 } },
    joker_display_def = jd and jd('j_cbuf_candle', function(JokerDisplay)
        return {
            text = {
                { text = '+' },
                { ref_table = 'card.ability.extra', ref_value = 'stored' },
            },
            text_config = { colour = G and G.C and G.C.CHIPS },
            reminder_text = { { ref_table = 'card.joker_display_values', ref_value = 'state' } },
            calc_function = function(card)
                local ex = card.ability and card.ability.extra or {}
                card.joker_display_values.state = ex.lit and '(Lit)' or '(Unlit)'
            end,
        }
    end) or nil,
    loc_txt = {
        name = 'Candle',
        text = {
            '{s:0.85}If score {s:0.85,C:attention}catches on fire{s:0.85}, it lights',
            '{s:0.85}Playing lit drips {s:0.85,C:attention}Hot Wax{s:0.85}',
            '{s:0.85}on {s:0.85,C:attention}#1#{s:0.85} scoring cards',
            '{s:0.85}Unlit {s:0.85,C:attention}High Card{s:0.85} takes held',
            '{s:0.85}cards\' Chips and Mult',
            '{s:0.85,C:chips}+#3#{s:0.85} Chips {s:0.85,V:1}(#4#){s:0.85}, melts in {s:0.85,C:attention}#2#{s:0.85}',
        },
    },
    loc_vars = function(self, info_queue, card)
        if G and G.P_SEALS and G.P_SEALS[SEAL_KEY] then
            info_queue[#info_queue + 1] = G.P_SEALS[SEAL_KEY]
        end
        local ex = card and card.ability and card.ability.extra or {}
        local lit = ex.lit
        return { vars = {
            CFG.wax_cards,
            CFG.melt_after - (ex.ignitions or 0),
            ex.stored or 0,
            lit and 'Lit' or 'Unlit',
            colours = { lit and FLAME or (G and G.C and G.C.UI and G.C.UI.TEXT_INACTIVE) or { 0.6, 0.6, 0.6, 1 } },
        } }
    end,
    -- Keeps the art in sync with the state (also right after loading a save) and flickers the flame.
    update = function(self, card, dt)
        local center = card and card.children and card.children.center
        local ex = card and card.ability and card.ability.extra
        if not (center and ex and center.set_sprite_pos) then return end
        local stage = math.min(4, math.max(0, ex.ignitions or 0))
        local want = stage * 3
        if ex.lit then
            local t = (G and G.TIMERS and G.TIMERS.REAL) or 0
            want = want + 1 + (math.floor(t * 5) % 2)
        end
        if card.cbuf_candle_frame ~= want then
            card.cbuf_candle_frame = want
            center:set_sprite_pos({ x = want, y = 0 })
        end
    end,
    calculate = function(self, card, context)
        if context.blueprint then return end
        local ex = card.ability.extra

        -- 1) Playing a hand while lit: snuff the flame, drip wax on scoring cards.
        if context.before then
            ex.chips_before = num(G.GAME and G.GAME.chips)
            if ex.lit then
                ex.lit = false
                ex.snuffed = true
                for _, c in ipairs(pick_wax_targets(context.scoring_hand)) do
                    G.E_MANAGER:add_event(Event({
                        trigger = 'after', delay = 0.15,
                        func = function()
                            pcall(function()
                                c:set_seal(SEAL_KEY, true, true)
                                c:juice_up(0.3, 0.3)
                                play_sound('card1', 0.9, 0.6)
                            end)
                            return true
                        end,
                    }))
                end
                return { message = 'Snuffed!', colour = WAX }
            end
        end

        -- 2) Unlit High Card: absorb the cards held in hand.
        if context.joker_main and not ex.lit and not ex.snuffed and context.scoring_name == 'High Card' then
            local add_chips = 0
            for _, h in ipairs(G.hand and G.hand.cards or {}) do
                if not h.debuff then
                    local ok1, c = pcall(h.get_chip_bonus, h)
                    if ok1 then add_chips = add_chips + num(c) end
                end
            end
            ex.stored = ex.stored + add_chips
        end

        -- 3) Pay the stored Chips (and the Mult just absorbed).
        if context.joker_main then
            local ret = {}
            if ex.stored > 0 then ret.chips = ex.stored end
            if not ex.lit and not ex.snuffed and context.scoring_name == 'High Card' then
                local m = 0
                for _, h in ipairs(G.hand and G.hand.cards or {}) do
                    if not h.debuff then
                        local ok, v = pcall(h.get_chip_mult, h)
                        if ok then m = m + num(v) end
                    end
                end
                if m > 0 then ret.mult = m end
            end
            if next(ret) then return ret end
        end

        -- 4) After the hand: light the flame, pay the price, maybe melt.
        if context.after then
            if ex.snuffed then
                ex.snuffed = false
                return
            end
            if ex.lit then return end
            local over = overshoot(ex)
            if over == nil then return end   -- only a hand that beats the blind lights the Candle

            ex.lit = true
            ex.ignitions = ex.ignitions + 1

            local lost_pct = 0
            if over > 0 and ex.stored > 0 then
                lost_pct = math.min(1, over)
                ex.stored = math.floor(ex.stored * (1 - lost_pct))
            end

            if ex.ignitions >= CFG.melt_after then
                G.E_MANAGER:add_event(Event({
                    trigger = 'after', delay = 0.5,
                    func = function()
                        pcall(function()
                            play_sound('tarot1')
                            card:start_dissolve({ WAX })
                        end)
                        return true
                    end,
                }))
                return { message = 'Melted!', colour = WAX }
            end

            local ret = { message = 'Lit!', colour = FLAME }
            if lost_pct > 0 then
                ret.extra = { message = '-' .. math.floor(lost_pct * 100 + 0.5) .. '% Chips', colour = G.C.CHIPS }
            end
            return ret
        end
    end,
}

log('info', 'loaded')
