-- Candy Buff — Thenik (Epic Joker), the "Thenik's" sticker and the Epic wave background (v1.26.35)
--
-- Thenik: 1 in 2 chance each hand to DEBUFF the Joker on its right and multiply
--   the values of the Joker on its left by the right Joker's sell value, until the end of the round.
--   * No Joker on the right or on the left (or nothing to multiply): nothing happens.
--   * Once the left Joker is boosted it is not boosted again in the same round (no stacking).
--   * X values only scale the part above X1 (X2 with factor 3 -> X4), the same rule as the Gambling Deck.
--   * Sealed Jokers are skipped, because Sealed would keep the temporary boost forever.
--   * The exact amount added is stored on the card, so the end of the round subtracts just that amount
--     and a scaling Joker keeps whatever it earned in between.
-- Wave: every Epic Joker of this mod (Thenik, Menos) cycles through wave-distorted frames of its background.
--
-- Safety: every hook is inside pcall; failures go to the Lovely log (search "CandyBuff thenik").

local MOD = SMODS.current_mod

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] thenik: ' .. msg, 'CandyBuff') end
end

local jd = _G.CBUF_API and _G.CBUF_API.jd   -- JokerDisplay helper from candy_core.lua
local function to_num_safe(x) return tonumber(x) or 0 end

local STICKER = 'cbuf_theniks'          -- card.ability key (mod prefix + sticker key)
local DELTA = 'cbuf_thenik_delta'       -- list of {path, key, amount} added to the left Joker
local FACTOR = 'cbuf_thenik_f'          -- the multiplier used (for the tooltip)
-- The "Thenik's" sticker turned out to be pointless (the game already shows the debuff), so it is off.
-- Set to true to bring the sticker back (its art cbuf_theniks.png is still in assets).
local USE_STICKER = false
local WAVE_FRAMES = 16

local function to_num(x)
    if type(to_number) == 'function' then
        local ok, v = pcall(to_number, x)
        if ok and type(v) == 'number' then return v end
    end
    return tonumber(x) or 0
end

local function show_message(card, text, colour)
    if card_eval_status_text and G and G.C then
        card_eval_status_text(card, 'extra', nil, nil, nil, { message = text, colour = colour or G.C.GREEN })
    end
end

-- Same Epic rarity as Menos: Cryptid's when installed, otherwise this mod's own (registered in candy_core.lua).
local CRYPTID_LOADED = SMODS.Mods and SMODS.Mods.Cryptid and SMODS.Mods.Cryptid.can_load and true or false
local RARITY = CRYPTID_LOADED and 'cry_epic' or 'cbuf_epic'

-- ===================================================================
-- Atlases
-- ===================================================================
-- columns 0..15 = the background wave frames (a seamless loop), column 16 = the floating creature
SMODS.Atlas { key = 'cbuf_thenik', path = 'cbuf_thenik.png', px = 71, py = 95, disable_mipmap = true }
if USE_STICKER then
    SMODS.Atlas { key = 'cbuf_theniks', path = 'cbuf_theniks.png', px = 71, py = 95, disable_mipmap = true }
end

-- ===================================================================
-- Which numbers of a Joker can be multiplied
-- ===================================================================
local X_SELF = { x_mult = true, xmult = true, Xmult = true, x_chips = true, xchips = true, Xchips = true }
local TOP_KEYS = { 'mult', 'h_mult', 't_mult', 'chips', 'h_chips', 't_chips', 'x_mult', 'x_chips' }
-- names that are counters, odds, steps or sizes: never multiplied
local BAD_WORDS = { 'odds', 'chance', 'used', 'pos', 'round', 'remain', 'count', 'hand', 'size', 'slot',
                    'discard', 'gain', 'mod', 'inc', 'every', 'need', 'req', 'dollar', 'money' }

local function is_x(k) return X_SELF[k] == true end

local function key_ok(k)
    if type(k) ~= 'string' then return false end
    local l = k:lower()
    for _, w in ipairs(BAD_WORDS) do
        if l:find(w, 1, true) then return false end
    end
    return (l:find('mult', 1, true) or l:find('chip', 1, true)) and true or false
end

-- Vanilla Jokers whose `ability.extra` is itself one plain number: true = an X value, false = chips / mult.
local EXTRA_NUMBER = {
    j_hiker = false, j_smiley = false, j_scary_face = false, j_even_steven = false, j_odd_todd = false,
    j_fibonacci = false, j_banner = false, j_abstract = false, j_bull = false, j_shoot_the_moon = false,
    j_blue_joker = false, j_erosion = false, j_arrowhead = false, j_onyx_agate = false,
    j_photograph = true, j_triboulet = true, j_baron = true, j_ancient = true, j_idol = true,
}

local function slots_of(card)
    local slots = {}
    local ab = card and card.ability
    if type(ab) ~= 'table' then return slots end
    for _, k in ipairs(TOP_KEYS) do
        local v = ab[k]
        if type(v) == 'number' and v > 0 and not (is_x(k) and v <= 1) then
            slots[#slots + 1] = { path = 'top', tbl = ab, key = k, x = is_x(k) }
        end
    end
    if type(ab.extra) == 'table' then
        for k, v in pairs(ab.extra) do
            if type(v) == 'number' and v > 0 and key_ok(k) and not (is_x(k) and v <= 1) then
                slots[#slots + 1] = { path = 'extra', tbl = ab.extra, key = k, x = is_x(k) }
            end
        end
    elseif type(ab.extra) == 'number' then
        local ckey = card.config and card.config.center and card.config.center.key
        local x = EXTRA_NUMBER[ckey]
        if x ~= nil and ab.extra > 0 and not (x and ab.extra <= 1) then
            slots[#slots + 1] = { path = 'self', tbl = ab, key = 'extra', x = x }
        end
    end
    return slots
end

-- Multiply the values of `card` by f. Returns how many numbers changed.
local function boost(card, f)
    local slots = slots_of(card)
    if #slots == 0 then return 0 end
    local deltas = {}
    for _, s in ipairs(slots) do
        local v = s.tbl[s.key]
        local nv = s.x and (1 + (v - 1) * f) or (v * f)
        s.tbl[s.key] = nv
        deltas[#deltas + 1] = { s.path, s.key, nv - v }
    end
    card.ability[DELTA] = deltas
    card.ability[FACTOR] = f
    return #deltas
end

local function round4(x) return math.floor(x * 10000 + 0.5) / 10000 end

-- Take back exactly what boost() added.
local function unboost(card)
    local ab = card.ability
    local deltas = ab and ab[DELTA]
    if type(deltas) ~= 'table' then return end
    for _, d in ipairs(deltas) do
        local path, key, amount = d[1], d[2], d[3]
        local tbl = (path == 'extra' and ab.extra) or ab
        if type(tbl) == 'table' and type(tbl[key]) == 'number' and type(amount) == 'number' then
            tbl[key] = round4(tbl[key] - amount)
        end
    end
    ab[DELTA] = nil
    ab[FACTOR] = nil
end

-- ===================================================================
-- The sticker "Thenik's": the Joker is debuffed until the end of the round
-- ===================================================================
if USE_STICKER then
SMODS.Sticker {
    key = 'theniks',
    atlas = 'cbuf_theniks',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('3CA370'),
    rate = 0,
    needs_enable_flag = false,
    default_compat = true,
    sets = { Joker = true },
    loc_txt = {
        name = "Thenik's",
        label = "Thenik's",
        text = {
            '{C:red}Debuffed{} until',
            'the end of the round',
        },
    },
}
end

-- A Joker carrying the flag stays debuffed (chained after the wrapper in candy_core.lua).
if Card and type(Card.set_debuff) == 'function' and not Card._cbuf_thenik_debuff then
    local debuff_ref = Card.set_debuff
    function Card:set_debuff(should_debuff, ...)
        if self.ability and self.ability[STICKER] then should_debuff = true end
        return debuff_ref(self, should_debuff, ...)
    end
    Card._cbuf_thenik_debuff = true
end

local function put_sticker(card)
    if USE_STICKER and type(card.add_sticker) == 'function' then pcall(card.add_sticker, card, STICKER, true) end
    card.ability[STICKER] = true
    pcall(card.set_debuff, card, true)
end

local function remove_sticker(card)
    if USE_STICKER and type(card.remove_sticker) == 'function' then pcall(card.remove_sticker, card, STICKER) end
    card.ability[STICKER] = nil
    if SMODS and type(SMODS.recalc_debuff) == 'function' then
        pcall(SMODS.recalc_debuff, card)
    else
        pcall(card.set_debuff, card, false)
    end
end

-- ===================================================================
-- The Joker
-- ===================================================================
local function neighbours(card)
    local list = G and G.jokers and G.jokers.cards
    if not list then return nil, nil end
    for i, c in ipairs(list) do
        if c == card then return list[i - 1], list[i + 1] end
    end
    return nil, nil
end

local function odds()
    local ok, num, den = pcall(function()
        if SMODS and type(SMODS.get_probability_vars) == 'function' then
            return SMODS.get_probability_vars(nil, 1, 2, 'cbuf_thenik')
        end
    end)
    if ok and num then return num, den end
    return (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1, 2
end

local function roll(card)
    if SMODS and type(SMODS.pseudorandom_probability) == 'function' then
        return SMODS.pseudorandom_probability(card, 'cbuf_thenik', 1, 2, 'cbuf_thenik') and true or false
    end
    local num = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return pseudorandom('cbuf_thenik') < num / 2
end

local function thenik_hand(card)
    local left, right = neighbours(card)
    if not (left and right) then return end
    if left.ability[DELTA] or right.ability[STICKER] then return end       -- already active this round
    if left.ability.cbuf_sealed then return end                            -- Sealed would keep the boost
    local f = math.floor(to_num(right.sell_cost))
    if f < 2 then return end                                               -- X1 would change nothing
    if #slots_of(left) == 0 then return end
    if not roll(card) then return end
    if boost(left, f) == 0 then return end
    put_sticker(right)
    show_message(card, 'Thenik!', HEX('3CA370'))
    show_message(left, 'X' .. f, HEX('F29D69'))
    pcall(function() left:juice_up(0.5, 0.5); right:juice_up(0.3, 0.3) end)
end

SMODS.Joker {
    key = 'thenik',
    atlas = 'cbuf_thenik',
    pos = { x = 0, y = 0 },
    soul_pos = { x = WAVE_FRAMES, y = 0 },
    rarity = RARITY,
    cost = 10,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = {} },
    -- JokerDisplay support (only used when the JokerDisplay mod is installed).
    joker_display_def = jd and jd('j_cbuf_thenik', function(JokerDisplay)
        return {
            text = {
                { text = 'X' },
                { ref_table = 'card.joker_display_values', ref_value = 'factor' },
            },
            text_config = { colour = G.C.ORANGE },
            reminder_text = {
                { text = '(' },
                { ref_table = 'card.joker_display_values', ref_value = 'odds' },
                { text = ')' },
            },
            calc_function = function(card)
                local left, right = neighbours(card)
                local f = left and left.ability and left.ability[FACTOR]
                card.joker_display_values.factor = f and tostring(f) or '-'
                local num, den = odds()
                card.joker_display_values.odds = math.floor(to_num_safe(num)) .. ' in ' .. math.floor(to_num_safe(den))
            end,
        }
    end) or nil,
    loc_txt = {
        name = 'Thenik',
        text = {
            '{C:green}#1# in #2#{} chance each hand to {C:red}debuff{}',
            'the Joker to the right and multiply the',
            "left Joker's values by its {C:attention}sell value{}",
            '{C:inactive}Until end of round. (#3#){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local num, den = odds()
        local status = 'Ready'
        local left = select(1, neighbours(card))
        local f = left and left.ability and left.ability[FACTOR]
        if f then status = 'Active: X' .. tostring(f) end
        return { vars = { num, den, status } }
    end,
    calculate = function(self, card, context)
        if context.blueprint then return end
        if context.before then
            local ok, err = pcall(thenik_hand, card)
            if not ok then log('error', 'hand failed: ' .. tostring(err)) end
        end
    end,
}

-- End of the round: give every boosted Joker its own numbers back and lift the debuff.
do
    local previous = MOD.calculate
    MOD.calculate = function(self, context)
        local r
        if previous then r = previous(self, context) end
        if context and context.end_of_round and not context.individual and not context.repetition
            and not context.game_over and G and G.jokers then
            for _, c in ipairs(G.jokers.cards) do
                local ab = c.ability
                if ab and ab[DELTA] then
                    local ok, err = pcall(unboost, c)
                    if not ok then log('error', 'restore failed: ' .. tostring(err)) end
                end
                if ab and ab[STICKER] then
                    local ok, err = pcall(remove_sticker, c)
                    if not ok then log('error', 'sticker removal failed: ' .. tostring(err)) end
                end
            end
        end
        return r
    end
end

-- ===================================================================
-- Animated card faces (the Epic wave, the Roundy idle loop): swap the card face between baked frames
-- ===================================================================
-- center key -> first frame column in the atlas, frame count, frames per second
local WAVE = {
    j_cbuf_thenik = { first = 0, frames = WAVE_FRAMES, fps = 8 },
    j_cbuf_menos = { first = 3, frames = WAVE_FRAMES, fps = 8 },   -- columns 0..2 are the original card and ducks
    j_cbuf_roundy = { first = 0, frames = 12, fps = 10 },          -- idle loop of the Roundy card art
    j_cbuf_nolhad = { first = 0, frames = WAVE_FRAMES, fps = 8 },
}

if Card and type(Card.update) == 'function' and not Card._cbuf_wave_update then
    local update_ref = Card.update
    Card.update = function(self, ...)
        local r = update_ref(self, ...)
        local center = self.config and self.config.center
        local w = center and WAVE[center.key]
        local sprite = w and self.children and self.children.center
        if sprite and sprite.set_sprite_pos then
            local t = (G and G.TIMERS and G.TIMERS.REAL) or 0
            local f = math.floor(t * w.fps) % w.frames
            if self._cbuf_wave ~= f then
                self._cbuf_wave = f
                pcall(sprite.set_sprite_pos, sprite, { x = w.first + f, y = 0 })
            end
        end
        return r
    end
    Card._cbuf_wave_update = true
else
    log('warn', 'Card.update not found, the Epic wave will not animate')
end

log('info', 'loaded')
