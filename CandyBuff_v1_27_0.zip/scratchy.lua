-- Candy Buff — Scratchy (Uncommon Joker) (v1.26.53)
--
--   * Starts at X1 Mult with a 1 in 1 chance.
--   * Every hand played it "scratches" once (before scoring):
--       HIT  (1 in N chance): +X0.5 Mult and the chance gets worse by one step (1 in N+1).
--       MISS: counted. Every 3 misses IN A ROW (a hit resets the count) the chance gets better by one step (1 in N-1, never below 1 in 1)
--             and its X Mult is cut in half (never below X1). Example: X2.5 -> X1.25.
--   * It then scores its current X Mult.
--
-- Safety: all hooks are inside pcall; failures go to the Lovely log (search "CandyBuff scratchy").

local MOD = SMODS.current_mod

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] scratchy: ' .. msg, 'CandyBuff') end
end

local jd = _G.CBUF_API and _G.CBUF_API.jd   -- JokerDisplay helper from candy_core.lua

local GAIN = 0.5            -- X Mult gained on a hit
local MISS_LIMIT = 3        -- misses before the penalty
local function round2(x) return math.floor(x * 100 + 0.5) / 100 end

local function fmt(x)       -- 2.5 -> "2.5", 1.25 -> "1.25", 2 -> "2"
    local s = string.format('%.2f', x)
    s = s:gsub('0+$', ''):gsub('%.$', '')
    return s
end

local function show(card, text, colour)
    if card_eval_status_text and G and G.C then
        card_eval_status_text(card, 'extra', nil, nil, nil, { message = text, colour = colour or G.C.ATTENTION })
    end
end

-- 1 in den (respects probability Jokers such as Oops! All 6s)
local function roll(card, den)
    if SMODS and type(SMODS.pseudorandom_probability) == 'function' then
        return SMODS.pseudorandom_probability(card, 'cbuf_scratchy', 1, den, 'cbuf_scratchy') and true or false
    end
    local num = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return pseudorandom('cbuf_scratchy') < num / den
end

local function odds_vars(card)
    local ex = card.ability and card.ability.extra or {}
    local den = ex.den or 1
    local num = 1
    pcall(function()
        if SMODS and type(SMODS.get_probability_vars) == 'function' then
            num, den = SMODS.get_probability_vars(card, 1, ex.den or 1, 'cbuf_scratchy')
        end
    end)
    return num, den
end

-- 71x95 card art (one static frame)
SMODS.Atlas { key = 'cbuf_scratchy', path = 'cbuf_scratchy.png', px = 71, py = 95, disable_mipmap = true }

local function scratch(card)
    local ex = card.ability.extra
    ex.den = math.max(1, ex.den or 1)
    ex.xmult = ex.xmult or 1
    ex.miss = ex.miss or 0
    if roll(card, ex.den) then
        ex.xmult = round2(ex.xmult + GAIN)
        ex.den = ex.den + 1
        ex.miss = 0                      -- misses must be consecutive
        pcall(function() card:juice_up(0.6, 0.6) end)
        show(card, '+X' .. fmt(GAIN), G.C.MULT)
    else
        ex.miss = ex.miss + 1
        if ex.miss >= MISS_LIMIT then
            ex.miss = 0
            ex.den = math.max(1, ex.den - 1)
            ex.xmult = round2(math.max(1, ex.xmult / 2))
            show(card, 'X' .. fmt(ex.xmult), G.C.RED)
        else
            show(card, 'Miss ' .. ex.miss .. '/' .. MISS_LIMIT, G.C.INACTIVE)
        end
    end
end

SMODS.Joker {
    key = 'scratchy',
    atlas = 'cbuf_scratchy',
    pos = { x = 0, y = 0 },
    rarity = 2,
    cost = 6,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = { xmult = 1, den = 1, miss = 0 } },
    -- JokerDisplay support (only used when the JokerDisplay mod is installed).
    joker_display_def = jd and jd('j_cbuf_scratchy', function(JokerDisplay)
        return {
            text = {
                { text = 'X' },
                { ref_table = 'card.joker_display_values', ref_value = 'xmult' },
            },
            text_config = { colour = G.C.MULT },
            reminder_text = {
                { ref_table = 'card.joker_display_values', ref_value = 'odds' },
            },
            calc_function = function(card)
                local ex = card.ability.extra or {}
                card.joker_display_values.xmult = fmt(ex.xmult or 1)
                local num, den = odds_vars(card)
                card.joker_display_values.odds = '(' .. math.floor(tonumber(num) or 1) .. '/' .. math.floor(tonumber(den) or 1) .. ')'
            end,
        }
    end) or nil,
    loc_txt = {
        name = 'Scratchy',
        text = {
            '{C:green}#1# in #2#{} chance each hand: {X:mult,C:white}+X' .. fmt(GAIN) .. '{} Mult,',
            'then the odds get {C:attention}1{} worse',
            'Every {C:attention}' .. MISS_LIMIT .. '{} misses in a row: odds {C:attention}1{} better,',
            'Mult is {C:attention}halved{}',
            '{C:inactive}(Currently {X:mult,C:white}X#3#{} {C:inactive}Mult, miss #4#/' .. MISS_LIMIT .. '){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = card.ability and card.ability.extra or {}
        local num, den = odds_vars(card)
        return { vars = { num, den, fmt(ex.xmult or 1), ex.miss or 0 } }
    end,
    calculate = function(self, card, context)
        if context.before and not context.blueprint then
            local ok, err = pcall(scratch, card)
            if not ok then log('error', 'scratch failed: ' .. tostring(err)) end
            return
        end
        if context.joker_main then
            local x = card.ability.extra and card.ability.extra.xmult or 1
            if x > 1 then
                return { xmult = x }
            end
        end
    end,
}

log('info', 'loaded')
