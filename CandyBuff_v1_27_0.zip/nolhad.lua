-- Candy Buff — Nol Had (Epic Joker) (v1.26.36)
--
--   * Every card held in hand when you play a hand: +$1 sell value. Retriggers of held-in-hand cards
--     (Mime, Red Seal...) count as extra cards, so each one adds another +$1.
--   * When sold: 1 in 2 chance that it is NOT destroyed. You still get paid its sell value,
--     then its sell value drops to $0.
--
-- Safety: all hooks are inside pcall; failures go to the Lovely log (search "CandyBuff nolhad").

local MOD = SMODS.current_mod

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] nolhad: ' .. msg, 'CandyBuff') end
end

local jd = _G.CBUF_API and _G.CBUF_API.jd   -- JokerDisplay helper from candy_core.lua

local KEY = 'j_cbuf_nolhad'
local GAIN = 1                         -- sell value per held card (and per retrigger)
local RESET_VALUE = 0                  -- sell value after it survives a sale

local CRYPTID_LOADED = SMODS.Mods and SMODS.Mods.Cryptid and SMODS.Mods.Cryptid.can_load and true or false
local RARITY = CRYPTID_LOADED and 'cry_epic' or 'cbuf_epic'

local function show(card, text, colour)
    if card_eval_status_text and G and G.C then
        card_eval_status_text(card, 'extra', nil, nil, nil, { message = text, colour = colour or G.C.MONEY })
    end
end

local function roll(card, seed)
    if SMODS and type(SMODS.pseudorandom_probability) == 'function' then
        return SMODS.pseudorandom_probability(card, seed, 1, 2, seed) and true or false
    end
    local num = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return pseudorandom(seed) < num / 2
end

local function odds()
    local ok, num, den = pcall(function()
        if SMODS and type(SMODS.get_probability_vars) == 'function' then
            return SMODS.get_probability_vars(nil, 1, 2, 'cbuf_nolhad_sell')
        end
    end)
    if ok and num then return num, den end
    return (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1, 2
end

-- columns 0..15 = the background wave frames (a seamless loop), column 16 = the floating rock
SMODS.Atlas { key = 'cbuf_nolhad', path = 'cbuf_nolhad.png', px = 71, py = 95, disable_mipmap = true }

SMODS.Joker {
    key = 'nolhad',
    atlas = 'cbuf_nolhad',
    pos = { x = 0, y = 0 },
    soul_pos = { x = 16, y = 0 },
    rarity = RARITY,
    cost = 10,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = {} },
    -- JokerDisplay support (only used when the JokerDisplay mod is installed).
    joker_display_def = jd and jd('j_cbuf_nolhad', function(JokerDisplay)
        return {
            text = {
                { text = '$' },
                { ref_table = 'card.joker_display_values', ref_value = 'sell' },
            },
            text_config = { colour = G.C.GOLD },
            reminder_text = {
                { text = '(sell, ' },
                { ref_table = 'card.joker_display_values', ref_value = 'odds' },
                { text = ')' },
            },
            calc_function = function(card)
                card.joker_display_values.sell = card.sell_cost or 0
                local num, den = odds()
                card.joker_display_values.odds = math.floor(tonumber(num) or 1) .. ' in ' .. math.floor(tonumber(den) or 2)
            end,
        }
    end) or nil,
    loc_txt = {
        name = 'Nol Had',
        text = {
            '{C:money}+$' .. GAIN .. '{} sell value for each card',
            'held in hand, {C:attention}retriggers{} count too',
            '{C:green}#1# in #2#{} when sold: not destroyed,',
            'sell value drops to {C:money}$' .. RESET_VALUE .. '{}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local num, den = odds()
        return { vars = { num, den } }
    end,
    calculate = function(self, card, context)
        if context.blueprint then return end
        -- one call per held card, and one more for every retrigger of it
        if context.individual and context.cardarea == G.hand and not context.end_of_round then
            card.ability.extra_value = (card.ability.extra_value or 0) + GAIN
            card:set_cost()
            local msg = (type(localize) == 'function' and localize('k_val_up')) or 'Value Up!'
            return { message = msg, colour = G.C.MONEY, card = card }
        end
    end,
}

-- Selling: 50% the Joker survives. The player is paid the current sell value, then it restarts.
if Card and type(Card.sell_card) == 'function' and not Card._cbuf_nolhad_sell then
    local sell_ref = Card.sell_card
    function Card:sell_card(...)
        local center = self.config and self.config.center
        if center and center.key == KEY and self.ability then
            local ok, spared = pcall(roll, self, 'cbuf_nolhad_sell')
            if ok and spared then
                local pay = self.sell_cost or 0
                if self.area and self.area.remove_from_highlighted then
                    pcall(self.area.remove_from_highlighted, self.area, self)
                end
                G.E_MANAGER:add_event(Event({
                    trigger = 'after', delay = 0.2,
                    func = function()
                        self.ability.extra_value = 0
                        self:set_cost()
                        -- drop to exactly RESET_VALUE (0), whatever the base value is
                        self.ability.extra_value = RESET_VALUE - (self.sell_cost or 0)
                        self:set_cost()
                        self:juice_up(0.8, 0.8)
                        if type(play_sound) == 'function' then play_sound('coin1') end
                        if pay > 0 and type(ease_dollars) == 'function' then ease_dollars(pay) end
                        show(self, 'Safe!', G.C.GREEN)
                        return true
                    end,
                }))
                return
            end
        end
        return sell_ref(self, ...)
    end
    Card._cbuf_nolhad_sell = true
else
    log('warn', 'Card.sell_card not found, the 1 in 2 save will not work')
end

log('info', 'loaded')
