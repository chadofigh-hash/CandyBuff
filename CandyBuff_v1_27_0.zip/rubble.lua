-- Candy Buff — Golden Rubble (Uncommon Joker) (v1.26.95)
--
--   It starts INACTIVE. Keep it while you defeat a Boss Blind and it is activated (it remembers that Boss).
--   Then SELL it: you are paid, it is NOT destroyed, its sell value drops to $0 and it opens into one of
--   three modes (Gold is the rare one, Nothing is rarer than Silver):
--
--   GOLD    After every Boss Blind: 1 in 8 a Rare Joker or 1 in 32 a Legendary Joker (then it is destroyed).
--           A miss adds that Boss's effect to EVERY blind while you own it (curses stack), and the odds get
--           better with every Boss it has been through. It also adds half of each blind's reward to the cash out.
--   SILVER  After every blind: +X0.2 Mult for each hand you still had. With a Common Joker, Steel cards held in
--           hand give an extra X0.25 each.
--   NOTHING Natural Negative chance x1.5. Each round a random rank and a random suit are debuffed.
--           If you defeated a Boss Blind with it, selling it makes a random Joker Negative.
--
-- Boss effects copied by Gold: the "while playing" ones (debuffs, face-down cards, hand rules, ...) are run through
-- the real Blind functions; the "at the start" ones are done by hand for The Water, The Needle, The Manacle,
-- The Wall and Violet Vessel. Other start-of-blind effects (Amber Acorn, Cerulean Bell ...) are not copied.
--
-- Written from reading Steamodded; it could NOT be run inside the game. Failures go to the Lovely log
-- (search "[CandyBuff] rubble").

local KEY = 'j_cbuf_rubble'

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] rubble: ' .. msg, 'CandyBuff') end
end

local jd = _G.CBUF_API and _G.CBUF_API.jd

local CFG = {
    gold_odds = 10,            -- "1 in 10" that the opened rubble is Gold
    silver_share = 0.65,       -- of the rest, this share is Silver (the others are Nothing)
    rare_den = 8,              -- Gold: Rare Joker  (1 in 8, better with every Boss)
    legend_den = 32,           -- Gold: Legendary   (1 in 32, better with every Boss)
    gold_share = 0.5,          -- Gold pays this part of the blind reward at cash out
    silver_per_hand = 0.2,     -- Silver: X Mult per hand left
    steel_bonus = 0.25,        -- Silver: extra X Mult per held Steel card (needs a Common Joker)
    neg_extra = 0.5,           -- Nothing: +50% natural Negative chance
    neg_base = 0.003,          -- vanilla chance of a natural Negative edition
}

-- art: 4 frames
local FRAME = { inactive = 0, ready = 0, gold = 1, silver = 2, nothing = 3 }
SMODS.Atlas { key = 'cbuf_rubble', path = 'cbuf_rubble.png', px = 71, py = 95, disable_mipmap = true }

local function fmt(x)
    local s = string.format('%.2f', x)
    s = s:gsub('0+$', ''):gsub('%.$', '')
    return s
end
local function round2(x) return math.floor(x * 100 + 0.5) / 100 end

local function show(card, text, colour)
    if card_eval_status_text and G and G.C then
        pcall(card_eval_status_text, card, 'extra', nil, nil, nil, { message = text, colour = colour or G.C.ATTENTION })
    end
end

local function roll(card, seed, num, den)
    if SMODS and type(SMODS.pseudorandom_probability) == 'function' then
        local ok, r = pcall(SMODS.pseudorandom_probability, card, seed, num, den, seed)
        if ok then return r and true or false end
    end
    local normal = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return pseudorandom(seed) < math.min(1, normal * num / den)
end

local function odds_vars(card, seed, num, den)
    if SMODS and type(SMODS.get_probability_vars) == 'function' then
        local ok, n, d = pcall(SMODS.get_probability_vars, card, num, den, seed)
        if ok and n and d then return n, d end
    end
    return num, den
end

local function set_frame(card, f)
    local c = card and card.children and card.children.center
    if c and c.set_sprite_pos then
        c:set_sprite_pos({ x = f, y = 0 })
        card.cbuf_rub_frame = f
    end
end

local function cur_blind_key()
    local b = G and G.GAME and G.GAME.blind
    return b and b.config and b.config.blind and b.config.blind.key
end

local function in_boss()
    local b = G and G.GAME and G.GAME.blind
    return b and b.boss and true or false
end

local function blind_name(key)
    local ok, n = pcall(localize, { type = 'name_text', key = key, set = 'Blind' })
    if ok and type(n) == 'string' and n ~= 'ERROR' then return n end
    return tostring(key):gsub('^bl_', '')
end

local function die(card)
    local ok = false
    if SMODS and type(SMODS.destroy_cards) == 'function' then ok = pcall(SMODS.destroy_cards, card, true) end
    if not ok then pcall(function() card:start_dissolve({ G.C.RED }, nil, 1.6) end) end
end

-- the rubbles that are in a given stage
local function each_rubble(stage, fn)
    for _, j in ipairs((G and G.jokers and G.jokers.cards) or {}) do
        local ex = j.ability and j.ability.extra
        if j.config and j.config.center and j.config.center.key == KEY and type(ex) == 'table'
            and ex.stage == stage and not j.debuff then
            fn(j, ex)
        end
    end
end

-- BOSS CURSES (Gold) ---------------------------------------------------------------------------------
local function proxy_for(card, key)
    card.cbuf_proxies = card.cbuf_proxies or {}
    local p = card.cbuf_proxies[key]
    if p then return p end
    local c = G and G.P_BLINDS and G.P_BLINDS[key]
    if not c then return nil end
    local real = G.GAME.blind
    -- a stand-in for the real Blind: it has the stored Boss's own name and settings, its own state, and reads
    -- everything else (methods, G values) from the real Blind.
    p = setmetatable({
        name = c.name, config = { blind = c }, debuff = c.debuff or {}, mult = c.mult, dollars = c.dollars,
        disabled = false, boss = true, hands = {}, triggered = nil, prepped = nil,
    }, { __index = function(_, k) return real and real[k] end })
    card.cbuf_proxies[key] = p
    return p
end

-- every stored curse of every Gold rubble that applies to the blind that is being played
local function active_proxies()
    local list = {}
    local real = G and G.GAME and G.GAME.blind
    if not (real and real.config and real.config.blind and real.chips and real.chips ~= 0) or real.disabled then return list end
    local seen = {}
    each_rubble('gold', function(j, ex)
        for _, key in ipairs(ex.curses or {}) do
            if key ~= cur_blind_key() and not seen[key] then
                local p = proxy_for(j, key)
                if p then seen[key] = true; list[#list + 1] = p end
            end
        end
    end)
    return list
end

local function wrap_blind()
    if not Blind or Blind._cbuf_rubble_wrapped then return end
    Blind._cbuf_rubble_wrapped = true

    local function wrap(name, after)
        local orig = Blind[name]
        if type(orig) ~= 'function' then log('warn', 'Blind.' .. name .. ' not found'); return end
        Blind[name] = function(self, ...)
            local r1, r2, r3 = orig(self, ...)
            local ok, a, b, c = pcall(after, self, orig, { ... }, r1, r2, r3)
            if ok then return a, b, c end
            log('warn', name .. ' curse failed: ' .. tostring(a))
            return r1, r2, r3
        end
    end

    -- a card gets debuffed: the curses may only ADD debuffs
    wrap('debuff_card', function(self, orig, args, r1)
        local card = args[1]
        for _, p in ipairs(active_proxies()) do
            local was = card and card.debuff
            pcall(orig, p, unpack(args))
            if was and card and not card.debuff and card.set_debuff then card:set_debuff(true) end
        end
        return r1
    end)
    -- cards drawn face down
    wrap('stay_flipped', function(self, orig, args, r1)
        if r1 then return r1 end
        for _, p in ipairs(active_proxies()) do
            local ok, r = pcall(orig, p, unpack(args))
            if ok and r then return true end
        end
        return r1
    end)
    -- hand is debuffed (The Psychic, The Eye, The Mouth ...)
    wrap('debuff_hand', function(self, orig, args, r1)
        if r1 then return r1 end
        for _, p in ipairs(active_proxies()) do
            local ok, r = pcall(orig, p, unpack(args))
            if ok and r then return r end
        end
        return r1
    end)
    -- hand score changes (The Flint ...): chain mult and chips
    wrap('modify_hand', function(self, orig, args, mult, chips, modded)
        for _, p in ipairs(active_proxies()) do
            local a = { unpack(args) }
            a[4], a[5] = mult, chips
            local ok, m, c, mod = pcall(orig, p, unpack(a))
            if ok and m then mult, chips = m, c; modded = modded or mod end
        end
        return mult, chips, modded
    end)
    wrap('press_play', function(self, orig, args, r1)
        for _, p in ipairs(active_proxies()) do pcall(orig, p, unpack(args)) end
        return r1
    end)
    wrap('drawn_to_hand', function(self, orig, args, r1)
        for _, p in ipairs(active_proxies()) do pcall(orig, p, unpack(args)) end
        return r1
    end)
end
pcall(wrap_blind)

-- start-of-blind effects, done by hand
local function apply_start(card, key)
    local ex = card.ability.extra
    local r = (G.GAME and G.GAME.current_round) or {}
    local c = G.P_BLINDS and G.P_BLINDS[key]
    if key == 'bl_water' then
        if (r.discards_left or 0) > 0 then ease_discard(-r.discards_left, true) end
    elseif key == 'bl_needle' then
        local h = r.hands_left or 0
        if h > 1 then ease_hands_played(-(h - 1), true) end
    elseif key == 'bl_manacle' then
        G.hand:change_size(-1)
        ex.hs_loss = (ex.hs_loss or 0) + 1
    elseif c and (c.mult or 2) > 2 and G.GAME.blind and G.GAME.blind.chips then
        local f = (c.mult or 2) / 2                      -- The Wall (x4) -> x2 more, Violet Vessel (x6) -> x3 more
        G.GAME.blind.chips = G.GAME.blind.chips * f
        if number_format then G.GAME.blind.chip_text = number_format(G.GAME.blind.chips) end
        pcall(function() G.GAME.blind:wiggle() end)
    end
end

local function give_back_hand_size(card)
    local ex = card.ability and card.ability.extra
    if ex and (ex.hs_loss or 0) > 0 and G and G.hand then
        pcall(function() G.hand:change_size(ex.hs_loss) end)
        ex.hs_loss = 0
    end
end

-- NOTHING: debuffed rank + suit, natural Negative ---------------------------------------------------
local RANKS = { { 2, '2' }, { 3, '3' }, { 4, '4' }, { 5, '5' }, { 6, '6' }, { 7, '7' }, { 8, '8' }, { 9, '9' },
    { 10, '10' }, { 11, 'Jack' }, { 12, 'Queen' }, { 13, 'King' }, { 14, 'Ace' } }
local SUITS = { 'Spades', 'Hearts', 'Clubs', 'Diamonds' }

local function recalc_all()
    pcall(function()
        for _, c in ipairs(G.playing_cards or {}) do
            if SMODS and type(SMODS.recalc_debuff) == 'function' then SMODS.recalc_debuff(c)
            elseif G.GAME.blind then G.GAME.blind:debuff_card(c) end
        end
    end)
end

if type(poll_edition) == 'function' and not _G._cbuf_rubble_poll then
    _G._cbuf_rubble_poll = true
    local ref = poll_edition
    function poll_edition(_key, _mod, _no_neg, _guaranteed, ...)
        local r = ref(_key, _mod, _no_neg, _guaranteed, ...)
        if r == 'e_negative' or _no_neg or _guaranteed then return r end
        local n = 0
        each_rubble('nothing', function() n = n + 1 end)
        if n > 0 then
            local ok, hit = pcall(function()
                return pseudorandom('cbuf_rubble_neg' .. tostring(_key)) < CFG.neg_base * CFG.neg_extra * n * (tonumber(_mod) or 1)
            end)
            if ok and hit then return 'e_negative' end
        end
        return r
    end
end

-- text of the stages (own descriptions, installed by hand like the Halloween Night ones) --------------
local ENTRIES = {
    j_cbuf_rubble_ready = { name = 'Golden Rubble', text = {
        '{s:0.85,C:attention}Activated{s:0.85} by #1#',
        '{s:0.85,C:attention}Sell{s:0.85} it to open it and see',
        '{s:0.85,C:attention}Gold{s:0.85} / {s:0.85,C:inactive}Silver{s:0.85} / {s:0.85,C:inactive}Nothing',
        '{s:0.85}Its sell value becomes {s:0.85,C:money}$0',
    } },
    j_cbuf_rubble_gold = { name = 'Golden Rubble: Gold', text = {
        '{s:0.85}After each {s:0.85,C:attention}Boss Blind{s:0.85}: {s:0.85,C:green}#1# in #2#{s:0.85} {s:0.85,C:red}Rare{s:0.85} Joker',
        '{s:0.85}or {s:0.85,C:green}#3# in #4#{s:0.85} {s:0.85,C:legendary}Legendary{s:0.85} (then it breaks)',
        '{s:0.85}A miss adds that Boss\'s effect to',
        '{s:0.85,C:attention}every{s:0.85} blind and improves the odds',
        '{s:0.85}Half of each blind reward is added',
        '{s:0.8,C:inactive}Curses: #5#',
    } },
    j_cbuf_rubble_silver = { name = 'Golden Rubble: Silver', text = {
        '{s:0.85}After each blind: {s:0.85,X:mult,C:white}+X#2#{s:0.85} Mult',
        '{s:0.85}for each hand left',
        '{s:0.85}With a {s:0.85,C:attention}Common{s:0.85} Joker, held {s:0.85,C:attention}Steel',
        '{s:0.85}cards give {s:0.85,X:mult,C:white}+X#3#{s:0.85} more each',
        '{s:0.85,C:inactive}(Currently {s:0.85,X:mult,C:white}X#1#{s:0.85,C:inactive})',
    } },
    j_cbuf_rubble_nothing = { name = 'Golden Rubble: Nothing', text = {
        '{s:0.85,C:dark_edition}Negative{s:0.85} editions appear {s:0.85,C:attention}x1.5{s:0.85} as often',
        '{s:0.85}Each round a random {s:0.85,C:attention}rank{s:0.85} and',
        '{s:0.85,C:attention}suit{s:0.85} are {s:0.85,C:red}debuffed',
        '{s:0.85}Beat a Boss Blind with it, then sell:',
        '{s:0.85}a random Joker gets {s:0.85,C:dark_edition}Negative',
        '{s:0.8,C:inactive}#1#',
    } },
}

local function install_loc()
    pcall(function()
        local loc = G and G.localization
        if not (loc and loc.descriptions) or type(loc_parse_string) ~= 'function' then return end
        loc.descriptions.Joker = loc.descriptions.Joker or {}
        for key, e in pairs(ENTRIES) do
            local cur = loc.descriptions.Joker[key]
            if not (cur and cur.text_parsed and cur.name_parsed) then
                local entry = { name = e.name, text = e.text, name_parsed = { loc_parse_string(e.name) }, text_parsed = {} }
                for _, line in ipairs(e.text) do entry.text_parsed[#entry.text_parsed + 1] = loc_parse_string(line) end
                loc.descriptions.Joker[key] = entry
            end
        end
    end)
end
install_loc()
if type(init_localization) == 'function' and not _G._cbuf_rubble_loc then
    _G._cbuf_rubble_loc = true
    local ref = init_localization
    function init_localization(...)
        local r = ref(...)
        install_loc()
        return r
    end
end

local function has_entry(key)
    local d = G and G.localization and G.localization.descriptions and G.localization.descriptions.Joker
    local e = d and d[key]
    return e and e.text_parsed and e.name_parsed and true or false
end

local function curse_list(ex)
    local t = {}
    for _, k in ipairs(ex.curses or {}) do t[#t + 1] = blind_name(k) end
    if #t == 0 then return 'none' end
    return table.concat(t, ', ')
end

local function has_common(except)
    for _, j in ipairs((G and G.jokers and G.jokers.cards) or {}) do
        local c = j.config and j.config.center
        if j ~= except and c and (c.rarity == 1 or c.rarity == 'Common') and not j.debuff then return true end
    end
    return false
end

-- OPENING (selling an activated rubble) -----------------------------------------------------------------
local function pick_mode(card)
    if roll(card, 'cbuf_rubble_gold', 1, CFG.gold_odds) then return 'gold' end
    if pseudorandom('cbuf_rubble_mode') < CFG.silver_share then return 'silver' end
    return 'nothing'
end

local OPEN_TEXT = { gold = { 'Gold!', 'MONEY' }, silver = { 'Silver!', 'CHIPS' }, nothing = { 'Nothing...', 'INACTIVE' } }

if Card and type(Card.sell_card) == 'function' and not Card._cbuf_rubble_sell then
    local sell_ref = Card.sell_card
    function Card:sell_card(...)
        local center = self.config and self.config.center
        local ex = self.ability and self.ability.extra
        if center and center.key == KEY and type(ex) == 'table' and ex.stage == 'ready' then
            local ok, mode = pcall(pick_mode, self)
            if not ok then mode = 'silver' end
            local pay = self.sell_cost or 0
            if self.area and self.area.remove_from_highlighted then
                pcall(self.area.remove_from_highlighted, self.area, self)
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after', delay = 0.2,
                func = function()
                    ex.stage = mode
                    if mode == 'gold' then ex.curses = { ex.boss_key }; ex.fails = 1
                    elseif mode == 'silver' then ex.xmult = 1
                    else ex.won = false end
                    -- sell value to exactly $0
                    self.ability.extra_value = 0
                    self:set_cost()
                    self.ability.extra_value = -(self.sell_cost or 0)
                    self:set_cost()
                    set_frame(self, FRAME[mode])
                    self:juice_up(0.8, 0.8)
                    if type(play_sound) == 'function' then play_sound('coin1') end
                    if pay > 0 and type(ease_dollars) == 'function' then ease_dollars(pay) end
                    local t = OPEN_TEXT[mode]
                    show(self, t[1], G.C[t[2]] or G.C.ATTENTION)
                    log('info', 'opened as ' .. mode)
                    return true
                end,
            }))
            return
        end
        return sell_ref(self, ...)
    end
    Card._cbuf_rubble_sell = true
else
    log('warn', 'Card.sell_card not found: the rubble cannot be opened')
end

-- the Joker ---------------------------------------------------------------------------------------------------
local function stage_label(ex)
    local s = ex.stage or 'inactive'
    if s == 'inactive' then return 'Inactive' end
    if s == 'ready' then return 'Sell me' end
    if s == 'gold' then return 'Gold ' .. #(ex.curses or {}) end
    if s == 'silver' then return 'Silver X' .. fmt(ex.xmult or 1) end
    return 'Nothing'
end

SMODS.Joker {
    key = 'rubble',
    atlas = 'cbuf_rubble',
    pos = { x = 0, y = 0 },
    rarity = 2,
    cost = 5,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = true,
    config = { extra = { stage = 'inactive' } },
    joker_display_def = jd and jd(KEY, function(JokerDisplay)
        return {
            reminder_text = { { ref_table = 'card.joker_display_values', ref_value = 'state' } },
            calc_function = function(card)
                local ex = card.ability and card.ability.extra or {}
                card.joker_display_values.state = '(' .. stage_label(ex) .. ')'
            end,
        }
    end) or nil,
    loc_txt = {
        name = 'Golden Rubble',
        text = {
            '{s:0.85,C:attention}Defeat a Boss Blind{s:0.85} to activate',
            '{s:0.85}Keep it in your Jokers while you do',
            '{s:0.85,C:inactive}Then sell it: it opens as Gold,',
            '{s:0.85,C:inactive}Silver or Nothing',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = card and card.ability and card.ability.extra or {}
        local st = ex.stage
        if st == 'ready' and has_entry('j_cbuf_rubble_ready') then
            return { key = 'j_cbuf_rubble_ready', vars = { ex.boss_name or '?' } }
        elseif st == 'gold' and has_entry('j_cbuf_rubble_gold') then
            local f = ex.fails or 1
            local rn, rd = odds_vars(card, 'cbuf_rubble_rare', math.min(CFG.rare_den, f), CFG.rare_den)
            local ln, ld = odds_vars(card, 'cbuf_rubble_leg', math.min(CFG.legend_den, f), CFG.legend_den)
            return { key = 'j_cbuf_rubble_gold', vars = { rn, rd, ln, ld, curse_list(ex) } }
        elseif st == 'silver' and has_entry('j_cbuf_rubble_silver') then
            return { key = 'j_cbuf_rubble_silver', vars = { fmt(ex.xmult or 1), fmt(CFG.silver_per_hand), fmt(CFG.steel_bonus) } }
        elseif st == 'nothing' and has_entry('j_cbuf_rubble_nothing') then
            local line = 'No debuff right now'
            if ex.dr and ex.ds then line = 'Debuffed now: ' .. tostring(ex.dr_name) .. ' + ' .. tostring(ex.ds) end
            if ex.won then line = line .. '  (Boss beaten: sell for Negative)' end
            return { key = 'j_cbuf_rubble_nothing', vars = { line } }
        end
        return { vars = {} }
    end,
    -- keeps the art in sync with the stage (also right after loading a save)
    update = function(self, card, dt)
        local ex = card and card.ability and card.ability.extra
        local c = card and card.children and card.children.center
        if not (ex and c and c.set_sprite_pos) then return end
        local want = FRAME[ex.stage or 'inactive'] or 0
        if card.cbuf_rub_frame ~= want then set_frame(card, want) end
    end,
    calc_dollar_bonus = function(self, card)
        local ex = card.ability and card.ability.extra
        if ex and ex.stage == 'gold' and (ex.pending or 0) > 0 then
            local v = ex.pending
            ex.pending = 0
            return v
        end
    end,
    remove_from_deck = function(self, card, from_debuff)
        if from_debuff then return end
        pcall(give_back_hand_size, card)
        local ex = card.ability and card.ability.extra
        if ex and ex.stage == 'nothing' then pcall(recalc_all) end
    end,
    calculate = function(self, card, context)
        if context.blueprint then return end
        local ex = card.ability and card.ability.extra
        if not ex then return end

        -- NOTHING: a rank and a suit are debuffed
        if context.debuff_card and ex.stage == 'nothing' and ex.dr then
            local c = context.debuff_card
            if c and c.area ~= G.jokers and c.base then
                local hit = false
                pcall(function() hit = (c:get_id() == ex.dr) or c:is_suit(ex.ds, true) end)
                if hit then return { debuff = true } end
            end
            return
        end

        -- a blind starts
        if context.setting_blind and not context.repetition then
            card.cbuf_proxies = nil
            if ex.stage == 'gold' then
                for _, key in ipairs(ex.curses or {}) do
                    if key ~= cur_blind_key() then
                        local ok, err = pcall(apply_start, card, key)
                        if not ok then log('warn', 'start effect ' .. tostring(key) .. ' failed: ' .. tostring(err)) end
                    end
                end
                if #(ex.curses or {}) > 0 then show(card, 'Cursed!', G.C.RED) end
            elseif ex.stage == 'nothing' then
                local r = RANKS[math.floor(pseudorandom('cbuf_rubble_rank', 1, #RANKS))]
                ex.dr, ex.dr_name = r[1], r[2]
                ex.ds = SUITS[math.floor(pseudorandom('cbuf_rubble_suit', 1, #SUITS))]
                show(card, ex.dr_name .. ' + ' .. ex.ds, G.C.RED)
                recalc_all()
            end
            return
        end

        -- a blind is defeated
        if context.end_of_round and not context.individual and not context.repetition and not context.game_over then
            pcall(give_back_hand_size, card)
            local boss = in_boss()

            if ex.stage == 'inactive' then
                if boss then
                    ex.stage = 'ready'
                    ex.boss_key = cur_blind_key()
                    ex.boss_name = blind_name(ex.boss_key)
                    show(card, 'Activated!', G.C.GREEN)
                    card:juice_up(0.7, 0.7)
                end

            elseif ex.stage == 'gold' then
                local reward = 0
                pcall(function() reward = math.floor((G.GAME.blind.dollars or 0) * CFG.gold_share) end)
                if boss then
                    local f = ex.fails or 1
                    local made
                    if roll(card, 'cbuf_rubble_leg', math.min(CFG.legend_den, f), CFG.legend_den) then made = 'legendary'
                    elseif roll(card, 'cbuf_rubble_rare', math.min(CFG.rare_den, f), CFG.rare_den) then made = 'rare' end
                    if made then
                        show(card, made == 'legendary' and 'Legendary!' or 'Rare!', G.C.GOLD)
                        die(card)
                        G.E_MANAGER:add_event(Event({
                            trigger = 'after', delay = 0.7,
                            func = function()
                                local ok, err = pcall(function()
                                    local t = { set = 'Joker', key_append = 'cbuf_rubble' }
                                    if made == 'legendary' then t.legendary = true else t.rarity = 'Rare' end
                                    SMODS.add_card(t)
                                end)
                                if not ok then log('warn', 'reward failed: ' .. tostring(err)) end
                                return true
                            end,
                        }))
                        return
                    end
                    -- a miss: this Boss's effect joins the stack
                    ex.fails = f + 1
                    local key = cur_blind_key()
                    local has = false
                    for _, k in ipairs(ex.curses or {}) do if k == key then has = true end end
                    if key and not has then
                        ex.curses = ex.curses or {}
                        ex.curses[#ex.curses + 1] = key
                        show(card, '+' .. blind_name(key), G.C.RED)
                    else
                        show(card, 'Miss', G.C.RED)
                    end
                end
                ex.pending = reward
                if reward > 0 then show(card, '+$' .. reward, G.C.MONEY) end

            elseif ex.stage == 'silver' then
                local hands = (G.GAME.current_round and G.GAME.current_round.hands_left) or 0
                if hands > 0 then
                    ex.xmult = round2((ex.xmult or 1) + CFG.silver_per_hand * hands)
                    show(card, '+X' .. fmt(CFG.silver_per_hand * hands), G.C.MULT)
                    card:juice_up(0.5, 0.5)
                end

            elseif ex.stage == 'nothing' then
                ex.dr, ex.ds, ex.dr_name = nil, nil, nil
                recalc_all()
                if boss and not ex.won then
                    ex.won = true
                    show(card, 'Boss beaten!', G.C.GREEN)
                end
            end
            return
        end

        -- SILVER: score and boosted Steel
        if ex.stage == 'silver' then
            if context.joker_main then
                local x = ex.xmult or 1
                if x > 1 then return { xmult = x } end
                return
            end
            if context.individual and context.cardarea == G.hand and not context.end_of_round
                and context.other_card and not context.other_card.debuff then
                local c = context.other_card.config and context.other_card.config.center
                if c and c.key == 'm_steel' and has_common(card) then
                    return { xmult = 1 + CFG.steel_bonus }
                end
            end
        end

        -- NOTHING: selling it after a Boss win makes a random Joker Negative
        if context.selling_self and ex.stage == 'nothing' and ex.won then
            local pool = {}
            for _, j in ipairs((G and G.jokers and G.jokers.cards) or {}) do
                if j ~= card and not j.edition then pool[#pool + 1] = j end
            end
            if #pool > 0 then
                local j = pseudorandom_element(pool, pseudoseed('cbuf_rubble_neg_sell'))
                G.E_MANAGER:add_event(Event({
                    trigger = 'after', delay = 0.4,
                    func = function()
                        local ok = pcall(function() j:set_edition('e_negative', true) end)
                        if not ok then pcall(function() j:set_edition({ negative = true }, true) end) end
                        return true
                    end,
                }))
            end
        end
    end,
}

log('info', 'loaded')
