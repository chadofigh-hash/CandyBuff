-- Candy Buff — JokerDisplay safety net (v1.26.90)
--
-- JokerDisplay (another mod) calculates the little numbers above Jokers every frame. If its definition for ANY
-- Joker hits something unexpected (for example another mod changed that Joker's numbers), the whole game used to
-- crash ("attempt to perform arithmetic on field 'chips' (a nil value)"). Now such an error is caught: that
-- Joker simply shows no number, the game keeps running, and the Lovely log says which Joker it was
-- (search "[CandyBuff] safety").

local function log(msg)
    if type(sendWarnMessage) == 'function' then pcall(sendWarnMessage, '[CandyBuff] safety: ' .. msg, 'CandyBuff') end
end

local function describe(card)
    local key = card and card.config and card.config.center and card.config.center.key or '?'
    local parts = {}
    pcall(function()
        local ex = card.ability and card.ability.extra
        if type(ex) == 'table' then
            for k, v in pairs(ex) do parts[#parts + 1] = tostring(k) .. '=' .. tostring(v) end
            table.sort(parts)
        else
            parts[1] = 'extra=' .. tostring(ex)
        end
    end)
    return key, table.concat(parts, ', ')
end

local seen = {}

local function install()
    if not Card or Card._cbuf_jd_guard or type(Card.calculate_joker_display) ~= 'function' then return false end
    Card._cbuf_jd_guard = true
    local ref = Card.calculate_joker_display
    function Card:calculate_joker_display(...)
        local ok, a, b = pcall(ref, self, ...)
        if not ok then
            local key, extra = describe(self)
            if not seen[key] then
                seen[key] = true
                log('JokerDisplay failed for ' .. key .. ' (ability.extra: ' .. extra .. '): ' .. tostring(a))
            end
            return
        end
        return a, b
    end
    return true
end

if not install() and Card and type(Card.update) == 'function' and not Card._cbuf_jd_retry then
    -- JokerDisplay was not loaded yet: try again on the first frame that updates a card
    Card._cbuf_jd_retry = true
    local ref = Card.update
    function Card:update(dt)
        if not Card._cbuf_jd_guard then install() end
        return ref(self, dt)
    end
end
