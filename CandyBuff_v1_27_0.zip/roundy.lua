-- Candy Buff — Roundy (Rare Joker) (v1.26.53)
--
--   * At the start of every round it picks a number from 2 to 5.
--   * Each hand: (scoring cards, retriggers count) x (the number) = M.
--     Chips and Mult are each rounded UP to the next multiple of M (already a multiple: unchanged); the table starts at the n-th multiple: minimum n x M.
--     Example: 5 scoring cards and the number 5 -> M = 25 -> 130 Chips x 7 Mult becomes 150 x 25.
--   * Done at the very end of scoring (final_scoring_step) by adding the missing Chips and Mult.
--   * The card art is a 12-frame idle loop (breathing, head bounce, twinkles); the swap is driven by the
--     animated-card table in thenik.lua.
--
-- Safety: all hooks are inside pcall; failures go to the Lovely log (search "CandyBuff roundy").

local MOD = SMODS.current_mod

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] roundy: ' .. msg, 'CandyBuff') end
end

local jd = _G.CBUF_API and _G.CBUF_API.jd   -- JokerDisplay helper from candy_core.lua

local MIN_PICK, MAX_PICK = 2, 5
local MAX_SCORE = 1e15                 -- above this the rounding is meaningless and float precision is gone

local function num(x)
    if type(to_number) == 'function' then
        local ok, v = pcall(to_number, x)
        if ok and type(v) == 'number' then return v end
    end
    return tonumber(x) or 0
end

local function show(card, text, colour)
    if card_eval_status_text and G and G.C then
        card_eval_status_text(card, 'extra', nil, nil, nil, { message = text, colour = colour or G.C.ATTENTION })
    end
end

-- 59x81 art (the same ratio as a card, the game scales it). Columns 0..11 = the idle loop.
SMODS.Atlas { key = 'cbuf_roundy', path = 'cbuf_roundy.png', px = 59, py = 81, disable_mipmap = true }

-- Next multiple of M at or above v (already a multiple: unchanged).
-- The table starts at the n-th multiple (n = the picked number): the result is never below n x M.
local function round_next(v, M, n)
    local r = math.ceil(v / M - 1e-9) * M
    local floor_v = M * (n or 1)
    if r < floor_v then r = floor_v end
    return r
end

local function final_step(card, context)
    local ex = card.ability.extra
    local n = ex and ex.pick
    if not n then return nil end
    local hand = context.scoring_hand
    -- every scoring of a card counts, retriggers included (counted in calculate); fallback: scoring cards
    local count = ex.scored or 0
    if count <= 0 then count = (type(hand) == 'table' and #hand) or 0 end
    if count <= 0 then return nil end
    local M = count * n
    local chips, mult = _G.hand_chips, _G.mult
    if chips == nil or mult == nil then
        if not _G.cbuf_roundy_warned then _G.cbuf_roundy_warned = true; log('warn', 'hand_chips / mult not found, no rounding') end
        return nil
    end
    local c, m = num(chips), num(mult)
    if c <= 0 or m <= 0 or c > MAX_SCORE or m > MAX_SCORE then return nil end
    local dc, dm = round_next(c, M, n) - c, round_next(m, M, n) - m
    if dc == 0 and dm == 0 then return nil end
    return {
        chips = dc ~= 0 and dc or nil,
        mult = dm ~= 0 and dm or nil,
        message = n .. 'x' .. count .. '=' .. M,
        colour = G.C.ATTENTION,
        card = card,
    }
end

SMODS.Joker {
    key = 'roundy',
    atlas = 'cbuf_roundy',
    pos = { x = 0, y = 0 },
    rarity = 3,          -- Rare: the n x M floor on Chips and Mult is very strong early on
    cost = 8,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = { pick = nil } },
    -- JokerDisplay support (only used when the JokerDisplay mod is installed).
    joker_display_def = jd and jd('j_cbuf_roundy', function(JokerDisplay)
        return {
            text = {
                { text = 'x' },
                { ref_table = 'card.joker_display_values', ref_value = 'pick' },
            },
            text_config = { colour = G.C.ORANGE },
            reminder_text = {
                { text = '(' },
                { ref_table = 'card.joker_display_values', ref_value = 'step' },
                { text = ')' },
            },
            calc_function = function(card)
                local pick = card.ability.extra and card.ability.extra.pick
                card.joker_display_values.pick = pick and tostring(pick) or '?'
                local count = 0
                local ok, hl = pcall(function() return G.hand and G.hand.highlighted end)
                if ok and type(hl) == 'table' then count = #hl end
                card.joker_display_values.step = (pick and count > 0) and ('M=' .. (pick * count)) or 'cards x number'
            end,
        }
    end) or nil,
    loc_txt = {
        name = 'Roundy',
        text = {
            'Picks a number {C:attention}n{} (2-5) each round',
            'Rounds {C:chips}Chips{} and {C:mult}Mult{} up to a multiple',
            'of {C:attention}cards x n{}, minimum {C:attention}cards x n x n{}',
            '{C:inactive}(Number: #1#){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local pick = card.ability and card.ability.extra and card.ability.extra.pick
        return { vars = { pick and tostring(pick) or '?' } }
    end,
    calculate = function(self, card, context)
        if context.blueprint then return end
        if context.setting_blind then
            local pick = pseudorandom('cbuf_roundy', MIN_PICK, MAX_PICK)
            card.ability.extra.pick = pick
            pcall(function() card:juice_up(0.8, 0.8) end)
            show(card, tostring(pick) .. '!', G.C.ATTENTION)
            return
        end
        if context.before then card.ability.extra.scored = 0 end
        if context.individual and context.cardarea == G.play and not context.end_of_round then
            card.ability.extra.scored = (card.ability.extra.scored or 0) + 1
        end
        if context.final_scoring_step then
            local ok, res = pcall(final_step, card, context)
            if ok then return res end
            log('error', 'final step failed: ' .. tostring(res))
        end
    end,
}

log('info', 'loaded')
