-- Candy Buff — Set of Files (Uncommon Joker) + the Budget modifier (v1.26.99)
--
--   FIRST MODE (active): when one of your OTHER Jokers is about to be destroyed, this Joker saves it by putting a
--     Budget (Level 1) on it: the Joker stays for 2 more rounds, then it is destroyed for real.
--   After giving a Budget it switches to the LATE REPORT mode (inactive for saving):
--     * If you would lose a blind but your score is at least 80% of the requirement, you are rescued
--       ("Rescued by a late report!") and this Joker destroys itself.
--     * If the Budget Joker is destroyed first (its Budget ran out) while the Late Report has not been used,
--       it moves to the SECOND MODE.
--   SECOND MODE: the next Joker to be destroyed is saved by a Budget (Level 2): it stays 1 more round.
--     After giving it, this Joker is permanently inactive.
--
-- "Destroyed" means the game's normal Joker destruction (Card:start_dissolve: Madness, Ankh, Hex, Ceremonial
-- Dagger, SMODS.destroy_cards, ...). Jokers that remove themselves with their own animation (Gros Michel,
-- Cavendish, Ramen ...) are NOT caught. Selling is not destruction.
--
-- Written from reading Steamodded; it could NOT be run inside the game. Failures go to the Lovely log
-- (search "[CandyBuff] files").

local KEY = 'j_cbuf_files'
local BUDGET = 'cbuf_budget'

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] files: ' .. msg, 'CandyBuff') end
end

local jd = _G.CBUF_API and _G.CBUF_API.jd

local CFG = {
    lv1_rounds = 2,          -- Budget Level 1: extra rounds
    lv2_rounds = 1,          -- Budget Level 2: extra rounds
    report_pct = 0.8,        -- late report: needs this share of the blind requirement
}

-- frames of the Joker: 0 = ready (saves a Joker), 1 = inactive (waiting for the late report, and the permanent
-- inactive state), 2 = second mode (after the Budget Joker was destroyed)
local FRAME = { a = 0, b = 1, c = 2, d = 1 }
SMODS.Atlas { key = 'cbuf_files', path = 'cbuf_files.png', px = 71, py = 95, disable_mipmap = true }
SMODS.Atlas { key = 'cbuf_budget', path = 'cbuf_budget.png', px = 71, py = 95, disable_mipmap = true }

local function show(card, text, colour)
    if card_eval_status_text and G and G.C then
        pcall(card_eval_status_text, card, 'extra', nil, nil, nil, { message = text, colour = colour or G.C.ATTENTION })
    end
end

local function set_frame(card, f)
    local c = card and card.children and card.children.center
    if c and c.set_sprite_pos then
        c:set_sprite_pos({ x = f, y = 0 })
        card.cbuf_files_frame = f
    end
end

-- BUDGET: a modifier category of its own (not a Sticker, Edition or Seal) ----------------------------------------
-- A Joker can carry one Budget at the same time as Stickers and an Edition. It lives in card.ability.cbuf_budget
-- ({ level, rounds, src }), so it is saved with the run. This file draws it, writes its tooltip, and runs it down.
-- The Budget definitions are also published as SMODS.Budgets so other mods can read them.
local BUDGETS = {
    [1] = { key = 'cbuf_budget_lv1', name = 'Budget Level 1', rounds = CFG.lv1_rounds },
    [2] = { key = 'cbuf_budget_lv2', name = 'Budget Level 2', rounds = CFG.lv2_rounds },
}
SMODS.Budgets = SMODS.Budgets or BUDGETS

-- one description per (level, rounds left), with the numbers written in (no variables to go wrong)
local BUDGET_TEXT = {}
local function budget_key(level, rounds)
    return 'cbuf_budget_l' .. tostring(level) .. '_r' .. tostring(rounds)
end
for level = 1, 2 do
    for rounds = 1, 5 do
        BUDGET_TEXT[budget_key(level, rounds)] = {
            name = 'Budget Level ' .. level,
            text = {
                'Saved from destruction',
                'by a {C:attention}Set of Files{}',
                '{C:attention}' .. rounds .. '{} more round' .. (rounds == 1 and '' or 's') .. ',',
                'then it is {C:red}destroyed{}',
            },
        }
    end
end

local function budget_state(card)
    local st = card and card.ability and card.ability[BUDGET]
    if type(st) == 'table' then return st end
end

-- the picture: one shared sprite, frame = level - 1
local budget_sprite
local function get_budget_sprite()
    if budget_sprite then return budget_sprite end
    local atlas = G and G.ASSET_ATLAS and G.ASSET_ATLAS['cbuf_budget']
    if not atlas then return nil end
    budget_sprite = Sprite(0, 0, G.CARD_W, G.CARD_H, atlas, { x = 0, y = 0 })
    return budget_sprite
end

local function draw_budget(card, st)
    local sp = get_budget_sprite()
    if not (sp and card.children and card.children.center and card.ARGS) then return end
    sp:set_sprite_pos({ x = math.min(2, math.max(1, st.level or 1)) - 1, y = 0 })
    sp.role.draw_major = card
    sp:draw_shader('dissolve', nil, nil, nil, card.children.center)
    sp:draw_shader('voucher', nil, card.ARGS.send_to_shader, nil, card.children.center)
end

if Card and type(Card.draw) == 'function' and not Card._cbuf_budget_draw then
    Card._cbuf_budget_draw = true
    local ref = Card.draw
    function Card:draw(layer, ...)
        local r = ref(self, layer, ...)
        if (layer == nil or layer == 'card' or layer == 'both') and self.facing ~= 'back' then
            local st = budget_state(self)
            if st then
                local ok, err = pcall(draw_budget, self, st)
                if not ok and not Card._cbuf_budget_draw_warned then
                    Card._cbuf_budget_draw_warned = true
                    log('warn', 'could not draw the Budget: ' .. tostring(err))
                end
            end
        end
        return r
    end
end

-- the tooltip: a "Budget" box next to the card's other info boxes
-- adds an info box to a card's UI table; the card's badges are hidden meanwhile (they crash the 'Other' branch)
local function add_info_box(r, key)
    local saved = r.badges
    r.badges = nil
    local ok, err = pcall(function() generate_card_ui({ key = key, set = 'Other' }, r) end)
    r.badges = saved
    if not ok then error(err, 0) end
end

if type(generate_card_ui) == 'function' and not _G._cbuf_budget_ui then
    _G._cbuf_budget_ui = true
    local ref = generate_card_ui
    function generate_card_ui(_c, full_UI_table, specific_vars, card_type, badges, hide_desc, main_start, main_end, card, ...)
        -- Collection > Budgets: show ONLY the Budget's own description (like Editions do), not the Joker's
        local only = card and card.cbuf_budget_only
        if only then
            local st0 = budget_state(card)
            if st0 then
                local lv = math.min(2, math.max(1, st0.level or 1))
                local rd = math.min(5, math.max(1, st0.rounds or 1))
                return ref({ key = budget_key(lv, rd), set = 'Other' }, full_UI_table, specific_vars, 'Other',
                    nil, hide_desc, main_start, main_end, nil, ...)
            end
        end
        local r = ref(_c, full_UI_table, specific_vars, card_type, badges, hide_desc, main_start, main_end, card, ...)
        pcall(function()
            -- the Set of Files Joker itself: side box that explains the Budget (its description no longer does)
            local ex = card and card.config and card.config.center and card.config.center.key == KEY
                and card.ability and card.ability.extra
            if ex and r and r.info then
                local bl = ({ a = 'cbuf_budget_l1_r2', c = 'cbuf_budget_l2_r1' })[ex.stage or 'a']
                if bl then add_info_box(r, bl) end
            end
            local st = card and budget_state(card)
            if st and r and r.info then
                local level = math.min(2, math.max(1, st.level or 1))
                local rounds = math.min(5, math.max(1, st.rounds or 1))
                -- same table as the card's own UI, so the game appends a normal info box (like info_queue does)
                add_info_box(r, budget_key(level, rounds))
            end
        end)
        return r
    end
end

-- Collection: a "Budgets" button (Collection > Other) that shows both levels on example Jokers ------------
function G.FUNCS.your_collection_cbuf_budgets(e)
    G.SETTINGS.paused = true
    G.FUNCS.overlay_menu { definition = create_UIBox_your_collection_cbuf_budgets() }
end

function create_UIBox_your_collection_cbuf_budgets()
    local area = CardArea(G.ROOM.T.x + 0.2 * G.ROOM.T.w / 2, G.ROOM.T.h, 3.4 * G.CARD_W, 1.05 * G.CARD_H,
        { card_limit = 2, type = 'title', highlight_limit = 0, collection = true })
    local center = G.P_CENTERS['j_cbuf_files'] or G.P_CENTERS['j_joker']
    for level = 1, 2 do
        local card = Card(area.T.x + area.T.w / 2, area.T.y, G.CARD_W, G.CARD_H, nil, center,
            { bypass_discovery_center = true, bypass_discovery_ui = true })
        card.ability[BUDGET] = { level = level, rounds = BUDGETS[level].rounds }
        card.cbuf_budget_only = true
        area:emplace(card)
    end
    local function line(text, scale, colour)
        return { n = G.UIT.R, config = { align = 'cm', padding = 0.05 }, nodes = {
            { n = G.UIT.T, config = { text = text, scale = scale, colour = colour or G.C.WHITE, shadow = true } } } }
    end
    return create_UIBox_generic_options({
        back_func = 'your_collection_other_gameobjects',
        contents = {
            line('Budget', 0.7),
            { n = G.UIT.R, config = { align = 'cm', padding = 0.2, no_fill = true }, nodes = {
                { n = G.UIT.O, config = { object = area } } } },
            line('Level 1: ' .. BUDGETS[1].rounds .. ' more rounds     Level 2: ' .. BUDGETS[2].rounds .. ' more round', 0.4, G.C.UI.TEXT_LIGHT),
            line('Hover a card to read it', 0.35, G.C.UI.TEXT_INACTIVE),
        },
    })
end

if SMODS.current_mod then
    local prev = SMODS.current_mod.custom_collection_tabs
    SMODS.current_mod.custom_collection_tabs = function()
        local tabs = type(prev) == 'function' and prev() or {}
        tabs[#tabs + 1] = UIBox_button({
            button = 'your_collection_cbuf_budgets', label = { 'Budgets' }, minw = 5, minh = 1.7,
            id = 'your_collection_cbuf_budgets', focus_args = { snap_to = true },
        })
        return tabs
    end
else
    log('warn', 'SMODS.current_mod not available: no Budgets button in the Collection')
end

-- Budget running down: once per round, when a round ends -------------------------------------------------------
local function tick_budgets()
    local round = G and G.GAME and G.GAME.round
    for _, card in ipairs((G and G.jokers and G.jokers.cards) or {}) do
        local st = budget_state(card)
        if st and not card.cbuf_expiring and not st.dead then
            if not (st.last_round ~= nil and st.last_round == round) then
                st.last_round = round
                st.rounds = (st.rounds or 0) - 1
                if st.rounds > 0 then
                    show(card, 'Budget: ' .. st.rounds, G.C.ATTENTION)
                else
                    show(card, 'Out of budget', G.C.RED)
                    card.cbuf_expiring = true
                    card.getting_sliced = true
                    pcall(_G.CBUF_FILES_DEAD, card)
                    G.E_MANAGER:add_event(Event({
                        trigger = 'after', delay = 0.4,
                        func = function()
                            pcall(function() card:start_dissolve({ G.C.RED }, nil, 1.6) end)
                            return true
                        end,
                    }))
                end
            end
        end
    end
end

if SMODS and type(SMODS.calculate_context) == 'function' and not SMODS._cbuf_budget_hooked then
    SMODS._cbuf_budget_hooked = true
    local ref = SMODS.calculate_context
    SMODS.calculate_context = function(context, ...)
        if type(context) == 'table' and context.end_of_round and not context.individual and not context.repetition
            and not context.game_over and not context.cbuf_budget_seen then
            local ok, err = pcall(tick_budgets)
            if not ok then log('warn', 'budget tick failed: ' .. tostring(err)) end
        end
        return ref(context, ...)
    end
end

-- helpers --------------------------------------------------------------------------------------------------------
local function each_files(fn)
    for _, j in ipairs((G and G.jokers and G.jokers.cards) or {}) do
        local ex = j.ability and j.ability.extra
        if j.config and j.config.center and j.config.center.key == KEY and type(ex) == 'table' and not j.debuff then
            if fn(j, ex) then return true end
        end
    end
    return false
end

local function put_budget(card, level, rounds, src)
    card.ability[BUDGET] = { level = level, rounds = rounds, src = src }
end

-- the Joker with a Budget has really died: a Level 1 Budget wakes the Files that gave it
function _G.CBUF_FILES_DEAD(card)
    local st = card and card.ability and card.ability[BUDGET]
    if type(st) ~= 'table' or st.dead then return end
    st.dead = true
    if st.level ~= 1 then return end
    each_files(function(f, ex)
        if f.sort_id == st.src and ex.stage == 'b' then
            ex.stage = 'c'
            show(f, 'Second mode', G.C.ATTENTION)
            return true
        end
    end)
end

-- called when `card` is about to be destroyed. Returns true if it was saved.
local function try_save(card)
    if not (card and card.ability and card.ability.set == 'Joker' and G and G.jokers and card.area == G.jokers) then return false end
    if G.STAGE ~= G.STAGES.RUN or card.cbuf_expiring or card.cbuf_selling then return false end
    local st = card.ability[BUDGET]
    if type(st) == 'table' then                 -- it already has a Budget: this destruction is real
        pcall(_G.CBUF_FILES_DEAD, card)
        return false
    end
    local saved = false
    each_files(function(f, ex)
        if f == card then return false end
        if ex.stage == 'a' then
            put_budget(card, 1, CFG.lv1_rounds, f.sort_id)
            ex.stage = 'b'
            show(f, 'Budget!', G.C.GREEN)
            saved = true
        elseif ex.stage == 'c' then
            put_budget(card, 2, CFG.lv2_rounds, f.sort_id)
            ex.stage = 'd'
            show(f, 'Budget! (Lv.2)', G.C.GREEN)
            saved = true
        end
        return saved
    end)
    if saved then
        card.getting_sliced = nil
        card.destroyed = nil
        pcall(function() card:juice_up(0.6, 0.6) end)
        show(card, 'Saved!', G.C.GREEN)
        log('info', 'saved a Joker from destruction')
    end
    return saved
end

-- the hooks ---------------------------------------------------------------------------------------------------------
if Card and type(Card.start_dissolve) == 'function' and not Card._cbuf_files_dissolve then
    Card._cbuf_files_dissolve = true
    local ref = Card.start_dissolve
    function Card:start_dissolve(...)
        local ok, saved = pcall(try_save, self)
        if ok and saved then return end
        if not ok then log('warn', 'try_save failed: ' .. tostring(saved)) end
        return ref(self, ...)
    end
else
    log('warn', 'Card.start_dissolve not found: the Set of Files cannot save Jokers')
end

-- selling is not destruction
if Card and type(Card.sell_card) == 'function' and not Card._cbuf_files_sell then
    Card._cbuf_files_sell = true
    local ref = Card.sell_card
    function Card:sell_card(...)
        self.cbuf_selling = true
        return ref(self, ...)
    end
end

-- "Saved by a late report" text for the game-over screen
local function install_loc()
    pcall(function()
        local loc = G and G.localization
        if loc and loc.misc and loc.misc.dictionary then
            loc.misc.dictionary.ph_cbuf_late_report = 'Rescued by a late report'
        end
        if not (loc and loc.descriptions) or type(loc_parse_string) ~= 'function' then return end
        loc.descriptions.Joker = loc.descriptions.Joker or {}
        loc.descriptions.Other = loc.descriptions.Other or {}
        for key, e in pairs(BUDGET_TEXT) do
            local cur = loc.descriptions.Other[key]
            if not (cur and cur.text_parsed and cur.name_parsed) then
                local entry = { name = e.name, text = e.text, name_parsed = { loc_parse_string(e.name) }, text_parsed = {} }
                for _, line in ipairs(e.text) do entry.text_parsed[#entry.text_parsed + 1] = loc_parse_string(line) end
                loc.descriptions.Other[key] = entry
            end
        end
        for key, e in pairs(_G.CBUF_FILES_ENTRIES or {}) do
            local cur = loc.descriptions.Joker[key]
            if not (cur and cur.text_parsed and cur.name_parsed) then
                local entry = { name = e.name, text = e.text, name_parsed = { loc_parse_string(e.name) }, text_parsed = {} }
                for _, line in ipairs(e.text) do entry.text_parsed[#entry.text_parsed + 1] = loc_parse_string(line) end
                loc.descriptions.Joker[key] = entry
            end
        end
    end)
end

_G.CBUF_FILES_ENTRIES = {
    j_cbuf_files_b = { name = 'Set of Files: Late report', text = {
        '{s:0.85,C:attention}Late report{s:0.85}: if you would lose a',
        '{s:0.85}blind with {s:0.85,C:attention}80%{s:0.85} of its requirement, you',
        '{s:0.85}are rescued, then this Joker breaks',
        '{s:0.85}If the {s:0.85,C:attention}Budget{s:0.85} Joker is destroyed first,',
        '{s:0.85}it moves to the {s:0.85,C:attention}Second mode',
    } },
    j_cbuf_files_c = { name = 'Set of Files: Second mode', text = {
        '{s:0.85}Saves the next Joker that would be',
        '{s:0.85,C:red}destroyed{s:0.85}, then this Joker is',
        '{s:0.85,C:red}permanently inactive',
    } },
    j_cbuf_files_d = { name = 'Set of Files: Inactive', text = {
        '{s:0.85,C:inactive}All files have been handed out.',
        '{s:0.85,C:inactive}This Joker is permanently inactive',
    } },
}
install_loc()
if type(init_localization) == 'function' and not _G._cbuf_files_loc then
    _G._cbuf_files_loc = true
    local ref = init_localization
    function init_localization(...)
        local r = ref(...)
        install_loc()
        return r
    end
end

local function has_entry(key)
    local d = G and G.localization and G.localization.descriptions and G.localization.descriptions.Joker
    local e = d and d[key]
    return e and e.text_parsed and e.name_parsed and true or false
end

local LABEL = { a = 'Ready', b = 'Late report', c = 'Second mode', d = 'Inactive' }

SMODS.Joker {
    key = 'files',
    atlas = 'cbuf_files',
    pos = { x = 0, y = 0 },
    rarity = 2,
    cost = 6,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = { stage = 'a' } },
    joker_display_def = jd and jd(KEY, function(JokerDisplay)
        return {
            reminder_text = { { ref_table = 'card.joker_display_values', ref_value = 'state' } },
            calc_function = function(card)
                local ex = card.ability and card.ability.extra or {}
                card.joker_display_values.state = '(' .. (LABEL[ex.stage or 'a'] or '?') .. ')'
            end,
        }
    end) or nil,
    loc_txt = {
        name = 'Set of Files',
        text = {
            '{s:0.85}Saves a Joker that would be',
            '{s:0.85,C:red}destroyed{s:0.85}, then waits for a',
            '{s:0.85,C:attention}late report',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = card and card.ability and card.ability.extra or {}
        local key = 'j_cbuf_files_' .. tostring(ex.stage or 'a')
        if ex.stage and ex.stage ~= 'a' and has_entry(key) then return { key = key, vars = {} } end
        return { vars = {} }
    end,
    update = function(self, card, dt)
        local ex = card and card.ability and card.ability.extra
        local c = card and card.children and card.children.center
        if not (ex and c and c.set_sprite_pos) then return end
        local want = FRAME[ex.stage or 'a'] or 0
        if card.cbuf_files_frame ~= want then set_frame(card, want) end
    end,
    calculate = function(self, card, context)
        if context.blueprint then return end
        local ex = card.ability and card.ability.extra
        if not ex then return end
        -- LATE REPORT: rescue a lost blind that reached 80% of its requirement
        if ex.stage == 'b' and context.end_of_round and context.game_over then
            local ok, enough = pcall(function()
                local need, got = G.GAME.blind.chips, G.GAME.chips
                return got / need >= CFG.report_pct
            end)
            if ok and enough then
                card.cbuf_expiring = true                     -- no other Files may "save" it from this
                ex.stage = 'd'
                G.E_MANAGER:add_event(Event({
                    func = function()
                        pcall(function()
                            G.hand_text_area.blind_chips:juice_up()
                            G.hand_text_area.game_chips:juice_up()
                            play_sound('tarot1')
                            card:start_dissolve()
                        end)
                        return true
                    end,
                }))
                return { message = 'Rescued by a late report!', saved = 'ph_cbuf_late_report', colour = G.C.RED }
            end
        end
    end,
}

log('info', 'loaded')
