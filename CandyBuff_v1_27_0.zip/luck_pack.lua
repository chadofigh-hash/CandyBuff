-- Candy Buff — Joker of Luck packs (v1.26.67)
--
-- Booster packs that only offer Jokers whose DESCRIPTION has a probability of any kind
-- ("1 in 4", "chance", "probability", "odds"), as long as the Joker can normally show up in the shop
-- (not Legendary, unlocked, allowed by its pool rules). The list is worked out when the pack opens, so it
-- also picks up Jokers from other mods. Normal / Jumbo / Mega sizes.
--
-- In the Test Your Luck deck one free pack opens when a new run starts. The packs never appear in the shop (weight 0).
--
-- Everything you may want to tweak is in CFG below.
-- Safety: all hooks are inside pcall; failures go to the Lovely log (search "CandyBuff luck_pack").

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] luck_pack: ' .. msg, 'CandyBuff') end
end

local CFG = {
    open_at_run_start = true,      -- Test Your Luck deck: one free pack when a new run starts
    open_weights = { normal = 6, jumbo = 3, mega = 1 },   -- which size opens
}

local DECK_KEY = 'b_cbuf_luck_test'

local function deck_active()
    local b = G and G.GAME and G.GAME.selected_back
    return b and b.effect and b.effect.center and b.effect.center.key == DECK_KEY
end

SMODS.Atlas { key = 'cbuf_luck_boosters', path = 'cbuf_luck_boosters.png', px = 71, py = 95, disable_mipmap = true }

-- What a pack offers -------------------------------------------------------------------
local open_pack = { owner = nil, picked = {}, list = nil }
local NEVER = { j_cbuf_menos = true, j_cbuf_pile_of_rocks = true }

local function description_text(center)
    local loc = G and G.localization and G.localization.descriptions
    local entry = loc and loc.Joker and loc.Joker[center.key]
    local lines = (entry and entry.text) or (center.loc_txt and center.loc_txt.text) or {}
    local t = {}
    for _, line in ipairs(lines) do t[#t + 1] = tostring(line) end
    return table.concat(t, ' '):lower()
end

local function mentions_probability(text)
    if text:find('chance', 1, true) or text:find('probab', 1, true) or text:find('odds', 1, true) then
        return true
    end
    return text:find('%d+%s+in%s+%d+') ~= nil or text:find('#%d+#%s+in%s+#%d+#') ~= nil
end

-- Could this Joker show up in a normal shop?
local function shop_possible(center)
    if not center or center.set ~= 'Joker' or center.no_collection or NEVER[center.key] then return false end
    if center.unlocked == false then return false end
    local r = center.rarity
    local ok_rarity = (r == 1 or r == 2 or r == 3 or r == 'Common' or r == 'Uncommon' or r == 'Rare')
    if not ok_rarity and r ~= nil and r ~= 4 and SMODS and SMODS.Rarities and SMODS.Rarities[r] then
        ok_rarity = (SMODS.Rarities[r].default_weight or 0) > 0
    end
    if not ok_rarity then return false end
    local flags = G.GAME and G.GAME.pool_flags or {}
    if center.no_pool_flag and flags[center.no_pool_flag] then return false end
    if center.yes_pool_flag and not flags[center.yes_pool_flag] then return false end
    if G.GAME and G.GAME.banned_keys and G.GAME.banned_keys[center.key] then return false end
    if type(center.in_pool) == 'function' then
        local ok, res = pcall(center.in_pool, center, { source = 'shop' })
        if ok and res == false then return false end
    end
    return true
end

local function build_list()
    local list = {}
    local pool = G and G.P_CENTER_POOLS and G.P_CENTER_POOLS.Joker or {}
    for _, center in ipairs(pool) do
        if shop_possible(center) and mentions_probability(description_text(center)) then
            list[#list + 1] = center.key
        end
    end
    return list
end

local function owned_keys()
    local t = {}
    if G and G.jokers and G.jokers.cards then
        for _, c in ipairs(G.jokers.cards) do
            local k = c.config and c.config.center and c.config.center.key
            if k then t[k] = true end
        end
    end
    return t
end

local function pick(seed)
    local owned = owned_keys()
    local fresh, fresh_unowned = {}, {}
    for _, k in ipairs(open_pack.list or {}) do
        if not open_pack.picked[k] then
            fresh[#fresh + 1] = k
            if not owned[k] then fresh_unowned[#fresh_unowned + 1] = k end
        end
    end
    local from = (#fresh_unowned > 0) and fresh_unowned or fresh
    -- Rare Jokers (see oops.lua) show up less often here too
    local rare = _G.CBUF_RARE
    if rare then
        local kept = {}
        for i, k in ipairs(from) do
            local cut = rare[k]
            if not (cut and pseudorandom(seed .. 'rare' .. k .. i) < cut) then kept[#kept + 1] = k end
        end
        if #kept > 0 then from = kept end
    end
    if #from == 0 then return nil end
    local ante = (G.GAME and G.GAME.round_resets and G.GAME.round_resets.ante) or 1
    local key = pseudorandom_element(from, pseudoseed(seed .. tostring(ante) .. tostring(#fresh)))
    if key then open_pack.picked[key] = true end
    return key
end

-- The packs -----------------------------------------------------------------------------
local SIZES = {
    { id = 'normal', frame = 0, extra = 3, choose = 1, cost = 6, weight = 0.3,  title = '' },
    { id = 'jumbo',  frame = 1, extra = 5, choose = 1, cost = 8, weight = 0.15, title = 'Jumbo ' },
    { id = 'mega',   frame = 2, extra = 5, choose = 2, cost = 10, weight = 0.04, title = 'Mega ' },
}

for _, size in ipairs(SIZES) do
    SMODS.Booster {
        key = 'luck_pack_' .. size.id,
        kind = 'cbuf_luck',
        atlas = 'cbuf_luck_boosters',
        pos = { x = size.frame, y = 0 },
        weight = 0,                       -- never in the shop; only the Test Your Luck deck gives it
        cost = size.cost,
        config = { extra = size.extra, choose = size.choose },
        discovered = true,
        draw_hand = false,
        loc_txt = {
            name = size.title .. 'Joker of Luck Pack',
            group_name = 'Joker of Luck',
            text = {
                'Choose {C:attention}#1#{} of up to',
                '{C:attention}#2#{} Jokers with a {C:green}probability{}',
            },
        },
        ease_background_colour = function(self)
            if type(ease_background_colour_blind) == 'function' then
                ease_background_colour_blind(G.STATES.BUFFOON_PACK)
            end
        end,
        particles = function(self)
            G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
                timer = 0.015, scale = 0.2, initialize = true, lifespan = 1, speed = 1.1, padding = -1,
                attach = G.ROOM_ATTACH,
                colours = { G.C.WHITE, G.C.GREEN, G.C.GOLD, lighten(G.C.GREEN, 0.4) },
                fill = true,
            })
            G.booster_pack_sparkles.fade_alpha = 1
            G.booster_pack_sparkles:fade(1, 0)
        end,
        create_card = function(self, card, i)
            if i == 1 or open_pack.owner ~= card then
                open_pack.owner = card
                open_pack.picked = {}
                local ok_l, list = pcall(build_list)
                open_pack.list = ok_l and list or {}
                if not ok_l then log('error', 'build_list failed: ' .. tostring(list)) end
            end
            local ok, k = pcall(pick, 'cbuf_luck_pack')
            if not ok then log('error', 'pick failed: ' .. tostring(k)); k = nil end
            if k then
                return { key = k, area = G.pack_cards, skip_materialize = true, key_append = 'cbuf_luck_pack' }
            end
            return { set = 'Joker', area = G.pack_cards, skip_materialize = true, key_append = 'cbuf_luck_pack' }
        end,
    }
end

-- Test Your Luck: a free pack at the start of every round ---------------------------------
local function pick_size()
    local total = 0
    for _, w in pairs(CFG.open_weights) do total = total + w end
    local r = pseudorandom('cbuf_luck_pack_size') * total
    for _, id in ipairs({ 'normal', 'jumbo', 'mega' }) do
        r = r - (CFG.open_weights[id] or 0)
        if r < 0 then return id end
    end
    return 'normal'
end

local function open_free_pack()
    local key = 'p_cbuf_luck_pack_' .. pick_size()
    if not (G.P_CENTERS and G.P_CENTERS[key]) then return end
    -- same way the Booster Tags open their pack
    local card = Card(G.play.T.x + G.play.T.w / 2 - G.CARD_W * 1.27 / 2,
        G.play.T.y + G.play.T.h / 2 - G.CARD_H * 1.27 / 2,
        G.CARD_W * 1.27, G.CARD_H * 1.27, G.P_CARDS.empty, G.P_CENTERS[key],
        { bypass_discovery_center = true, bypass_discovery_ui = true })
    card.cost = 0
    card.from_tag = true
    G.FUNCS.use_card({ config = { ref_table = card } })
    card:start_materialize()
end

-- Opens once, when a NEW run starts (the first blind-select screen). Continuing a saved run does not reopen it.
local function schedule_open()
    local tries = 0
    G.E_MANAGER:add_event(Event({
        trigger = 'after', delay = 0.5, blocking = false, blockable = false,
        func = function()
            if not (G and G.GAME and deck_active()) then return true end
            tries = tries + 1
            if tries > 400 then return true end
            if G.STATE ~= G.STATES.BLIND_SELECT or not G.STATE_COMPLETE
                or (G.CONTROLLER and G.CONTROLLER.locked) or not G.blind_select then
                return false                      -- wait until the blind select screen is up
            end
            local ok, err = pcall(open_free_pack)
            if not ok then log('error', 'free pack failed: ' .. tostring(err)) end
            return true
        end }))
end

if CFG.open_at_run_start and Game and type(Game.start_run) == 'function' and not Game._cbuf_luckpack_hooked then
    Game._cbuf_luckpack_hooked = true
    local ref = Game.start_run
    function Game:start_run(args, ...)
        local r = ref(self, args, ...)
        pcall(function()
            local saved = type(args) == 'table' and args.savetext
            if deck_active() and not saved then schedule_open() end
        end)
        return r
    end
end

log('info', 'loaded')
