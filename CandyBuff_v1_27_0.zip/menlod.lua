-- Candy Buff — Menlod's Capsule (Uncommon Joker) (v1.26.59)
--
--   * Picks a random poker hand and keeps it HIDDEN (the card shows "???").
--   * The first time you score that hand in a round, it is revealed for the rest of the round and
--     the Capsule either LEVELS UP that hand or RETRIGGERS the scoring cards of that hand (50/50).
--     That happens once per round.
--   * When the round ends it picks a new hand and hides it again.
--   * A new Capsule does nothing until a round has ended after you got it.
--   * Every copy works on its own, so copies stack.
--
-- Everything you may want to tweak is in CFG below.
-- Safety: failures go to the Lovely log (search "CandyBuff menlod").

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] menlod: ' .. msg, 'CandyBuff') end
end

local jd = _G.CBUF_API and _G.CBUF_API.jd   -- JokerDisplay helper from candy_core.lua

local CFG = {
    levelup_chance = 0.5,   -- chance for "level up"; otherwise it retriggers the hand
    levels = 1,             -- levels gained when it levels the hand up
    repetitions = 1,        -- extra triggers when it retriggers the hand
}

local RED = HEX and HEX('D9553E') or (G and G.C and G.C.RED)

-- A random hand the player can already see in the run-info list (secret hands stay out until found).
local function pick_hand()
    local list = {}
    local hands = G and G.GAME and G.GAME.hands
    if not hands then return nil end
    for _, k in ipairs(G.handlist or {}) do
        if hands[k] and hands[k].visible then list[#list + 1] = k end
    end
    if #list == 0 then
        for k, h in pairs(hands) do
            if h.visible then list[#list + 1] = k end
        end
        table.sort(list)
    end
    if #list == 0 then return 'High Card' end
    return list[math.floor(pseudorandom('cbuf_menlod_pick') * #list) + 1]
end

local function hand_name(key)
    if not key then return '???' end
    local ok, name = pcall(localize, key, 'poker_hands')
    if ok and type(name) == 'string' and name ~= 'ERROR' then return name end
    return tostring(key)
end

SMODS.Atlas { key = 'cbuf_menlod', path = 'cbuf_menlod.png', px = 71, py = 95, disable_mipmap = true }

SMODS.Joker {
    key = 'menlod',
    atlas = 'cbuf_menlod',
    pos = { x = 0, y = 0 },
    rarity = 2,
    cost = 6,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    allow_duplicates = true,
    config = { extra = { target = nil, revealed = false, used = false, armed = false, retrigger = false } },
    joker_display_def = jd and jd('j_cbuf_menlod', function(JokerDisplay)
        return {
            reminder_text = { { ref_table = 'card.joker_display_values', ref_value = 'state' } },
            calc_function = function(card)
                local ex = card.ability and card.ability.extra or {}
                card.joker_display_values.state = '(' .. ((ex.revealed and hand_name(ex.target)) or '???') .. ')'
            end,
        }
    end) or nil,
    loc_txt = {
        name = "Menlod's Capsule",
        text = {
            '{s:0.85}A hidden hand is chosen',
            '{s:0.85}Score it to {s:0.85,C:attention}reveal{s:0.85} it and',
            '{s:0.85,C:attention}level up{s:0.85} or {s:0.85,C:attention}retrigger{s:0.85} it',
            '{s:0.85}Once per round, then it hides again',
            '{s:0.85,V:1}#1#{s:0.85}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = card and card.ability and card.ability.extra or {}
        local text, colour
        if not ex.armed then
            text, colour = 'Wakes after this round ends', G and G.C and G.C.UI and G.C.UI.TEXT_INACTIVE
        elseif ex.revealed then
            text, colour = 'Hand: ' .. hand_name(ex.target), RED
        else
            text, colour = 'Hand: ???', G and G.C and G.C.UI and G.C.UI.TEXT_INACTIVE
        end
        return { vars = { text, colours = { colour or { 0.6, 0.6, 0.6, 1 } } } }
    end,
    add_to_deck = function(self, card, from_debuff)
        if from_debuff then return end
        local ex = card.ability.extra
        ex.armed, ex.revealed, ex.used, ex.retrigger = false, false, false, false
        ex.target = ex.target or pick_hand()
    end,
    calculate = function(self, card, context)
        if context.blueprint then return end
        local ex = card.ability.extra

        -- Round over: wake up (first time), pick a new hidden hand, reset.
        if context.end_of_round and not context.individual and not context.repetition and not context.game_over then
            ex.armed = true
            ex.revealed = false
            ex.used = false
            ex.retrigger = false
            ex.target = pick_hand()
            return
        end

        if not ex.armed then return end

        -- The hidden hand was scored.
        if context.before and not ex.used and ex.target and context.scoring_name == ex.target then
            ex.used = true
            ex.revealed = true
            if pseudorandom('cbuf_menlod_effect') < CFG.levelup_chance then
                return {
                    message = hand_name(ex.target),
                    colour = RED,
                    extra = { level_up = CFG.levels, message = localize('k_level_up_ex'), colour = RED },
                }
            else
                ex.retrigger = true
                return { message = hand_name(ex.target), colour = RED }
            end
        end

        -- Retrigger the scoring cards of that hand (only on the hand that was just found).
        if context.repetition and context.cardarea == G.play and ex.retrigger then
            return { repetitions = CFG.repetitions, message = localize('k_again_ex') }
        end

        if context.after then ex.retrigger = false end
    end,
}

log('info', 'loaded')
