-- cbuf_achievements.lua
-- إنجازات مود CandyBuff بنمط ستيم (تظهر في شاشة الإنجازات داخل بالاترو).
-- ضع الملف داخل مجلد المود، ثم أضف هذا السطر في ملف المود الرئيسي:
--   assert(SMODS.load_file("cbuf_achievements.lua"))()
--
-- ملاحظة مهمة: هذه إنجازات داخل المود فقط. لا يمكن لأي مود منح إنجاز
-- حقيقي في حساب ستيم، لأن ستيم يقبله فقط من اللعبة الأصلية.
--
-- غير موثق بالكامل: لم أستطع قراءة صفحة SMODS.Achievement الرسمية أثناء الكتابة،
-- لذلك الحقول أدناه (key, unlock_condition, check_for_unlock, misc.achievement_*)
-- مكتوبة من معرفة عامة. قارنها بـ docs.smods.dev ثم جرّب.

SMODS.Achievement({
    key = "first_candy_win",
    order = 1,
    -- يفتح عند الفوز بجولة وأنت في Ante 2 أو أعلى
    unlock_condition = function(self, args)
        if args.type == "round_win" and G.GAME and G.GAME.round_resets.ante >= 2 then
            return true
        end
    end,
})

SMODS.Achievement({
    key = "pocket_full",
    order = 2,
    -- يفتح عند الفوز بجولة ومعك 100 دولار أو أكثر
    unlock_condition = function(self, args)
        if args.type == "round_win" and G.GAME and G.GAME.dollars >= 100 then
            return true
        end
    end,
})

SMODS.Achievement({
    key = "lucky_pull",
    order = 3,
    -- يفتح من الكود الخاص بماكينة القمار: check_for_unlock({ type = "cbuf_jackpot" })
    unlock_condition = function(self, args)
        return args.type == "cbuf_jackpot"
    end,
})

-- مثال للاستدعاء داخل كود الـ Gambling Deck عند ثلاثة تيجان:
--   check_for_unlock({ type = "cbuf_jackpot" })
