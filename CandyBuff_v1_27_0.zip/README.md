# Candy Buff

A candy-themed content mod for Balatro: new Jokers, enhancements, stickers, decks and a slot-machine Gambling Deck.

## Content
- **Jokers (22):** The Licker, Fried Eggs, Menos, Thenik, Nol Had, Roundy, Scratchy, Peven Steven, Old Couch Card, Candle, Menlod's Capsule, Unlucky Cliff, Mika 7s, Royal Balloon Crown, Pile of Rocks, Blue Glass Wave, Freespins in 20s, Halloween Night, Gym Survival, Meat Chunk with a Finger, Golden Rubble, Set of Files
- **Enhancements (3):** Orange Juice, Blue Ice, Black Plastic
- **Seals (6):** Fancy Seal, Hot Wax, and the Golden Red / Blue / Purple / Hot Wax seals
- **Consumables (4):** Tolape, Broken Sword, Rock Pile, The Keeper
- **Stickers (6):** Critical Hit, Broken Sword, Spoiled, Glass, Sealed, Rare
- **Budget (new modifier type, 2 levels):** put on Jokers by Set of Files. See both levels in Collection > Other > Budgets
- **Voucher (1):** Sweet Tooth
- **Decks (5):** Candy, Rock, Spade, Gambling, Test Your Luck (+ Candy Sleeve)
- **Booster packs (9):** Food Joker Pack, Food Consumable Pack and Joker of Luck Pack, each in Normal / Jumbo / Mega

## Compatibility
- **Steamodded** `>= 1.0.0~ALPHA-1424a` (required)
- **JokerDisplay:** shows The Licker, Fried Eggs and Menos values.
- **CardSleeves:** adds the Candy Sleeve. Without it, use the Candy Deck.
- **Cryptid:** Menos uses the Epic rarity.

## Highlights
- **Sealed sticker:** nothing is lost. When a Joker's own Chips / Mult / X Mult / X Chips / Retriggers (including s_mult and s_chips) drop (a reset or a decay), the loss goes into a counter shown in the sticker description, and the counter scores with the Joker every hand. Enhancements, Editions and Seals kept by a Sealed card keep working and stack. Blue Joker and Banner, which work their value out from the game, also keep what they lose during the round. The Keeper applies it to 1, 2 or 3 random held cards or Jokers.
- **Food packs:** pick from Food Jokers and consumables across vanilla and other mods, plus this mod's own.
- **Menos:** an Epic Joker with a floating duck.
- **Thenik:** an Epic Joker. 1 in 2 chance each hand to debuff the Joker on its right and multiply the values of the Joker on its left by that Joker's sell value, until the end of the round. It does nothing without a Joker on both sides, never stacks, and skips Sealed Jokers. X values scale only the part above X1.
- **Nol Had:** an Epic Joker. +$1 sell value for each card held in hand (retriggers count too). When sold, 1 in 2 chance it is not destroyed: you are paid, then its sell value drops to $0.
- **Roundy:** a Rare Joker. Picks a number n (2-5) each round. Chips and Mult are each rounded up to a multiple of M = scoring cards x n (retriggers count), never below n x M. Example: 5 cards, n = 5: 130 x 7 becomes 150 x 125.
- **Scratchy:** an Uncommon Joker. Starts at X1 Mult with a 1 in 1 chance. Each hand: on a hit it gains +X0.5 Mult and the chance gets one step worse (1 in 1 -> 1 in 2); on a miss it is counted. Every 3 misses in a row the chance gets one step better (never above 1 in 1) and its Mult is halved (X2.5 -> X1.25, never below X1).
- **Peven Steven:** a Common Joker. Played cards of even rank (2, 4, 6, 8, 10) give +4 Pult (purple Mult) when scored.
- **Candle:** an Uncommon Joker. A single hand whose own score is above the blind's requirement lights it; playing while it is lit snuffs it and drips Hot Wax on 2 scoring cards. While unlit, a High Card makes it absorb the Chips and Mult of the cards held in hand. Lighting costs stored Chips equal to the % the hand beat the blind by. It melts after being lit 5 times.
- **Menlod's Capsule:** an Uncommon Joker that picks a hidden random hand. Score it once per round to reveal it and either level it up or retrigger it. It hides again with a new hand when the round ends, and sleeps until a round has ended after you get it. Copies stack.
- **Unlucky Cliff:** an Uncommon Joker. Every missed probability gives it +1 point. Press USE to turn every 4 points into a guaranteed success for a later missed roll.
- **Hot Wax Seal:** only from the Candle. Gains +X0.1 Mult each time the card scores; after scoring it may fall off (1 in 6, +1/6 every time it stays).
- **Old Couch Card:** an Uncommon Joker that takes no Joker slot. At the end of the round it pays $1 for each other Joker with a sticker (max $5). When sold, it removes all stickers from your Jokers, and each sticker removed makes the next copies cost $1 more for the rest of the run.
- **Royal Balloon Crown:** every Royal Flush adds +1 retrigger to the first scored Ace (max 5, starts at 0). Defeating a Boss Blind removes 1 retrigger.
- **Orange Juice:** a card with a seal now gets the 1 in 24 upgrade too. No seal becomes a Gold Seal; Red / Blue / Purple / Hot Wax becomes its Golden copy; a seal that is already golden (or comes from another mod) retriggers the card instead.
- **Golden seals:** Golden Red, Blue, Purple and Hot Wax keep everything their normal seal does, plus a 1 in 2 chance to earn $2 each time the seal triggers (follows Oops! All 6s). Only the golden pixels shimmer.
- **Rare sticker:** Oops! All 6s now always carries Perishable and the Rare sticker. Rare Jokers appear 25% less often in shops, packs, Judgement and every other source.
- **Halloween Night:** an Uncommon Joker, an empty pumpkin. When a round starts it becomes **Trick** or **Treat** (1 in 2 for Treat; with an Egg Joker it is always Trick), changes its art and description, and is empty again when the round ends.
  - **Trick** (idea: The REAL Nightmare): every effect that happens when a card is discarded (Purple Seals, Hit the Road, Mail-In Rebate, Faceless Joker, Ramen, Yorick...) happens one more time. More Tricks = more repeats (max 3). The extra changes a repeat makes to a Joker's numbers are temporary and are taken back when the round ends.
  - **Treat** (idea: TheDragonJaymer08): Enhancement and Gold Seal effects (Chips, Mult, X Mult, X Chips, $) are 25-50% stronger this round. Cards get their own numbers back when the shop opens.
- **Gym Survival:** an Uncommon Joker. +X0.2 Mult at the end of every round in which you still have Hands and Discards left (both above 0); if either is 0 when the round ends, it goes back to X1. At the start of each round: 1 in 6 for a **Hard mission**, otherwise 1 in 3 for a normal mission (a Hard mission replaces the normal roll). The mission and its reward are shown on the card; finishing it pays the reward, failing costs $2. Normal missions: win in 2 hands or fewer, win without discarding, never play a High Card, score 150% of the blind. Hard missions: win in 1 hand, win in 2 hands with no discards, score 300% of the blind, only play Three of a Kind or better. Normal rewards: money, a Tarot card, +1 level on a random hand, a Common Joker. Hard rewards: more money, a Spectral card, an Uncommon Joker, or (1 in 8) a Rare Joker. No room for the card: you get money instead. All odds follow Oops! All 6s.
- **Meat Chunk with a Finger:** a Common Joker that only works when you play 3 or more cards (smaller hands change nothing). Starts at X1 Mult. Every hand played gives +X0.2 to +X0.9 Mult (random) before scoring, but every scored card takes -X0.12 away (never below X1). If it is back at X1 after a hand, that is a strike; the 3rd strike kills it (it cannot be Eternal).
- **Golden Rubble:** an Uncommon Joker. It starts inactive: defeat a Boss Blind while you own it to activate it (it remembers that Boss). Then sell it: you are paid, it is not destroyed, its sell value becomes $0 and it opens as **Gold** (rare, 1 in 10), **Silver** or **Nothing** (Nothing is rarer than Silver).
  - **Gold:** after every Boss Blind, 1 in 8 for a Rare Joker or 1 in 32 for a Legendary Joker (it then breaks); each miss improves the odds. A miss adds that Boss's effect to every blind while you own it (effects stack), and half of every blind reward is added to the cash out. Copied Boss effects: all "while playing" ones (debuffs, face-down cards, hand rules...) plus The Water, The Needle, The Manacle, The Wall and Violet Vessel at blind start; other start-of-blind effects are not copied.
  - **Silver:** after every blind, +X0.2 Mult for each hand you still had. With a Common Joker, held Steel cards give +X0.25 more each.
  - **Nothing:** natural Negative editions appear x1.5 as often; each round a random rank and a random suit are debuffed. If you beat a Boss Blind with it, selling it gives a random Joker Negative.
- **Set of Files:** an Uncommon Joker with four stages. **Ready:** when one of your other Jokers would be destroyed, it is saved by a **Budget** (a modifier type of its own, not a Sticker; Level 1: stays 2 more rounds, then breaks) and this Joker switches to **Late report**: if you would lose a blind with at least 80% of the requirement you are rescued ("Rescued by a late report") and it breaks. If the Budget Joker is destroyed before that, it moves to the **Second mode**: the next Joker to be destroyed gets a Budget Level 2 (1 more round) and this Joker becomes permanently **inactive**. Only the game's normal Joker destruction is caught; Jokers that remove themselves with their own animation (Gros Michel, Ramen...) are not, and selling is not destruction.
- **Rock Deck:** starts with two Rock Piles, and a random 10-30% of the deck starts as Stone cards.
- **Epic wave:** the background of every Epic Joker (Menos, Thenik, Nol Had) ripples like a wave.

## Test Your Luck Deck
Everything has a 1 in 2 chance to work, and every miss makes the numbers grow. It goes through Steamodded's probability system, so Oops! All 6s and other odds Jokers help.
- **Playing cards:** a scoring card that misses is debuffed for that hand and permanently doubles its chips and mult.
- **Jokers:** a miss cancels that trigger and doubles the Joker's numbers.
- **Consumables:** a miss uses the card up and doubles the numbers of that kind of consumable; a hit works and sends that kind back to normal.
- **Blinds:** a missed Small or Big Blind is skipped straight to the shop with no money, and the next roll gets better (2 in 3, 3 in 4...). A missed Boss Blind needs x2 score instead.
- **Resets:** every 3 hits bring a doubled Joker or playing card back to its original numbers.
- **Shop:** Jokers and Joker packs show up with only a 0.002% chance. A free Joker of Luck Pack opens at the start of the run; it offers only Jokers with a probability in their description and never appears in the shop.

## Gambling Deck
After each Boss Blind a slot machine opens before the cash-out screen. Stake Cash, the Interest cap, the deck's first-hand X Mult, or 10 / 25 / 50% of a Joker's values, then pull the lever. The reels pick a multiplier from the paytable (3 Crowns X10 down to 3 Sixes X0.25), and `new value = value - stake + stake × multiplier`. Choose "No Thanks" to skip.

**Shop Slot:** a cheaper, lower-payout slot behind the lever in the shop. $3 per pull, +$1 every 3 pulls, resets each ante. Max payout is X6 (about X0.83 average return, against about X1.03 for the Boss Blind slot).

## Config (`config.lua`)
- `slot_fast = false`: shorter spin animation
- `shop_slot_enabled = true`: show the Shop Slot
- `shop_slot_style = 'icon'`: `'icon'`, or `'column'` for a button next to Reroll
- `shop_slot_cost = 3`: starting price per pull
- `shop_slot_all_decks = false`: show the Shop Slot on every deck
- `fried_eggs_boost = 4`: extra pool copies of Fried Eggs once unlocked (0 = normal Uncommon chance)
- `menos_duck = 'big'`: `'big'` or `'small'` duck size
- `licker_start = true`: start with a Negative The Licker (Candy Sleeve)
- `licker_hunger = 3`: blinds The Licker can go hungry before it spoils a Joker
- `devour_chance = 50`: chance (%) it devours a Spoiled Joker

## Credits
Ideas: Z-Leon (Fried Eggs), Mika3.0 (Mika 7s), Alex (Royal Balloon Crown), Sun fall (Critical Hit, Broken Sword), 20 freespins na swit (Freespins in 20s), menos (Menos, Fancy Seal, Tolape), The REAL Nightmare (Halloween Night: Trick), TheDragonJaymer08 (Halloween Night: Treat).

## Changelog
### 1.27.0
- Settings page: new Discord button (join the community).

### 1.26.99
- Budget: new "Budgets" page in the Collection (Collection > Other); its tooltip text no longer uses variables (fixes the broken text); Set of Files no longer shows a Budget box beside its own description.

### 1.26.98
- Set of Files: new art for every mode (ready, inactive / waiting for the late report, second mode, permanently inactive) and for Budget Level 1 and 2.

### 1.26.97
- Budget is no longer a Sticker: it is now its own modifier type (own picture, tooltip box and countdown), and can sit on a Joker together with Stickers and an Edition.

### 1.26.96
- New Joker "Set of Files" and the new Budget (see Highlights).

### 1.26.95
- New Joker "Golden Rubble" (Uncommon) with Gold / Silver / Nothing modes (see Highlights).

### 1.26.94
- Meat Chunk with a Finger: new art.

### 1.26.93
- Meat Chunk with a Finger now only works when you play 3 or more cards.

### 1.26.92
- Meat Chunk with a Finger: the "-X0.12" loss text now appears above the scored card instead of on the Joker.

### 1.26.91
- Meat Chunk with a Finger: gain per hand is now +X0.2 to +X0.9 and the loss per scored card is -X0.12.

### 1.26.90
- New Joker "Meat Chunk with a Finger" (Common).
- Crash fix: errors inside JokerDisplay's own number calculation ("attempt to perform arithmetic on field 'chips'") are now caught, so the game keeps running; the Lovely log names the Joker and its values (search "[CandyBuff] safety").

### 1.26.89
- New Joker "Gym Survival" (Uncommon): survive rounds with Hands and Discards left to grow +X0.2 Mult, plus random normal / Hard missions with rewards (see Highlights).

### 1.26.88
- README corrected: Halloween Night added to the content list, Highlights and Credits (idea authors: The REAL Nightmare, TheDragonJaymer08); Jokers count updated to 18.

### 1.26.87
- Halloween Night (Trick): the extra changes a repeat makes to a Joker (Yorick gaining faster, Ramen losing faster, ...) are now only for the current round and are taken back when the round ends. The normal first run stays permanent.

### 1.26.86
- Halloween Night (Trick): the repeat now runs on a clean copy of the discard context and keeps its own result list, so scaling jokers such as Ramen and Yorick repeat too; if a counter joker still did not change, the step is applied by hand (logged as "[CandyBuff] pumpkin").

### 1.26.85
- Halloween Night (Treat) also boosts X Chips (including Orange Juice's).
### 1.26.84
- New Joker "Halloween Night" (Uncommon): an empty pumpkin that becomes Trick (discard effects happen once more) or Treat (+25-50% on Enhancement and Gold Seal values) each round, 1 in 2. With an Egg Joker it is always Trick. It is empty again when the round ends. Ideas by TheDragonJaymer08 and The REAL Nightmare.
### 1.26.83
- Peven Steven: original art back, with a flatter background (two lavender tones, no gradient and no drop shadows).
### 1.26.82
- Gambling Deck: clearer deck text, slot-machine texts reworded ("Cherries" instead of "Cherrys", "Worst / Best" range line, "3x / 2x" paytable columns) and the paytable row of the winning symbol now glows.
### 1.26.79
- New deck Test Your Luck: everything has a 1 in 2 chance to work, and every miss doubles the numbers.
- New Joker of Luck Pack (Normal / Jumbo / Mega): only Jokers with a probability. One opens free in the Test Your Luck deck.
- Oops! All 6s is always Perishable and carries the new Rare sticker (25% less common everywhere).
- New Golden Red / Blue / Purple / Hot Wax seals (+$2 on a 1 in 2 chance). Orange Juice upgrades seals to their Golden copy, or retriggers the card if the seal is already golden.
- Royal Balloon Crown: max 5 retriggers, and a Boss Blind removes 1 instead of 3.
- Rock Deck: two Rock Piles and 10-30% Stone cards at the start.
- Refreshed deck art.

### 1.26.61
- Unlucky Slope renamed to Unlucky Cliff.

### 1.26.60
- New Uncommon Joker Unlucky Cliff.

### 1.26.59
- New Uncommon Joker Menlod's Capsule.

### 1.26.58
- Candle description now reads "If score catches on fire, it lights".

### 1.26.57
- Candle lights when one hand's own score is above the blind's requirement (not the round total).

### 1.26.56
- Candle now lights when a hand scores over the blind. Shorter, smaller descriptions for Candle and Hot Wax.

### 1.26.55
- Candle melts in 5 stages: its art gets shorter and the wax puddle wider each time it is lit (lit and unlit versions).

### 1.26.54
- New Uncommon Joker Candle and new Hot Wax Seal.

### 1.26.53
- Fixed a crash when hovering Old Couch Card (its "Takes 0 Joker slots" box).
- Peven Steven: original jester on a new background, no outline. Scratchy: cleaner shadow.

### 1.26.52
- Scratchy: its misses must now be consecutive (a hit resets the count).
- Old Couch Card: shows a "Takes 0 Joker slots" box like Negative. Each sticker it removes makes the next copies cost $1 more for the rest of the run.
- Improved card art for Scratchy, Peven Steven and Old Couch Card.

### 1.26.51
- New Uncommon Joker Scratchy.
- New Common Joker Peven Steven.
- New Uncommon Joker Old Couch Card.

### 1.26.50
- Fixed technical bugs and added a little polish.

### 1.26.45
- Roundy is now Rare ($8). Chips and Mult round up to a multiple of M (scoring cards x n) and never end below n x M. Retriggers count.

### 1.26.44
- Roundy is now Uncommon (cost $6): its bonus is small once scores grow.

### 1.26.43
- Roundy rounds Chips and Mult up (each) to the next multiple. Cleaner animation frames: the outline never breaks. Thenik, Nol Had and Roundy now show up in JokerDisplay.

### 1.26.42
- New Rare Joker Roundy with an animated card.

### 1.26.41
- Freespins in 20s: new look based on the original drawing, with its intentional gaps kept, cleaner outlines, iron details (sheen, bolts, a little rust) and "FREE REROLL" written on the green box.

### 1.26.39
- Sealed now works on Blue Joker and Banner: chips lost as the deck or discards run down are kept.

### 1.26.38
- Sealed counter also keeps s_mult, s_chips, X Chips and retriggers.

### 1.26.37
- Sealed Jokers no longer lag: the per-frame value lock is replaced by a small counter written in the sticker description (Chips / Mult / X Mult), updated once after each Joker calculation. The Thenik's sticker is removed (the debuff is still shown by the game).

### 1.26.36
- New Epic Joker Nol Had.

### 1.26.35
- New Epic Joker Thenik and the "Thenik's" sticker; Epic Joker backgrounds now ripple like a wave. Shorter description.

### 1.26.32
- Fixed a second, static tongue on The Licker.
- Fixed the same card appearing twice in a Food pack; packs now open faster.
- Less lag with the Candy Deck and Sealed Jokers (per-frame work reduced).
- The Keeper now seals 1, 2 or 3 random cards or Jokers.
- Sealed: a kept Lucky enhancement now rolls its real 1 in 5 / 1 in 15 chances.

### 1.26.31
- The Licker has the JOKER lettering and a light three-layer animation: static background, floating chains and lock, and a tongue that swings from the keyhole.
- Fried Eggs appears more often than a Common Joker once unlocked (`fried_eggs_boost`).

### 1.26.30
New mod icon, shorter description and README.

### 1.26.1
Initial release.

## Community
Join the Discord: https://discord.gg/ush3YvnW9 (also a button on the Candy Buff settings page).
