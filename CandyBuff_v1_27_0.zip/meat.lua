-- Candy Buff — Meat Chunk with a Finger (Common Joker) (v1.26.90)
--
--   * Only works when you play 3 or more cards (a smaller hand does nothing at all).
--   * Starts at X1 Mult.
--   * Every hand you play it gains +X0.2 to +X0.9 Mult (random, in steps of 0.1) before the cards score.
--   * Every card that scores takes -X0.12 away (retriggers count). It never goes below X1.
--   * If, after a hand, it has reached X1 (it is back at the floor), that is a STRIKE. One strike per hand at most.
--     On the 3rd strike the meat dies (it is destroyed; it cannot be Eternal).
--   * Then it scores its current X Mult.
--
-- Written from reading Steamodded; it could NOT be run inside the game. Failures go to the Lovely log
-- (search "[CandyBuff] meat").

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] meat: ' .. msg, 'CandyBuff') end
end

local jd = _G.CBUF_API and _G.CBUF_API.jd

local CFG = {
    gain_min = 2, gain_max = 9,   -- tenths: +X0.2 .. +X0.9 per hand played
    loss = 0.12,                  -- per scored card
    strikes_to_die = 3,
    min_cards = 3,                -- it only works when you play at least this many cards
}

-- hands with fewer cards are ignored completely (no gain, no loss, no score)
local function enough(context)
    local n = 0
    if type(context.full_hand) == 'table' then n = #context.full_hand
    elseif G and G.play and G.play.cards then n = #G.play.cards end
    return n >= CFG.min_cards
end

SMODS.Atlas { key = 'cbuf_meat', path = 'cbuf_meat.png', px = 71, py = 95, disable_mipmap = true }

local function round2(x) return math.floor(x * 100 + 0.5) / 100 end
local function fmt(x)
    local s = string.format('%.2f', x)
    s = s:gsub('0+$', ''):gsub('%.$', '')
    return s
end

local function show(card, text, colour)
    if card_eval_status_text and G and G.C then
        pcall(card_eval_status_text, card, 'extra', nil, nil, nil, { message = text, colour = colour or G.C.ATTENTION })
    end
end

local function die(card)
    show(card, 'Rotten!', G.C.RED)
    local ok = false
    if SMODS and type(SMODS.destroy_cards) == 'function' then
        ok = pcall(SMODS.destroy_cards, card, true)
    end
    if not ok then pcall(function() card:start_dissolve({ G.C.RED }, nil, 1.6) end) end
    log('info', 'the meat died')
end

SMODS.Joker {
    key = 'meat',
    atlas = 'cbuf_meat',
    pos = { x = 0, y = 0 },
    rarity = 1,
    cost = 5,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = true,
    config = { extra = { xmult = 1, strikes = 0, floor_hit = false } },
    joker_display_def = jd and jd('j_cbuf_meat', function(JokerDisplay)
        return {
            text = {
                { text = 'X' },
                { ref_table = 'card.joker_display_values', ref_value = 'xmult' },
            },
            text_config = { colour = G.C.MULT },
            reminder_text = { { ref_table = 'card.joker_display_values', ref_value = 'strikes' } },
            calc_function = function(card)
                local ex = card.ability and card.ability.extra or {}
                card.joker_display_values.xmult = fmt(ex.xmult or 1)
                card.joker_display_values.strikes = '(' .. (ex.strikes or 0) .. '/' .. CFG.strikes_to_die .. ')'
            end,
        }
    end) or nil,
    loc_txt = {
        name = 'Meat Chunk with a Finger',
        text = {
            '{s:0.85}Only when you play {s:0.85,C:attention}3+{s:0.85} cards:',
            '{s:0.85}Each hand played:',
            '{s:0.85,X:mult,C:white}+X' .. fmt(CFG.gain_min / 10) .. '-' .. fmt(CFG.gain_max / 10) .. '{s:0.85} Mult',
            '{s:0.85}Each card scored: {s:0.85,X:mult,C:white}-X' .. fmt(CFG.loss),
            '{s:0.85}Back at {s:0.85,X:mult,C:white}X1{s:0.85} after a hand = {s:0.85,C:attention}strike',
            '{s:0.85,C:red}Dies{s:0.85} on strike {s:0.85,C:attention}' .. CFG.strikes_to_die,
            '{s:0.85,C:inactive}(Currently {s:0.85,X:mult,C:white}X#1#{s:0.85,C:inactive}, strikes #2#/' .. CFG.strikes_to_die .. ')',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = card and card.ability and card.ability.extra or {}
        return { vars = { fmt(ex.xmult or 1), ex.strikes or 0 } }
    end,
    calculate = function(self, card, context)
        local ex = card.ability and card.ability.extra
        if not ex then return end

        -- a hand is played: the meat grows
        if context.before and not context.blueprint then
            if not enough(context) then return end
            local g = pseudorandom('cbuf_meat', CFG.gain_min, CFG.gain_max) / 10
            ex.xmult = round2((ex.xmult or 1) + g)
            ex.floor_hit = false
            show(card, '+X' .. fmt(g), G.C.MULT)
            return
        end

        -- every scored card eats some of it
        if context.individual and context.cardarea == G.play and not context.blueprint and context.other_card then
            if not enough(context) then return end
            local new = round2((ex.xmult or 1) - CFG.loss)
            if new <= 1 then
                new = 1
                ex.floor_hit = true
            end
            ex.xmult = new
            return { message = '-X' .. fmt(CFG.loss), colour = G.C.RED, message_card = context.other_card }   -- shown above the scored card
        end

        if context.joker_main then
            if not enough(context) then return end
            local x = ex.xmult or 1
            if x > 1 then return { xmult = x } end
            return
        end

        -- after the hand: a strike if it is back at the floor
        if context.after and not context.blueprint then
            if ex.floor_hit and enough(context) then
                ex.floor_hit = false
                ex.strikes = (ex.strikes or 0) + 1
                show(card, 'Strike ' .. ex.strikes .. '/' .. CFG.strikes_to_die, G.C.RED)
                if ex.strikes >= CFG.strikes_to_die then
                    local ok, err = pcall(die, card)
                    if not ok then log('error', 'die failed: ' .. tostring(err)) end
                end
            end
        end
    end,
}

log('info', 'loaded')
