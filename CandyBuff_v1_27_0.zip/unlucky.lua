-- Candy Buff — Unlucky Cliff (Uncommon Joker) (v1.26.63)
--
--   * Every probability roll that MISSES (any card or Joker, "1 in 4" and so on) gives this Joker +1 point.
--   * Press USE (the button under the Joker when you select it) to turn points into guaranteed
--     successes: every 4 points become 1 Ready charge.
--   * A Ready charge turns the next MISSED roll into a success (a roll that already hit does not use one).
--   * Every copy keeps its own points; Ready charges are spent one at a time, copy by copy.
--
-- How it works: SMODS.pseudorandom_probability (the function every probability goes through in
-- current Steamodded) is wrapped once. If a roll fails it either spends a charge (and returns true)
-- or adds the points.
--
-- Everything you may want to tweak is in CFG below.
-- Safety: all hooks are inside pcall; failures go to the Lovely log (search "CandyBuff unlucky").

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] unlucky: ' .. msg, 'CandyBuff') end
end

local jd = _G.CBUF_API and _G.CBUF_API.jd   -- JokerDisplay helper from candy_core.lua

local CFG = {
    points_per_miss = 1,   -- points gained for every missed probability
    points_per_charge = 4, -- points needed for one guaranteed success
}

local KEY = 'j_cbuf_unlucky'
local GREEN = HEX and HEX('7CB342') or (G and G.C and G.C.GREEN)

local function is_unlucky(c)
    return c and c.config and c.config.center and c.config.center.key == KEY
        and c.ability and type(c.ability.extra) == 'table' and not c.debuff
end

local function say(card, text, colour)
    pcall(function()
        card_eval_status_text(card, 'extra', nil, nil, nil, { message = text, colour = colour })
    end)
end

-- Called when a probability roll failed. Returns true if a charge turned it into a success.
local function on_miss()
    local owned = G and G.jokers and G.jokers.cards
    if not owned then return false end
    for _, c in ipairs(owned) do
        if is_unlucky(c) and (c.ability.extra.charges or 0) > 0 then
            c.ability.extra.charges = c.ability.extra.charges - 1
            c:juice_up(0.4, 0.4)
            say(c, 'Lucky!', GREEN)
            return true
        end
    end
    for _, c in ipairs(owned) do
        if is_unlucky(c) then
            c.ability.extra.points = (c.ability.extra.points or 0) + CFG.points_per_miss
            c:juice_up(0.2, 0.2)
            say(c, '+' .. CFG.points_per_miss, G.C.RED)
        end
    end
    return false
end

-- Wrap the probability function once.
if SMODS and type(SMODS.pseudorandom_probability) == 'function' and not SMODS._cbuf_unlucky_hooked then
    SMODS._cbuf_unlucky_hooked = true
    local orig = SMODS.pseudorandom_probability
    SMODS.pseudorandom_probability = function(...)
        local result = orig(...)
        if result then return result end
        local ok, saved = pcall(on_miss)
        if ok and saved then return true end
        return result
    end
else
    log('warn', 'SMODS.pseudorandom_probability not found: Unlucky Cliff cannot see missed rolls (Steamodded too old?)')
end

-- USE button ------------------------------------------------------------------
G.FUNCS.cbuf_unlucky_can_use = function(e)
    local card = e.config.ref_table
    local ex = card and card.ability and card.ability.extra
    if ex and (ex.points or 0) >= CFG.points_per_charge then
        e.config.colour = G.C.GREEN
        e.config.button = 'cbuf_unlucky_use'
    else
        e.config.colour = G.C.UI.BACKGROUND_INACTIVE
        e.config.button = nil
    end
end

G.FUNCS.cbuf_unlucky_use = function(e)
    local card = e.config.ref_table
    local ex = card and card.ability and card.ability.extra
    if not ex then return end
    local gained = math.floor((ex.points or 0) / CFG.points_per_charge)
    if gained < 1 then return end
    ex.points = ex.points - gained * CFG.points_per_charge
    ex.charges = (ex.charges or 0) + gained
    pcall(function() card.area:remove_from_highlighted(card) end)
    card:juice_up(0.6, 0.6)
    pcall(play_sound, 'generic1')
    say(card, 'Ready x' .. ex.charges, GREEN)
end

local function make_button(card)
    return { n = G.UIT.R, config = { align = 'cl', padding = 0.05 }, nodes = {
        { n = G.UIT.C, config = {
            ref_table = card, align = 'cr', padding = 0.1, r = 0.08, minw = 1.25, hover = true, shadow = true,
            colour = G.C.UI.BACKGROUND_INACTIVE, one_press = true,
            button = 'cbuf_unlucky_use', func = 'cbuf_unlucky_can_use',
        }, nodes = {
            { n = G.UIT.B, config = { w = 0.1, h = 0.6 } },
            { n = G.UIT.C, config = { align = 'tm' }, nodes = {
                { n = G.UIT.R, config = { align = 'cm', maxw = 1.25 }, nodes = {
                    { n = G.UIT.T, config = { text = localize('b_use'), colour = G.C.UI.TEXT_LIGHT, scale = 0.4, shadow = true } },
                } },
            } },
        } },
    } }
end

-- First column of the returned UI that holds the buttons (the one with "cl" alignment).
local function find_column(node)
    if type(node) ~= 'table' then return nil end
    if node.nodes and node.config and node.config.align == 'cl' and node.n == G.UIT.C then return node end
    for _, child in ipairs(node.nodes or {}) do
        local f = find_column(child)
        if f then return f end
    end
    return nil
end

if G and G.UIDEF and type(G.UIDEF.use_and_sell_buttons) == 'function' and not _G._cbuf_unlucky_ui_hooked then
    _G._cbuf_unlucky_ui_hooked = true
    local ref = G.UIDEF.use_and_sell_buttons
    function G.UIDEF.use_and_sell_buttons(card, ...)
        local ui = ref(card, ...)
        pcall(function()
            if card and card.area == G.jokers and card.config and card.config.center
                and card.config.center.key == KEY then
                local col = find_column(ui)
                if col then
                    col.nodes[#col.nodes + 1] = make_button(card)
                elseif ui and ui.nodes then
                    ui.nodes[#ui.nodes + 1] = make_button(card)
                end
            end
        end)
        return ui
    end
end

-- Joker --------------------------------------------------------------------------
SMODS.Atlas { key = 'cbuf_unlucky', path = 'cbuf_unlucky.png', px = 71, py = 95, disable_mipmap = true }

SMODS.Joker {
    key = 'unlucky',
    atlas = 'cbuf_unlucky',
    pos = { x = 0, y = 0 },
    rarity = 2,
    cost = 6,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = { points = 0, charges = 0 } },
    joker_display_def = jd and jd('j_cbuf_unlucky', function(JokerDisplay)
        return {
            text = {
                { ref_table = 'card.ability.extra', ref_value = 'points' },
                { text = '/' },
                { ref_table = 'card.ability.extra', ref_value = 'charges' },
            },
        }
    end) or nil,
    loc_txt = {
        name = 'Unlucky Cliff',
        text = {
            '{s:0.85}Every missed probability',
            '{s:0.85}gives {s:0.85,C:attention}+1{s:0.85} point',
            '{s:0.85,C:attention}USE{s:0.85}: every {s:0.85,C:attention}#3#{s:0.85} points become',
            '{s:0.85}a guaranteed success',
            '{s:0.85}Points {s:0.85,C:attention}#1#{s:0.85}  Ready {s:0.85,C:green}#2#{s:0.85}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = card and card.ability and card.ability.extra or {}
        return { vars = { ex.points or 0, ex.charges or 0, CFG.points_per_charge } }
    end,
}

log('info', 'loaded')
