-- Candy Buff — Gym Survival (Uncommon Joker) (v1.26.89)
--
--   CORE: at the end of every round, if you still have Hands AND Discards left (both above 0), it gains +X0.2 Mult.
--         If either one is 0 when the round ends, it goes back to X1.
--   MISSIONS (decided when a round starts; the Hard roll always comes first):
--     1 in 6 -> a HARD mission. Otherwise 1 in 3 -> a normal mission. Otherwise nothing (and if a Hard mission
--     is rolled, there is no normal one).
--     Finishing the round with the mission done pays its reward (shown on the card). Failing costs $2.
--     Normal rewards: money / Tarot / +1 level on a random hand / Common Joker.
--     Hard rewards: more money / Spectral / Uncommon Joker, and 1 in 8 a Rare Joker instead.
--     (No room for the card? you get money instead.)
--   All odds follow probability Jokers (Oops! All 6s).
--
-- Written from reading Steamodded; it could NOT be run inside the game. Failures go to the Lovely log
-- (search "[CandyBuff] gym").

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] gym: ' .. msg, 'CandyBuff') end
end

local jd = _G.CBUF_API and _G.CBUF_API.jd

local CFG = {
    gain = 0.2,                 -- X Mult per round survived
    hard_odds = 6,              -- "1 in 6": Hard mission
    normal_odds = 3,            -- "1 in 3": normal mission
    rare_odds = 8,              -- "1 in 8": a Hard reward is a Rare Joker
    penalty = 2,                -- $ lost for a failed mission
    money_normal = { 3, 6 },    -- random $ range, normal mission
    money_hard = { 8, 12 },     -- random $ range, Hard mission
}

SMODS.Atlas { key = 'cbuf_gym', path = 'cbuf_gym.png', px = 71, py = 95, disable_mipmap = true }

local function fmt(x)
    local s = string.format('%.2f', x)
    s = s:gsub('0+$', ''):gsub('%.$', '')
    return s
end
local function round2(x) return math.floor(x * 100 + 0.5) / 100 end

local function show(card, text, colour)
    if card_eval_status_text and G and G.C then
        pcall(card_eval_status_text, card, 'extra', nil, nil, nil, { message = text, colour = colour or G.C.ATTENTION })
    end
end

local function roll(card, seed, den)
    if SMODS and type(SMODS.pseudorandom_probability) == 'function' then
        local ok, r = pcall(SMODS.pseudorandom_probability, card, seed, 1, den, seed)
        if ok then return r and true or false end
    end
    local normal = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return pseudorandom(seed) < math.min(1, normal / den)
end

local function odds_vars(card, seed, den)
    if SMODS and type(SMODS.get_probability_vars) == 'function' then
        local ok, n, d = pcall(SMODS.get_probability_vars, card, 1, den, seed)
        if ok and n and d then return n, d end
    end
    return (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1, den
end

-- missions ---------------------------------------------------------------------------------------
-- check(ex) runs when the round ends. ex.m_bad is set during play by the "before" hook below.
local function cur() return (G and G.GAME and G.GAME.current_round) or {} end

local function ratio(ex)
    local ok, r = pcall(function()
        local need, got = ex.m_need, G.GAME.chips
        if need and got and need > 0 then return got / need end
        return nil
    end)
    if ok then return r end
    return nil
end

local WEAK = { ['High Card'] = true, ['Pair'] = true, ['Two Pair'] = true }

local NORMAL = {
    { id = 'fast',   text = 'Win in 2 hands or fewer',   check = function(ex) return (cur().hands_played or 0) <= 2 end },
    { id = 'nodisc', text = 'Win without discarding',    check = function(ex) return (cur().discards_used or 0) == 0 end },
    { id = 'nohigh', text = 'Never play a High Card',    check = function(ex) return not ex.m_bad end },
    { id = 'over',   text = 'Score 150% of the blind',   check = function(ex) local r = ratio(ex); return r == nil or r >= 1.5 end },
}
local HARD = {
    { id = 'one',   text = 'Win in 1 hand',                          check = function(ex) return (cur().hands_played or 0) <= 1 end },
    { id = 'lean',  text = 'Win in 2 hands, no discards',            check = function(ex) return (cur().hands_played or 0) <= 2 and (cur().discards_used or 0) == 0 end },
    { id = 'big',   text = 'Score 300% of the blind',                check = function(ex) local r = ratio(ex); return r == nil or r >= 3 end },
    { id = 'combo', text = 'Only play Three of a Kind or better',    check = function(ex) return not ex.m_bad end },
}

local function find(list, id)
    for _, m in ipairs(list) do if m.id == id then return m end end
end
local function mission_of(ex)
    if not ex.m_id then return nil end
    return find(ex.m_tier == 'hard' and HARD or NORMAL, ex.m_id)
end

-- which hands count as "bad" for the two tracking missions
local function track_hand(ex, name)
    if ex.m_id == 'nohigh' and name == 'High Card' then ex.m_bad = true end
    if ex.m_id == 'combo' and WEAK[name] then ex.m_bad = true end
end

local REWARD_TEXT = {
    tarot = 'a Tarot card', spectral = 'a Spectral card', level = '+1 level, random hand',
    joker_common = 'a Common Joker', joker_uncommon = 'an Uncommon Joker', joker_rare = 'a Rare Joker',
}
local function reward_text(ex)
    if ex.m_reward == 'money' then return '$' .. tostring(ex.m_amount or 0) end
    return REWARD_TEXT[ex.m_reward] or '?'
end

-- rewards ---------------------------------------------------------------------------------------
local function money(card, n)
    n = math.floor(tonumber(n) or 0)
    if n == 0 then return end
    ease_dollars(n)
    show(card, (n > 0 and '+$' or '-$') .. math.abs(n), n > 0 and G.C.MONEY or G.C.RED)
end

local function room(area, buffer, extra_buf)
    return area and area.cards and area.config
        and (#area.cards + (G.GAME[buffer] or 0)) < area.config.card_limit
end

local function give_card(card, ex, set, rarity)
    local is_joker = (set == 'Joker')
    local area = is_joker and G.jokers or G.consumeables
    local buf = is_joker and 'joker_buffer' or 'consumeable_buffer'
    if not room(area, buf) then
        money(card, ex.m_amount or 4)             -- no room: money instead
        return
    end
    G.GAME[buf] = (G.GAME[buf] or 0) + 1
    G.E_MANAGER:add_event(Event({
        trigger = 'before', delay = 0.0,
        func = function()
            local ok, err = pcall(function()
                local t = { set = set, key_append = 'cbuf_gym' }
                if rarity then t.rarity = rarity end
                SMODS.add_card(t)
            end)
            if not ok then log('warn', 'could not create reward: ' .. tostring(err)) end
            G.GAME[buf] = math.max(0, (G.GAME[buf] or 1) - 1)
            return true
        end,
    }))
    show(card, 'Reward!', G.C.GREEN)
end

local function level_up(card)
    local list = {}
    for k, v in pairs(G.GAME.hands or {}) do
        if v.visible then list[#list + 1] = k end
    end
    table.sort(list)
    if #list == 0 then return money(card, 4) end
    local h = pseudorandom_element(list, pseudoseed('cbuf_gym_level'))
    level_up_hand(card, h, true, 1)
    show(card, 'Level up! ' .. tostring(localize(h, 'poker_hands')), G.C.CHIPS)
end

local function give(card, ex)
    local k = ex.m_reward
    if k == 'money' then money(card, ex.m_amount)
    elseif k == 'tarot' then give_card(card, ex, 'Tarot')
    elseif k == 'spectral' then give_card(card, ex, 'Spectral')
    elseif k == 'level' then level_up(card)
    elseif k == 'joker_common' then give_card(card, ex, 'Joker', 'Common')
    elseif k == 'joker_uncommon' then give_card(card, ex, 'Joker', 'Uncommon')
    elseif k == 'joker_rare' then give_card(card, ex, 'Joker', 'Rare')
    end
end

-- round start: Hard roll first, then the normal roll ----------------------------------------------
local function clear_mission(ex)
    ex.m_id, ex.m_tier, ex.m_reward, ex.m_amount, ex.m_bad, ex.m_need = nil, nil, nil, nil, nil, nil
end

local function start_round(card)
    local ex = card.ability.extra
    clear_mission(ex)
    local tier
    if roll(card, 'cbuf_gym_hard', CFG.hard_odds) then tier = 'hard'
    elseif roll(card, 'cbuf_gym_normal', CFG.normal_odds) then tier = 'normal' end
    if not tier then return end
    local list = (tier == 'hard') and HARD or NORMAL
    local m = pseudorandom_element(list, pseudoseed('cbuf_gym_pick'))
    ex.m_tier, ex.m_id, ex.m_bad = tier, m.id, false
    ex.m_need = G.GAME and G.GAME.blind and G.GAME.blind.chips or nil
    if tier == 'hard' then
        if roll(card, 'cbuf_gym_rare', CFG.rare_odds) then
            ex.m_reward = 'joker_rare'
        else
            ex.m_reward = pseudorandom_element({ 'money', 'spectral', 'joker_uncommon' }, pseudoseed('cbuf_gym_hr'))
        end
        ex.m_amount = pseudorandom('cbuf_gym_hm', CFG.money_hard[1], CFG.money_hard[2])
    else
        ex.m_reward = pseudorandom_element({ 'money', 'tarot', 'level', 'joker_common' }, pseudoseed('cbuf_gym_nr'))
        ex.m_amount = pseudorandom('cbuf_gym_nm', CFG.money_normal[1], CFG.money_normal[2])
    end
    pcall(play_sound, tier == 'hard' and 'timpani' or 'generic1', 1, 0.6)
    show(card, tier == 'hard' and 'Hard mission!' or 'Mission!', tier == 'hard' and G.C.RED or G.C.ATTENTION)
    card:juice_up(0.5, 0.5)
end

-- round end ----------------------------------------------------------------------------------------
local function end_round(card)
    local ex = card.ability.extra
    -- 1) the mission
    local m = mission_of(ex)
    if m then
        local ok, passed = pcall(m.check, ex)
        if not ok then log('warn', 'mission check failed: ' .. tostring(passed)); passed = true end
        if passed then
            show(card, 'Mission done!', G.C.GREEN)
            give(card, ex)
        else
            show(card, 'Mission failed', G.C.RED)
            money(card, -CFG.penalty)
        end
    end
    clear_mission(ex)
    -- 2) the survival bonus
    local r = cur()
    local hands, discards = r.hands_left or 0, r.discards_left or 0
    if hands > 0 and discards > 0 then
        ex.xmult = round2((ex.xmult or 1) + CFG.gain)
        show(card, '+X' .. fmt(CFG.gain), G.C.MULT)
        card:juice_up(0.6, 0.6)
    else
        if (ex.xmult or 1) > 1 then show(card, 'Reset to X1', G.C.RED) end
        ex.xmult = 1
    end
end

SMODS.Joker {
    key = 'gym',
    atlas = 'cbuf_gym',
    pos = { x = 0, y = 0 },
    rarity = 2,
    cost = 6,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = { xmult = 1 } },
    joker_display_def = jd and jd('j_cbuf_gym', function(JokerDisplay)
        return {
            text = {
                { text = 'X' },
                { ref_table = 'card.joker_display_values', ref_value = 'xmult' },
            },
            text_config = { colour = G.C.MULT },
            reminder_text = { { ref_table = 'card.joker_display_values', ref_value = 'mission' } },
            calc_function = function(card)
                local ex = card.ability and card.ability.extra or {}
                card.joker_display_values.xmult = fmt(ex.xmult or 1)
                local m = mission_of(ex)
                card.joker_display_values.mission = m and ('(' .. (ex.m_tier == 'hard' and 'Hard: ' or '') .. m.text .. ')') or ''
            end,
        }
    end) or nil,
    loc_txt = {
        name = 'Gym Survival',
        text = {
            '{s:0.85,X:mult,C:white}+X' .. fmt(CFG.gain) .. '{s:0.85} Mult each round you end with',
            '{s:0.85,C:attention}Hands{s:0.85} and {s:0.85,C:attention}Discards{s:0.85} above 0',
            '{s:0.85}If either is 0: back to {s:0.85,X:mult,C:white}X1',
            '{s:0.85}Round start: {s:0.85,C:green}#1# in #2#{s:0.85} {s:0.85,C:attention}Hard{s:0.85} mission,',
            '{s:0.85}else {s:0.85,C:green}#3# in #4#{s:0.85} mission',
            '{s:0.85}Failed mission: {s:0.85,C:red}-$' .. CFG.penalty,
            '{s:0.85,C:inactive}(Currently {s:0.85,X:mult,C:white}X#5#{s:0.85,C:inactive})',
            '{s:0.85,C:attention}#6#',
            '{s:0.8,C:inactive}#7#',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = card and card.ability and card.ability.extra or {}
        local hn, hd = odds_vars(card, 'cbuf_gym_hard', CFG.hard_odds)
        local nn, nd = odds_vars(card, 'cbuf_gym_normal', CFG.normal_odds)
        local m = mission_of(ex)
        local l1, l2 = 'No mission this round', ' '
        if m then
            l1 = (ex.m_tier == 'hard' and 'Hard: ' or 'Mission: ') .. m.text
            l2 = 'Reward: ' .. reward_text(ex)
        end
        return { vars = { hn, hd, nn, nd, fmt(ex.xmult or 1), l1, l2 } }
    end,
    calculate = function(self, card, context)
        local ex = card.ability and card.ability.extra
        if not ex then return end
        -- a new round: roll the mission
        if context.setting_blind and not context.blueprint and not context.repetition then
            local ok, err = pcall(start_round, card)
            if not ok then log('error', 'start_round failed: ' .. tostring(err)) end
            return
        end
        -- track the hands played (for "never High Card" / "Three of a Kind or better")
        if context.before and not context.blueprint and ex.m_id then
            pcall(track_hand, ex, context.scoring_name)
            return
        end
        -- round over: mission result, then Hands/Discards check
        if context.end_of_round and not context.individual and not context.repetition
            and not context.game_over and not context.blueprint then
            local ok, err = pcall(end_round, card)
            if not ok then log('error', 'end_round failed: ' .. tostring(err)) end
            return
        end
        if context.joker_main then
            local x = ex.xmult or 1
            if x > 1 then return { xmult = x } end
        end
    end,
}

log('info', 'loaded')
