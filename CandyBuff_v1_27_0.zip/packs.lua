-- Candy Buff — booster packs (v1.26.29)
--
-- Two kinds of pack, each in Normal / Jumbo / Mega size:
--   Food Joker Pack       -> Food jokers: this mod's, vanilla (Gros Michel, Egg, Cavendish, Popcorn...) and
--                            any other mod's (Food pool, Cryptid food list, food-looking names)
--   Food Consumable Pack  -> this mod's consumables, food consumables (food names, eat/drink in the text or
--                            code, losing value, counting rounds/uses left) and the consumables of
--                            custom consumable types that other mods add
-- Contents are computed when a pack opens, so mod load order does not matter and a missing mod is harmless.
-- Packs show up in the shop like any other booster (their weights are low so they stay special).
-- Menos and the Pile of Rocks Joker are never offered.
--
-- Everything here is isolated (see main.lua): if it fails the Lovely log says "CandyBuff packs"
-- and the rest of the mod still loads.

local MOD = SMODS.current_mod

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] packs: ' .. msg, 'CandyBuff') end
end

SMODS.Atlas { key = 'cbuf_boosters', path = 'cbuf_boosters.png', px = 71, py = 95, disable_mipmap = true }

-- What a pack may contain is worked out when the pack is opened, so it also picks up other mods
-- (Cryptid, Bakery, Hot Potato, Food-pool mods...) no matter in which order the mods loaded.
--   Joker pack      : Food jokers (vanilla + any mod) and every Joker of this mod
--   Consumable pack : consumables of this mod, food-themed consumables from anywhere, and
--                     consumables of custom consumable types added by other mods
local OWN_JOKERS = {
    'j_cbuf_licker', 'j_cbuf_fried_eggs', 'j_cbuf_mika_7s',
    'j_cbuf_royal_balloon_crown', 'j_cbuf_blue_glass_wave', 'j_cbuf_freespins20',
    'j_cbuf_breadcrumbs', 'j_cbuf_gingerbread_house',   -- only exist when Sagatro is installed (see sagatro.lua)
}
local OWN_CONSUMABLES = { 'c_cbuf_tolape', 'c_cbuf_blade', 'c_cbuf_rock_pile', 'c_cbuf_keeper' }
local NEVER = { j_cbuf_menos = true, j_cbuf_pile_of_rocks = true }       -- never offered by packs
local VANILLA_FOOD = {
    j_gros_michel = true, j_egg = true, j_ice_cream = true, j_cavendish = true, j_turtle_bean = true,
    j_diet_cola = true, j_popcorn = true, j_ramen = true, j_selzer = true,
}
local VANILLA_SETS = { Joker = true, Tarot = true, Planet = true, Spectral = true, Default = true, Enhanced = true,
    Edition = true, Voucher = true, Booster = true, Back = true, Seal = true, Stake = true, Tag = true, Blind = true, Sticker = true }
-- words that mark something as food when they appear in its key or name (checked on whole tokens / prefixes)
local FOOD_WORDS = {
    'food', 'candy', 'sweet', 'sugar', 'choco', 'cocoa', 'cookie', 'biscuit', 'cake', 'cupcake', 'pie', 'pizza', 'burger',
    'fries', 'taco', 'sandwich', 'bread', 'toast', 'bagel', 'donut', 'doughnut', 'muffin', 'pancake', 'waffle', 'pastry',
    'bakery', 'baguette', 'croissant', 'cheese', 'butter', 'milk', 'cream', 'yogurt', 'egg', 'bacon', 'sausage', 'meat',
    'steak', 'chicken', 'fish', 'sushi', 'noodle', 'ramen', 'pasta', 'spaghetti', 'rice', 'soup', 'salad', 'bean',
    'banana', 'apple', 'orange', 'lemon', 'lime', 'cherry', 'grape', 'berry', 'melon', 'peach', 'mango', 'pear',
    'pickle', 'pepper', 'chili', 'tomato', 'potato', 'carrot', 'corn', 'popcorn', 'nut', 'peanut', 'honey', 'jam',
    'jelly', 'syrup', 'lolli', 'licker', 'gum', 'mint', 'toffee', 'caramel', 'marshmallow', 'icecream', 'cone',
    'soda', 'cola', 'seltzer', 'juice', 'tea', 'coffee', 'beer', 'wine', 'drink', 'snack', 'meal', 'lunch', 'dinner',
    'breakfast', 'cereal', 'oat', 'fruit', 'veg', 'mushroom', 'garlic', 'onion', 'curry', 'kebab', 'hotdog', 'nugget',
}

local function words_of(str)
    local t = {}
    for w in tostring(str or ''):lower():gmatch('%a+') do t[#t + 1] = w end
    return t
end

-- words in a description that mean "this thing is eaten or drunk"
local EAT_WORDS = {}
for w in ([[eat eats eaten eating ate drink drinks drinking drank sip sips devour devours devoured consume consumes
    consumed chew chews bite bites swallow swallows lick licks snack snacks feast hungry delicious tasty taste tastes
    flavor flavour]]):gmatch('%a+') do EAT_WORDS[w] = true end

local function description_words(center)
    local words = {}
    local loc = G and G.localization and G.localization.descriptions
    local entry = loc and center.set and loc[center.set] and loc[center.set][center.key]
    local lines = (entry and entry.text) or (center.loc_txt and center.loc_txt.text) or {}
    for _, line in ipairs(lines) do
        for _, w in ipairs(words_of((tostring(line):gsub('{[^}]*}', '')))) do words[#words + 1] = w end
    end
    return words
end

-- Food detection, part 2: things that lose value by themselves, and anything that eats / drinks in its code.
local VANILLA_DECAY = { j_ice_cream = true, j_popcorn = true, j_ramen = true, j_selzer = true }
local DECAY_NAME_PARTS = { 'decay', 'decreas', 'reduc', 'degrad', 'deprec', 'shrink', 'stale', 'spoil', 'wither', 'melt',
    'expire', 'loss', 'lose' }
local DECAY_VERBS = { lose = true, loses = true, losing = true, decrease = true, decreases = true, reduce = true, reduces = true,
    decay = true, decays = true, degrade = true, degrades = true, shrink = true, shrinks = true, spoil = true, spoils = true,
    melt = true, melts = true, depreciate = true, depreciates = true, wither = true, withers = true }
local VALUE_WORDS_TXT = { chip = true, chips = true, mult = true, value = true, money = true, dollar = true, dollars = true,
    gold = true, x = true, bonus = true }

local function name_has(name, parts)
    name = tostring(name):lower()
    for _, p in ipairs(parts) do if name:find(p, 1, true) then return true end end
    return false
end

local function config_decays(tbl, depth)
    if type(tbl) ~= 'table' or depth > 2 then return false end
    for k, v in pairs(tbl) do
        if type(k) == 'string' then
            if name_has(k, DECAY_NAME_PARTS) then return true end
            if type(v) == 'number' and v < 0 and k:lower():find('mod', 1, true) then return true end
            if type(v) == 'table' and config_decays(v, depth + 1) then return true end
        end
    end
    return false
end

local function description_decays(center)
    local text = table.concat(description_words(center), ' ')
    -- split into rough sentences on the original lines instead: a verb and a value word must be close together
    local words = description_words(center)
    for i, w in ipairs(words) do
        if DECAY_VERBS[w] then
            for j = i + 1, math.min(i + 6, #words) do
                if VALUE_WORDS_TXT[words[j]] then return true end
            end
        end
    end
    return false
end

local function decays_by_itself(center)
    if VANILLA_DECAY[center.key] then return true end
    if config_decays(center.config, 0) then return true end
    return description_decays(center)
end

-- eat / drink in the Lua source of the Joker (calculate, add_to_deck, ... as written in its mod's files)
local EAT_SRC = { eat = true, eats = true, eaten = true, eating = true, ate = true, drink = true, drinks = true,
    drinking = true, drank = true, drunk = true, devour = true, devours = true, devoured = true }
local file_cache, code_cache = {}, {}

local function read_lines(path)
    if file_cache[path] ~= nil then return file_cache[path] or nil end
    local text
    local nfs = (SMODS and SMODS.NFS) or NFS
    if nfs and nfs.read then local ok, r = pcall(nfs.read, path); if ok and type(r) == 'string' then text = r end end
    if not text and io and io.open then
        local f = io.open(path, 'rb'); if f then text = f:read('*a'); f:close() end
    end
    if not text then file_cache[path] = false; return nil end
    local lines = {}
    for line in (text .. '\n'):gmatch('(.-)\r?\n') do lines[#lines + 1] = line end
    file_cache[path] = lines
    return lines
end

local function source_path(src)
    if type(src) ~= 'string' then return nil end
    if src:sub(1, 1) == '@' then return src:sub(2) end
    local modid, rel = src:match('^=%[SMODS (%S+) "(.-)"%]')
    if modid then
        local base = (modid == '_' and SMODS.path) or (SMODS.Mods and SMODS.Mods[modid] and SMODS.Mods[modid].path)
        if base then return base .. rel end
    end
    return nil
end

local function code_mentions_food(center)
    local key = center.key
    if code_cache[key] ~= nil then return code_cache[key] end
    local found = false
    local ok = pcall(function()
        for _, fname in ipairs({ 'calculate', 'add_to_deck', 'remove_from_deck', 'set_ability', 'update', 'loc_vars', 'use', 'in_pool' }) do
            local fn = center[fname]
            if type(fn) == 'function' and debug and debug.getinfo then
                local info = debug.getinfo(fn, 'S')
                local path = info and source_path(info.source)
                local lines = path and read_lines(path)
                if lines and info.linedefined and info.lastlinedefined and info.lastlinedefined >= info.linedefined then
                    for i = info.linedefined, math.min(info.lastlinedefined, info.linedefined + 300) do
                        local line = lines[i]
                        if line then
                            for w in line:lower():gmatch('%a+') do
                                if EAT_SRC[w] then found = true; return end
                            end
                        end
                    end
                end
            end
        end
    end)
    code_cache[key] = found
    return found
end

-- Consumables that count rounds / uses / time left behave like food that can run out.
local COUNTER_NAME_PARTS = { 'round', 'remain', 'left', 'timer', 'expire', 'duration', 'turns', 'perish', 'uses', 'shelf' }
local COUNTER_WORDS = { remaining = true, expires = true, expire = true, expiring = true, rounds = true, uses = true, perishes = true, spoils = true }

local function counter_config(tbl, depth)
    if type(tbl) ~= 'table' or depth > 2 then return false end
    for k, v in pairs(tbl) do
        if type(k) == 'string' then
            if type(v) == 'number' and v > 0 and name_has(k, COUNTER_NAME_PARTS) then return true end
            if type(v) == 'table' and counter_config(v, depth + 1) then return true end
        end
    end
    return false
end

local function has_round_counter(center)
    if counter_config(center.config, 0) then return true end
    for _, w in ipairs(description_words(center)) do
        if COUNTER_WORDS[w] then return true end
    end
    return false
end

local food_cache = {}
local function looks_like_food(center)
    if not center then return false end
    local ck = center.key
    if ck and food_cache[ck] ~= nil then return food_cache[ck] end
    local ok, res = pcall(function()
        if center.pools and center.pools.Food then return true end
        if center.key and VANILLA_FOOD[center.key] then return true end
        if type(Cryptid) == 'table' and type(Cryptid.food) == 'table' and center.key then
            for _, k in ipairs(Cryptid.food) do if k == center.key then return true end end
        end
        local tokens = words_of((center.key or ''):gsub('^%a_', ''):gsub('_', ' '))
        for _, w in ipairs(words_of(center.name)) do tokens[#tokens + 1] = w end
        for _, w in ipairs(description_words(center)) do
            if EAT_WORDS[w] then return true end
        end
        if decays_by_itself(center) or code_mentions_food(center) then return true end
        if center.consumeable and has_round_counter(center) then return true end
        for _, w in ipairs(tokens) do
            for _, f in ipairs(FOOD_WORDS) do
                if #f >= 6 then
                    if w:sub(1, #f) == f then return true end          -- "chocolate" starts with "choco"
                elseif w == f or w == f .. 's' then return true end     -- short words match exactly ("pear" yes, "pearl" no)
            end
        end
        return false
    end)
    res = ok and res or false
    if ck then food_cache[ck] = res end
    return res
end

-- Sagatro (HuyTheKiller): its Story Mode only allows Sagatro Jokers, "Disable Sagatro items" removes its cards,
-- and Celestara cards of unplayed secret hands stay locked. Packs pick cards by key, so they must respect that too.
local function is_sagatro(center)
    local ok, res = pcall(function() return center.mod and center.mod.id == 'Sagatro' end)
    return ok and res or false
end

local function sagatro_blocks(center)
    local ok, res = pcall(function()
        local game = G.GAME
        if not game then return false end
        if game.story_mode and center.set == 'Joker' and not center.saga_group then return true end
        if game.modifiers and game.modifiers.sgt_disable_sagatro_items and is_sagatro(center) then return true end
        if center.exclude_from_pool then return true end
        if center.set == 'Celestara' and center.config and center.config.softlock and center.config.hand_type then
            local hand = game.hands and game.hands[center.config.hand_type]
            if not hand or (hand.played or 0) <= 0 then return true end
        end
        return false
    end)
    return ok and res or false
end

local function allowed(center)
    if not center or not center.key or NEVER[center.key] then return false end
    if G.GAME and G.GAME.banned_keys and G.GAME.banned_keys[center.key] then return false end
    if center.hidden or center.no_doe then return false end
    if sagatro_blocks(center) then return false end
    local ok, res = pcall(function()
        if SMODS and SMODS.add_to_pool then return SMODS.add_to_pool(center, {}) end
        return true
    end)
    return (not ok) or res ~= false
end

-- Cards of the pack being opened are created one after another, before any of them is placed in
-- G.pack_cards, so the pack has to remember its own picks (otherwise the same card shows up twice).
local open_pack = { picked = {}, list = nil, is_joker = nil, owner = nil }

local function begin_pack(is_joker)
    open_pack.picked = {}
    open_pack.list = nil
    open_pack.is_joker = is_joker
end

local function candidates(is_joker)
    if open_pack.list and open_pack.is_joker == is_joker then return open_pack.list end
    local out, seen = {}, {}
    local function add(center)
        if center and center.key and not seen[center.key] and allowed(center) then
            seen[center.key] = true; out[#out + 1] = center.key
        end
    end
    if is_joker then
        for _, k in ipairs(OWN_JOKERS) do add(G.P_CENTERS[k]) end
        for _, c in ipairs((G.P_CENTER_POOLS and G.P_CENTER_POOLS.Joker) or {}) do
            if looks_like_food(c) then add(c) end
        end
    else
        for _, k in ipairs(OWN_CONSUMABLES) do add(G.P_CENTERS[k]) end
        -- consumable types added by other mods (Cryptid Code, Bakery treats, ...)
        local types = (SMODS and SMODS.ConsumableTypes) or {}
        for set_key in pairs(types) do
            if not VANILLA_SETS[set_key] and G.P_CENTER_POOLS and G.P_CENTER_POOLS[set_key] then
                for _, c in ipairs(G.P_CENTER_POOLS[set_key]) do
                    -- Sagatro adds 80+ non-food cards: only its food-looking ones belong in a Food pack
                    if not is_sagatro(c) or looks_like_food(c) then add(c) end
                end
            end
        end
        -- food-themed consumables of any type (including vanilla sets)
        for _, set_key in ipairs({ 'Tarot', 'Planet', 'Spectral', 'Consumeables' }) do
            for _, c in ipairs((G.P_CENTER_POOLS and G.P_CENTER_POOLS[set_key]) or {}) do
                if looks_like_food(c) then add(c) end
            end
        end
    end
    open_pack.list = out
    open_pack.is_joker = is_joker
    return out
end

local function pick(is_joker, seed)
    local all = candidates(is_joker)
    local picked = open_pack.picked
    local fresh, fresh_unowned = {}, {}
    for _, k in ipairs(all) do
        if not picked[k] then
            fresh[#fresh + 1] = k
            local owned = is_joker and G.GAME and G.GAME.used_jokers and G.GAME.used_jokers[k]
            if not owned then fresh_unowned[#fresh_unowned + 1] = k end
        end
    end
    -- prefer cards you do not own yet; owned ones are fine, duplicates inside one pack are not
    local from = (#fresh_unowned > 0) and fresh_unowned or fresh
    if #from == 0 then return nil end   -- everything is already in this pack: the caller falls back to the normal pool
    local key = pseudorandom_element(from, pseudoseed(seed .. tostring(G.GAME and G.GAME.round_resets and G.GAME.round_resets.ante or 1) .. tostring(#fresh)))
    if key then picked[key] = true end
    return key
end

local SIZES = {
    { id = 'normal', frame = 0, extra = 3, choose = 1, cost = 5, weight = 0.6,  title = '' },
    { id = 'jumbo',  frame = 1, extra = 5, choose = 1, cost = 7, weight = 0.3,  title = 'Jumbo ' },
    { id = 'mega',   frame = 2, extra = 5, choose = 2, cost = 9, weight = 0.07, title = 'Mega ' },
}

local function make_pack(kind, row, size)
    local is_joker = (kind == 'joker')
    local key = kind .. '_pack_' .. size.id
    local label = size.title .. (is_joker and 'Food Joker Pack' or 'Food Consumable Pack')
    local group = is_joker and 'Food Joker Pack' or 'Food Consumable Pack'
    SMODS.Booster {
        key = key,
        kind = is_joker and 'cbuf_joker' or 'cbuf_consumable',
        atlas = 'cbuf_boosters',
        pos = { x = size.frame, y = row },
        weight = size.weight,
        cost = size.cost,
        config = { extra = size.extra, choose = size.choose },
        discovered = true,
        draw_hand = not is_joker,           -- consumables like Tolape need cards in hand
        loc_txt = {
            name = label,
            group_name = group,
            text = {
                'Choose {C:attention}#1#{} of up to',
                '{C:attention}#2#{} ' .. (is_joker and 'Food {C:attention}Jokers{}' or 'Food & Candy {C:attention}consumables{}'),
            },
        },
        ease_background_colour = function(self)
            if type(ease_background_colour_blind) == 'function' then
                ease_background_colour_blind(is_joker and G.STATES.BUFFOON_PACK or G.STATES.SPECTRAL_PACK)
            end
        end,
        particles = function(self)
            G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
                timer = 0.015, scale = 0.2, initialize = true, lifespan = 1, speed = 1.1, padding = -1,
                attach = G.ROOM_ATTACH,
                colours = { G.C.WHITE, G.C.BLUE, G.C.GOLD, lighten(G.C.BLUE, 0.4) },
                fill = true,
            })
            G.booster_pack_sparkles.fade_alpha = 1
            G.booster_pack_sparkles:fade(1, 0)
        end,
        create_card = function(self, card, i)
            if i == 1 or open_pack.owner ~= card then begin_pack(is_joker); open_pack.owner = card end   -- first card of this pack
            local ok, k = pcall(pick, is_joker, 'cbuf_' .. kind .. '_pack')
            if not ok then log('error', 'pick failed: ' .. tostring(k)); k = nil end
            if k then
                return { key = k, area = G.pack_cards, skip_materialize = true, key_append = 'cbuf_pack' }
            end
            -- nothing from this mod is loaded: fall back to the normal pool
            return { set = is_joker and 'Joker' or 'Spectral', area = G.pack_cards, skip_materialize = true, key_append = 'cbuf_pack' }
        end,
    }
end

for _, size in ipairs(SIZES) do
    make_pack('joker', 0, size)
    make_pack('consumable', 1, size)
end

log('info', 'loaded')
