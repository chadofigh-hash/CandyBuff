-- Candy Buff — Sagatro content (v1.26.33)
--
-- Two fairy-tale Jokers that exist ONLY when the Sagatro mod (HuyTheKiller) is installed and loaded.
-- Without Sagatro this file does nothing, so nothing is added to the game or to the collection.
-- Notes from Sagatro's own files: its id is "Sagatro" (prefix sgt); in Story Mode it removes every Joker without
-- `saga_group` from the pool, so these two never show up there (the story keeps its own jokers).
-- Both count Food Jokers (this mod's, vanilla's and other mods', including Sagatro's food Jokers)
-- using the same food detection as the Candy Deck and the Food packs.
--
-- Isolated like the other files (see main.lua): a failure is written to the Lovely log ("CandyBuff sagatro").

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] sagatro: ' .. msg, 'CandyBuff') end
end

-- Mod id is matched loosely (id or name contains "sagatro"), because the exact id is not hard-coded here.
local function sagatro_loaded()
    local mods = SMODS and SMODS.Mods
    if type(mods) ~= 'table' then return false end
    for id, m in pairs(mods) do
        local label = (tostring(id) .. ' ' .. tostring(type(m) == 'table' and m.name or '')):lower()
        if label:find('sagatro', 1, true) and not (type(m) == 'table' and m.can_load == false) then
            return true
        end
    end
    return false
end

if not sagatro_loaded() then
    log('info', 'Sagatro not installed: skipped')
    return
end

local API = _G.CBUF_API or {}
local OWN = { j_cbuf_breadcrumbs = true, j_cbuf_gingerbread_house = true }

-- Food Jokers owned right now (the Joker itself and the other Sagatro Jokers of this file never count).
local function food_count(self_card)
    local n = 0
    local check = API.is_food_joker
    if type(check) ~= 'function' or not (G and G.jokers and G.jokers.cards) then return 0 end
    for _, j in ipairs(G.jokers.cards) do
        if j ~= self_card and not OWN[j.config and j.config.center and j.config.center.key or ''] then
            local ok, res = pcall(check, j)
            if ok and res then n = n + 1 end
        end
    end
    return n
end

-- JokerDisplay (Sagatro has a big JokerDisplay integration, so people using it expect these to show values too).
local function jd(key, fn)
    if type(API.jd) == 'function' then return API.jd(key, fn) end
    return fn
end

SMODS.Atlas { key = 'cbuf_breadcrumbs', path = 'sagatro_breadcrumbs.png', px = 71, py = 95, disable_mipmap = true }
SMODS.Atlas { key = 'cbuf_gingerbread_house', path = 'sagatro_gingerbread_house.png', px = 71, py = 95, disable_mipmap = true }

-- Gretel's Breadcrumbs (Common): +4 Mult for every Food Joker you own.
SMODS.Joker {
    key = 'breadcrumbs',
    atlas = 'cbuf_breadcrumbs',
    pos = { x = 0, y = 0 },
    rarity = 1,
    cost = 4,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = { mult = 4 } },
    joker_display_def = jd('j_cbuf_breadcrumbs', function(JokerDisplay)
        return {
            text = { { text = '+' }, { ref_table = 'card.joker_display_values', ref_value = 'mult' } },
            text_config = { colour = G.C.MULT },
            calc_function = function(card)
                local ex = card.ability.extra or {}
                card.joker_display_values.mult = (ex.mult or 0) * food_count(card)
            end,
        }
    end),
    loc_txt = {
        name = "Gretel's Breadcrumbs",
        text = {
            '{C:red}+#1#{} Mult for each',
            '{C:attention}Food Joker{} you own',
            '{C:inactive}(Currently {C:red}+#2#{C:inactive} Mult){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = (card and card.ability and card.ability.extra) or self.config.extra
        return { vars = { ex.mult, ex.mult * food_count(card) } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local ex = card.ability.extra
            local n = food_count(card)
            if n > 0 then return { mult = ex.mult * n } end
        end
    end,
}

-- Gingerbread House (Rare): X0.25 Mult for every Food Joker you own, up to 5 of them.
SMODS.Joker {
    key = 'gingerbread_house',
    atlas = 'cbuf_gingerbread_house',
    pos = { x = 0, y = 0 },
    rarity = 3,
    cost = 8,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = { xmult = 0.25, cap = 5 } },
    joker_display_def = jd('j_cbuf_gingerbread_house', function(JokerDisplay)
        return {
            text = {
                { border_nodes = {
                    { text = 'X' },
                    { ref_table = 'card.joker_display_values', ref_value = 'xmult' },
                } },
            },
            calc_function = function(card)
                local ex = card.ability.extra or {}
                card.joker_display_values.xmult = 1 + (ex.xmult or 0) * math.min(food_count(card), ex.cap or 5)
            end,
        }
    end),
    loc_txt = {
        name = 'Gingerbread House',
        text = {
            '{X:mult,C:white}X#1#{} Mult for each {C:attention}Food Joker{}',
            'you own {C:inactive}(up to #2#){}',
            '{C:inactive}(Currently {X:mult,C:white}X#3#{C:inactive} Mult){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = (card and card.ability and card.ability.extra) or self.config.extra
        local n = math.min(food_count(card), ex.cap)
        return { vars = { ex.xmult, ex.cap, 1 + ex.xmult * n } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local ex = card.ability.extra
            local n = math.min(food_count(card), ex.cap)
            if n > 0 then return { xmult = 1 + ex.xmult * n } end
        end
    end,
}

log('info', 'loaded')
