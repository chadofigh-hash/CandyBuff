-- Candy Buff — Test Your Luck (Deck) (v1.26.81)
--
-- Everything has a 1 in 2 chance to work, and every MISS makes the numbers grow:
--   * Playing cards:  each scoring card has a 1 in 2 chance to score. A miss debuffs it for this hand
--                     and doubles its chips and mult (permanent bonus).
--   * Jokers:         each time a Joker would trigger it has a 1 in 2 chance to. A miss cancels that
--                     trigger and doubles the numbers on the Joker.
--     3 HITS on a doubled Joker / playing card bring it back to its original numbers (CFG.hits_to_reset).
--     A Lucky Card's miss doubles its chancy +Mult / +$ (it never becomes a guaranteed +20 Mult).
--   * Consumables:    each use has a 1 in 2 chance to work (like The Wheel of Fortune's "Nope!").
--                     A miss USES THE CARD UP and doubles the numbers of that consumable (each kind on
--                     its own, e.g. The Hermit) for every copy you own, find or buy. A success works
--                     with the numbers shown on the card and sends that kind back to its normal numbers.
--   * Blinds:         Small and Big have a 1 in 2 chance to be played. A miss skips it straight to the shop
--                     with NO money (blind reward, hands, discards and interest are all cancelled), and the
--                     next roll of that blind is better (2 in 3, 3 in 4 ...) until it hits.
--                     Boss Blinds can not be skipped: a miss just makes the required score x2.
--                     (Blind-select shows a number instead of a long row of $ above 8.)
--
--   * Shop:           Jokers and Joker (Buffoon) packs show up in the shop with a 0.002% chance (CFG.shop_joker_chance,
--                     CFG.shop_pack_chance); the free Joker of Luck Pack at run start is how you find Jokers here.
--
-- Everything you may want to tweak is in CFG below.
-- Safety: every hook is inside pcall; failures go to the Lovely log (search "CandyBuff luck").

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] luck: ' .. msg, 'CandyBuff') end
end

local CFG = {
    success_chance = 0.5,   -- "1 in 2"
    max_value = 1e12,       -- numbers stop doubling past this (keeps the game from overflowing)
    shop_pack_chance = 0.00002,   -- 0.002%: chance that a shop pack is a Joker (Buffoon) pack
    shop_joker_chance = 0.00002,  -- 0.002%: chance that a shop card is a Joker in this deck
    max_cons_doubles = 8,   -- a consumable kind can double at most this many times in a row
    hits_to_reset = 3,      -- this many HITS bring a doubled Joker / playing card back to its original numbers
    hits_in_a_row = false,  -- true = the hits must come one after another (a miss starts the count again)
    max_pity = 8,           -- Small / Big hit chance after misses: 1 in 2, 2 in 3 ... up to (max_pity+1) in (max_pity+2)
    boss_miss_mult = 2,     -- a missed Boss Blind needs this much more score (it can not be skipped)
    dollar_icons_max = 8,   -- blind-select reward: more $ than this are shown as a number
}

local DECK_KEY = 'b_cbuf_luck_test'
local RED = HEX and HEX('D9553E') or (G and G.C and G.C.RED)

local function active()
    local b = G and G.GAME and G.GAME.selected_back
    return b and b.effect and b.effect.center and b.effect.center.key == DECK_KEY
end

-- Goes through Steamodded's probability system, so Jokers that change odds (Oops! All 6s, Cryptid
-- Jokers...) help here too: with Oops! All 6s "1 in 2" becomes "2 in 2" = always works.
-- 'obj' is the card the roll belongs to (nil for blinds).
local function roll(seed, obj, num, den)
    num = num or 1
    den = den or math.max(1, math.floor(1 / CFG.success_chance + 0.5))
    if SMODS and type(SMODS.pseudorandom_probability) == 'function' then
        local ok, r = pcall(SMODS.pseudorandom_probability, obj, seed, num, den, seed)
        if ok then return r and true or false end
    end
    local normal = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return pseudorandom(seed) < math.min(1, (num / den) * normal)
end

local function say(card, text)
    pcall(function()
        card_eval_status_text(card, 'extra', nil, nil, nil, { message = text, colour = RED })
    end)
end

-- Number doubling -----------------------------------------------------------------
-- Names that are chances / counters / sizes: doubling them would be nonsense or break the game.
local SKIP = { 'odds', 'chance', 'prob', 'denom', 'round', 'count', 'hands', 'discards', 'size',
               'index', 'pos', 'cost', 'id', 'limit', 'cards', 'turn', 'dissolve' }

local function skipped(key)
    key = tostring(key):lower()
    for _, w in ipairs(SKIP) do
        if key:find(w, 1, true) then return true end
    end
    return false
end

local function is_x(key)   -- X mult style values (1.5 -> 2.0 instead of 3.0)
    key = tostring(key):lower()
    return key:sub(1, 1) == 'x' or key:find('xmult', 1, true) or key:find('x_mult', 1, true)
end

local function dbl(key, v)
    if type(v) ~= 'number' or v == 0 or math.abs(v) > CFG.max_value then return v end
    if is_x(key) and v > 1 then return 1 + (v - 1) * 2 end
    return v * 2
end

local function map_table(t, fn, depth)
    if type(t) ~= 'table' or depth > 3 then return end
    for k, v in pairs(t) do
        if type(v) == 'number' and not skipped(k) then
            t[k] = fn(k, v)
        elseif type(v) == 'table' then
            map_table(v, fn, depth + 1)
        end
    end
end

local JOKER_TOP = { 'mult', 't_mult', 't_chips', 'h_mult', 'x_mult', 'h_x_mult', 'bonus' }

local function map_joker(card, fn)
    local ab = card.ability
    if not ab then return end
    for _, k in ipairs(JOKER_TOP) do
        if type(ab[k]) == 'number' then ab[k] = fn(k, ab[k]) end
    end
    if type(ab.extra) == 'number' then
        ab.extra = fn('extra', ab.extra)
    elseif type(ab.extra) == 'table' then
        map_table(ab.extra, fn, 1)
    end
end

-- A miss doubles the Joker; we count the doublings (cbuf_luck_dbl) so that 3 hits can undo them.
local function double_joker(card)
    local ab = card.ability
    if not ab then return end
    map_joker(card, dbl)
    ab.cbuf_luck_dbl = (ab.cbuf_luck_dbl or 0) + 1
    if CFG.hits_in_a_row then ab.cbuf_luck_hits = 0 end
end

-- Undo every doubling: plain numbers are divided by 2^n, X values lose their extra part the same way.
-- (Growth the Joker gained in between is kept in proportion instead of being wiped out.)
local function undo_joker(card)
    local ab = card.ability
    local n = ab and ab.cbuf_luck_dbl or 0
    if n < 1 then return end
    local f = 2 ^ n
    map_joker(card, function(key, v)
        if type(v) ~= 'number' or v == 0 or math.abs(v) > CFG.max_value then return v end
        if is_x(key) and v > 1 then return 1 + (v - 1) / f end
        return v / f
    end)
end

local function is_lucky(card)
    local key = card.config and card.config.center and card.config.center.key
    return key == 'm_lucky' or (card.ability and card.ability.name == 'Lucky Card')
end

local function double_playing(card)
    local ab = card.ability
    if not ab then return end
    local added = ab.cbuf_luck_added or { chips = 0, mult = 0 }
    ab.cbuf_luck_added = added
    -- chips: add what the card is worth now, so the total doubles
    local ok, chips = pcall(card.get_chip_bonus, card)
    if ok and type(chips) == 'number' and chips > 0 and chips < CFG.max_value then
        ab.perma_bonus = (ab.perma_bonus or 0) + chips
        added.chips = added.chips + chips
    end
    -- mult: permanent mult doubles. A Lucky Card's +20 Mult only happens 1 in 5, so it must NOT become a
    -- guaranteed bonus: instead its own chancy numbers (+Mult and +$) are doubled.
    local m = ab.perma_mult or 0
    if is_lucky(card) then
        ab.cbuf_luck_lucky = ab.cbuf_luck_lucky or { mult = ab.mult, dollars = ab.p_dollars }
        if type(ab.mult) == 'number' and ab.mult < CFG.max_value then ab.mult = ab.mult * 2 end
        if type(ab.p_dollars) == 'number' and ab.p_dollars < CFG.max_value then ab.p_dollars = ab.p_dollars * 2 end
    else
        m = m + (ab.mult or 0)
    end
    if type(m) == 'number' and m > 0 and m < CFG.max_value then
        ab.perma_mult = (ab.perma_mult or 0) + m
        added.mult = added.mult + m
    end
    ab.cbuf_luck_dbl = (ab.cbuf_luck_dbl or 0) + 1
    if CFG.hits_in_a_row then ab.cbuf_luck_hits = 0 end
end

local function undo_playing(card)
    local ab = card.ability
    if not ab then return end
    local a = ab.cbuf_luck_added
    if a then
        ab.perma_bonus = (ab.perma_bonus or 0) - a.chips
        ab.perma_mult = (ab.perma_mult or 0) - a.mult
    end
    local l = ab.cbuf_luck_lucky
    if l and is_lucky(card) then
        if l.mult ~= nil then ab.mult = l.mult end
        if l.dollars ~= nil then ab.p_dollars = l.dollars end
    end
    ab.cbuf_luck_added, ab.cbuf_luck_lucky = nil, nil
end

-- A HIT on a doubled card counts; after CFG.hits_to_reset hits it goes back to its original numbers.
local function register_hit(card, undo)
    local ab = card and card.ability
    if not ab or (ab.cbuf_luck_dbl or 0) < 1 then return end
    ab.cbuf_luck_hits = (ab.cbuf_luck_hits or 0) + 1
    if ab.cbuf_luck_hits >= CFG.hits_to_reset then
        undo(card)
        ab.cbuf_luck_dbl, ab.cbuf_luck_hits = nil, nil
        pcall(function() card:juice_up(0.4, 0.4) end)
        say(card, 'Back to normal!')
    end
end

-- Consumables: numbers are scaled per KIND (center key), so every copy shows and uses the same numbers --
-- The numbers live in two places (card.ability.* and card.ability.consumeable.*): both are scaled, so what
-- the description says is what the card really does.
local NO_SCALE = { c_wheel_of_fortune = true }       -- its only number is a chance, not a strength
local CONS_FIELDS = { 'max_highlighted', 'mod_num' }

local function mul_table(t, ratio, depth)
    if type(t) ~= 'table' or depth > 3 then return end
    for k, v in pairs(t) do
        if type(v) == 'number' and not skipped(k) then
            t[k] = v * ratio
        elseif type(v) == 'table' then
            mul_table(v, ratio, depth + 1)
        end
    end
end

local function mul_fields(ab, ratio)
    for _, k in ipairs(CONS_FIELDS) do
        if type(ab[k]) == 'number' then ab[k] = ab[k] * ratio end
    end
    if type(ab.extra) == 'number' then
        ab.extra = ab.extra * ratio
    elseif type(ab.extra) == 'table' then
        mul_table(ab.extra, ratio, 1)
    end
end

local function center_key(card)
    return card and card.config and card.config.center and card.config.center.key
end

local function is_consumable(card)
    local set = card and card.ability and card.ability.set
    return card and card.ability and (card.ability.consumeable ~= nil or set == 'Tarot'
        or set == 'Planet' or set == 'Spectral')
end

local function cons_scale_of(key)
    local t = G and G.GAME and G.GAME.cbuf_luck_cons
    return (t and t[key]) or 1
end

local function set_card_scale(card, target)
    local ab = card.ability
    if not ab then return end
    local key = center_key(card)
    if not key or NO_SCALE[key] then return end
    local cur = ab.cbuf_luck_scale or 1
    if cur == target then return end
    local ratio = target / cur
    mul_fields(ab, ratio)
    if type(ab.consumeable) == 'table' then
        if not ab.cbuf_luck_own then          -- never touch the table shared with the card definition
            ab.consumeable = copy_table(ab.consumeable)
            ab.cbuf_luck_own = true
        end
        mul_fields(ab.consumeable, ratio)
    end
    ab.cbuf_luck_scale = target
end

local function each_cons_of(key, fn, except)
    local areas = { G.consumeables, G.shop_jokers, G.pack_cards }
    for _, area in ipairs(areas) do
        if area and area.cards then
            for _, c in ipairs(area.cards) do
                if c ~= except and center_key(c) == key then pcall(fn, c) end
            end
        end
    end
end

local function cons_miss(card, key)
    G.GAME.cbuf_luck_cons = G.GAME.cbuf_luck_cons or {}
    local scale = math.min(cons_scale_of(key) * 2, 2 ^ CFG.max_cons_doubles)
    G.GAME.cbuf_luck_cons[key] = scale
    each_cons_of(key, function(c) set_card_scale(c, scale) end, card)
    if G.hand then G.hand:unhighlight_all() end
    say(card, 'Nope! x2')
end

local function cons_success(card, key)
    if G.GAME.cbuf_luck_cons then G.GAME.cbuf_luck_cons[key] = nil end
    -- the used card keeps its numbers (its effect may still be running); every other copy goes back to normal
    each_cons_of(key, function(c) set_card_scale(c, 1) end, card)
end

-- Jokers: each trigger has a 1 in 2 chance --------------------------------------
local JOKER_CONTEXTS = {
    'joker_main', 'individual', 'repetition', 'before', 'after', 'other_joker', 'end_of_round',
    'discard', 'setting_blind', 'reroll_shop', 'buying_card', 'selling_card', 'using_consumeable',
    'ending_shop', 'skip_blind', 'first_hand_drawn', 'open_booster', 'skipping_booster',
}

local function is_trigger_context(context)
    if type(context) ~= 'table' then return false end
    for _, k in ipairs(JOKER_CONTEXTS) do
        if context[k] then return true end
    end
    return false
end

if Card and type(Card.calculate_joker) == 'function' and not Card._cbuf_luck_hooked then
    Card._cbuf_luck_hooked = true
    local ref = Card.calculate_joker
    function Card:calculate_joker(context, ...)
        local a, b = ref(self, context, ...)
        if (a or b) and active() and self.ability and self.ability.set == 'Joker'
            and is_trigger_context(context) then
            local ok, hit = pcall(roll, 'cbuf_luck_joker', self)
            if ok and not hit then
                pcall(function()
                    double_joker(self)
                    self:juice_up(0.3, 0.3)
                    say(self, 'Miss! x2')
                end)
                return nil, nil
            end
            if ok and hit then pcall(register_hit, self, undo_joker) end
        end
        return a, b
    end
else
    log('warn', 'Card.calculate_joker not found: Jokers will not miss')
end

-- Consumables: each use has a 1 in 2 chance --------------------------------------
if Card and type(Card.use_consumeable) == 'function' and not Card._cbuf_luck_use_hooked then
    Card._cbuf_luck_use_hooked = true
    local ref = Card.use_consumeable
    function Card:use_consumeable(area, copier, ...)
        if active() and not copier and is_consumable(self) then
            local key = center_key(self)
            local ok, hit = pcall(roll, 'cbuf_luck_use', self)
            if ok and key and not hit then
                pcall(cons_miss, self, key)
                -- like The Wheel of Fortune's "Nope!": the card is used up. Make sure it really goes away.
                pcall(function()
                    G.E_MANAGER:add_event(Event({
                        trigger = 'after', delay = 0.6, blocking = false, blockable = false,
                        func = function()
                            if self.area and not self.dissolve and not self.removed then
                                self:start_dissolve()
                            end
                            return true
                        end }))
                end)
                return
            end
            if ok and key then
                pcall(set_card_scale, self, cons_scale_of(key))     -- cards made before the last miss
                local r1, r2 = ref(self, area, copier, ...)
                pcall(cons_success, self, key)
                return r1, r2
            end
        end
        return ref(self, area, copier, ...)
    end
else
    log('warn', 'Card.use_consumeable not found: consumables will not miss')
end

-- New consumables (shop, packs, creation) start with the numbers of their kind
if Card and type(Card.set_ability) == 'function' and not Card._cbuf_luck_ability_hooked then
    Card._cbuf_luck_ability_hooked = true
    local ref = Card.set_ability
    function Card:set_ability(...)
        local r = ref(self, ...)
        pcall(function()
            if active() and is_consumable(self) then
                local key = center_key(self)
                local scale = key and cons_scale_of(key) or 1
                if scale ~= 1 then set_card_scale(self, scale) end
            end
        end)
        return r
    end
end

-- Blinds: each blind has a 1 in 2 chance to be played ------------------------------
-- Small, Big and every Boss are tracked on their own (by blind key). The reward ("dollars") and the
-- required score ("mult") live in the blind definition, so changing them there also changes what the
-- blind-select screen shows.
local P_ORIG = {}

local function blind_def(key)
    return G and G.P_BLINDS and G.P_BLINDS[key]
end

local function apply_blind_scale(key)
    local def = blind_def(key)
    if not def then return end
    P_ORIG[key] = P_ORIG[key] or { mult = def.mult, dollars = def.dollars }
    local n = (G.GAME and G.GAME.cbuf_luck_blind and G.GAME.cbuf_luck_blind[key]) or 0
    local f = 2 ^ n
    def.mult = (P_ORIG[key].mult or 1) * f
    def.dollars = (P_ORIG[key].dollars or 0) * f
end

local function restore_all_blinds()
    for key, o in pairs(P_ORIG) do
        local def = blind_def(key)
        if def then def.mult = o.mult; def.dollars = o.dollars end
    end
end

local function restore_interest()
    if G and G.GAME and G.GAME.cbuf_luck_cap ~= nil then
        G.GAME.interest_cap = G.GAME.cbuf_luck_cap
        G.GAME.cbuf_luck_cap = nil
    end
end

local function auto_cash_out()
    local tries = 0
    G.E_MANAGER:add_event(Event({
        trigger = 'after', delay = 0.5, blocking = false, blockable = false,
        func = function()
            if not (G and G.GAME and G.GAME.cbuf_luck_nomoney) then return true end
            tries = tries + 1
            if tries > 600 then return true end      -- give up: the player can press Cash Out
            if G.round_eval and G.STATE == G.STATES.ROUND_EVAL and G.round_eval.get_UIE_by_ID then
                local btn = G.round_eval:get_UIE_by_ID('cash_out_button')
                if btn and G.FUNCS and G.FUNCS.cash_out then
                    pcall(G.FUNCS.cash_out, btn)
                    return true
                end
            end
            return false
        end }))
end

local function forced_win()
    G.GAME.blind.dollars = 0                         -- no blind reward
    G.GAME.current_round.hands_left = 0              -- no money for hands left
    G.GAME.current_round.discards_left = 0           -- nor for discards
    if G.GAME.cbuf_luck_cap == nil then G.GAME.cbuf_luck_cap = G.GAME.interest_cap end
    G.GAME.interest_cap = 0                          -- no interest
    G.GAME.cbuf_luck_nomoney = true
    pcall(function()
        attention_text({ text = 'Miss! Blind skipped' .. (G.GAME.cbuf_luck_next_odds and (' (next: ' .. G.GAME.cbuf_luck_next_odds .. ')') or ''), scale = 0.9, hold = 1.6, align = 'cm',
            offset = { x = 0, y = -2.7 }, major = G.play, colour = RED })
    end)
    G.GAME.chips = G.GAME.blind.chips
    G.STATE = G.STATES.HAND_PLAYED
    G.STATE_COMPLETE = true
    end_round()
    auto_cash_out()
end

local function schedule_forced_win()
    G.E_MANAGER:add_event(Event({
        trigger = 'after', delay = 0.3, blocking = false, blockable = false,
        func = function()
            if not (G and G.GAME and G.GAME.cbuf_luck_blind_state == 'miss') then return true end
            if G.STATE ~= G.STATES.SELECTING_HAND or not G.STATE_COMPLETE
                or not (G.hand and G.hand.cards and #G.hand.cards > 0)
                or (G.CONTROLLER and G.CONTROLLER.locked) then
                return false                          -- wait until the hand is dealt
            end
            G.GAME.cbuf_luck_blind_state = 'skipping'
            local ok, err = pcall(forced_win)
            if not ok then log('error', 'forced win failed: ' .. tostring(err)) end
            return true
        end }))
end

-- Small / Big: every miss makes the NEXT roll of that blind better (1 in 2 -> 2 in 3 -> 3 in 4 ...),
-- a hit sends it back to 1 in 2. Boss Blinds can not be skipped: a miss just multiplies the required score.
local function pity_odds(key)
    local k = (G.GAME.cbuf_luck_pity and G.GAME.cbuf_luck_pity[key]) or 0
    return 1 + k, 2 + k
end

local function blind_roll(self, blind)
    local key = blind.key
    G.GAME.cbuf_luck_blind_cat = key
    if blind.boss then
        if roll('cbuf_luck_blind_boss') then
            G.GAME.cbuf_luck_blind_state = 'hit'
            return
        end
        G.GAME.cbuf_luck_blind_state = 'boss_miss'
        local f = CFG.boss_miss_mult
        self.chips = self.chips * f
        if type(number_format) == 'function' then self.chip_text = number_format(self.chips) end
        pcall(function()
            attention_text({ text = 'Miss! Score x' .. tostring(f), scale = 0.9, hold = 1.6, align = 'cm',
                offset = { x = 0, y = -2.7 }, major = G.play, colour = RED })
        end)
        return
    end
    G.GAME.cbuf_luck_pity = G.GAME.cbuf_luck_pity or {}
    local n, d = pity_odds(key)
    if roll('cbuf_luck_blind', nil, n, d) then
        G.GAME.cbuf_luck_pity[key] = nil
        G.GAME.cbuf_luck_blind_state = 'hit'
        return
    end
    G.GAME.cbuf_luck_pity[key] = math.min((G.GAME.cbuf_luck_pity[key] or 0) + 1, CFG.max_pity)
    G.GAME.cbuf_luck_blind_state = 'miss'
    local n2, d2 = pity_odds(key)
    G.GAME.cbuf_luck_next_odds = n2 .. ' in ' .. d2
    schedule_forced_win()
end

if Blind and type(Blind.set_blind) == 'function' and not Blind._cbuf_luck_hooked then
    Blind._cbuf_luck_hooked = true
    local ref = Blind.set_blind
    function Blind:set_blind(blind, reset, ...)
        local r = ref(self, blind, reset, ...)
        pcall(function()
            restore_interest()
            if active() and not reset and type(blind) == 'table' and blind.key then
                blind_roll(self, blind)
            end
        end)
        return r
    end
else
    log('warn', 'Blind.set_blind not found: blinds will not miss')
end

if Blind and type(Blind.defeat) == 'function' and not Blind._cbuf_luck_defeat_hooked then
    Blind._cbuf_luck_defeat_hooked = true
    local ref = Blind.defeat
    function Blind:defeat(...)
        local r = ref(self, ...)
        pcall(function()
            if active() then G.GAME.cbuf_luck_blind_state = nil end
        end)
        return r
    end
end

-- Blind-select screen: past CFG.dollar_icons_max the row of "$$$$$$$$$$$$" becomes "$12" (a long row
-- widens the blind boxes and looks rough). Works in every deck.
local function shorten_dollars(node, depth)
    if type(node) ~= 'table' or depth > 14 then return end
    local c = node.config
    if node.n == G.UIT.T and type(c) == 'table' and type(c.text) == 'string' then
        local t = c.text
        if #t > CFG.dollar_icons_max and not t:find('[^%$]') then
            c.text = '$' .. tostring(#t)
        end
    end
    for _, child in pairs(node) do
        if type(child) == 'table' then shorten_dollars(child, depth + 1) end
    end
end

if type(create_UIBox_blind_choice) == 'function' and not _G._cbuf_luck_choice_hooked then
    _G._cbuf_luck_choice_hooked = true
    local ref = create_UIBox_blind_choice
    function create_UIBox_blind_choice(...)
        local ui = ref(...)
        pcall(shorten_dollars, ui, 0)
        return ui
    end
else
    log('warn', 'create_UIBox_blind_choice not found: the $ row is left as it is')
end

if G and G.FUNCS and type(G.FUNCS.cash_out) == 'function' and not G.FUNCS._cbuf_luck_cash then
    G.FUNCS._cbuf_luck_cash = true
    local ref = G.FUNCS.cash_out
    G.FUNCS.cash_out = function(e, ...)
        pcall(function()
            if G.GAME and G.GAME.cbuf_luck_nomoney then
                restore_interest()
                if G.GAME.current_round then G.GAME.current_round.dollars = 0 end
                G.GAME.cbuf_luck_nomoney = nil
            end
        end)
        return ref(e, ...)
    end
end

-- keep the blind definitions in sync with the run
if Game and type(Game.start_run) == 'function' and not Game._cbuf_luck_run_hooked then
    Game._cbuf_luck_run_hooked = true
    local ref = Game.start_run
    function Game:start_run(...)
        pcall(restore_all_blinds)
        return ref(self, ...)
    end
    if type(Game.delete_run) == 'function' then
        local ref_del = Game.delete_run
        function Game:delete_run(...)
            pcall(restore_all_blinds)
            return ref_del(self, ...)
        end
    end
end

-- Shop: Jokers are almost never offered -------------------------------------------
-- The shop picks a card type with weights: Joker 20, Tarot 4, Planet 4 (+ Playing card / Spectral 0).
-- We set the Joker weight so that P(Joker) = CFG.shop_joker_chance, whatever the other weights are now.
local function set_shop_joker_rate()
    local g = G and G.GAME
    if not g then return end
    local others = (g.tarot_rate or 0) + (g.planet_rate or 0) + (g.playing_card_rate or 0) + (g.spectral_rate or 0)
    if others <= 0 then return end
    local p = CFG.shop_joker_chance
    g.joker_rate = others * p / (1 - p)
end

if type(create_card_for_shop) == 'function' and not _G._cbuf_luck_shop_hooked then
    _G._cbuf_luck_shop_hooked = true
    local ref = create_card_for_shop
    function create_card_for_shop(...)
        if active() then pcall(set_shop_joker_rate) end
        return ref(...)
    end
else
    log('warn', 'create_card_for_shop not found: Jokers keep their normal shop chance')
end

-- Shop: Jokers (Buffoon) packs are almost never offered ---------------------------------
-- Wraps get_pack (the shop's pack picker). A Buffoon pack is kept only with CFG.shop_pack_chance; otherwise
-- the pick is redone (up to 20 times) until it is something else. Other pack kinds are untouched.
if type(get_pack) == 'function' and not _G._cbuf_luck_getpack_hooked then
    _G._cbuf_luck_getpack_hooked = true
    local ref = get_pack
    function get_pack(...)
        local args = { ... }
        local n = select('#', ...)
        local pack = ref(...)
        local ok, res = pcall(function()
            if not active() then return pack end
            local p = pack
            for i = 1, 20 do
                local kind = p and p.kind
                if kind ~= 'Buffoon' then return p end
                if pseudorandom('cbuf_luck_buffoon' .. i .. tostring(G.GAME.round or 0)) < CFG.shop_pack_chance then return p end
                p = ref(unpack(args, 1, n))
            end
            return p
        end)
        if ok then return res end
        return pack
    end
else
    log('warn', 'get_pack not found: Joker packs keep their normal shop chance')
end

-- Playing cards: the deck itself decides which scoring cards score ----------------
local function set_miss_debuff(card, on)
    if SMODS and type(SMODS.debuff_card) == 'function' then
        SMODS.debuff_card(card, on and true or false, 'cbuf_luck')
    else
        card.debuff = on and true or false
    end
end

-- Side box text. localize() needs the *_parsed tables, which the game only builds for entries that exist when
-- it loads the language, so we build them ourselves (same trick as the Old Couch box in couch.lua).
local function install_loc()
    pcall(function()
        local loc = G and G.localization
        if not (loc and loc.descriptions) or type(loc_parse_string) ~= 'function' then return end
        loc.descriptions.Other = loc.descriptions.Other or {}
        local cur = loc.descriptions.Other.cbuf_luck_reset
        if cur and cur.text_parsed and cur.name_parsed then return end
        local entry = { name = 'Good to know', text = {
            'Every {C:attention}' .. CFG.hits_to_reset .. ' hits{} bring a Joker',
            'or playing card back to',
            'its {C:attention}original{} numbers',
            '{C:attention}Small / Big{} miss: skipped,',
            'the next roll is better',
            '{C:attention}Boss{} miss: score {X:mult,C:white}x' .. CFG.boss_miss_mult .. '{}',
        } }
        entry.name_parsed = { loc_parse_string(entry.name) }
        entry.text_parsed = {}
        for _, line in ipairs(entry.text) do
            entry.text_parsed[#entry.text_parsed + 1] = loc_parse_string(line)
        end
        loc.descriptions.Other.cbuf_luck_reset = entry
    end)
end
install_loc()
if type(init_localization) == 'function' and not _G._cbuf_luck_loc then
    local ref = init_localization
    function init_localization(...)
        local r = ref(...)
        install_loc()
        return r
    end
    _G._cbuf_luck_loc = true
end

SMODS.Atlas { key = 'cbuf_luck_back', path = 'cbuf_luck_back.png', px = 71, py = 95, disable_mipmap = true }

SMODS.Back {
    key = 'luck_test',
    name = 'Test Your Luck',
    atlas = 'cbuf_luck_back',
    pos = { x = 0, y = 0 },
    unlocked = true,
    discovered = true,
    config = {},
    loc_txt = {
        name = 'Test Your Luck',
        text = {
            '{s:0.85}Everything has a {s:0.85,C:green}1 in 2{s:0.85} chance',
            '{s:0.85}to work: {s:0.85,C:attention}score{s:0.85}, {s:0.85,C:attention}trigger{s:0.85}, {s:0.85,C:attention}use{s:0.85}, {s:0.85,C:attention}blind',
            '{s:0.85}A {s:0.85,C:attention}miss{s:0.85} doubles the numbers',
            '{s:0.85}Shop Jokers & Joker Packs: {s:0.85,C:green}0.002%{s:0.85}',
            '{s:0.85}Free {s:0.85,C:attention}Joker of Luck Pack{s:0.85} at run start',
        },
    },
    -- the side box (like Negative's) next to the deck's text
    loc_vars = function(self, info_queue, back)
        local ent = G and G.localization and G.localization.descriptions
            and G.localization.descriptions.Other and G.localization.descriptions.Other.cbuf_luck_reset
        if ent and ent.text_parsed and ent.name_parsed and type(info_queue) == 'table' then
            info_queue[#info_queue + 1] = { set = 'Other', key = 'cbuf_luck_reset', vars = {} }
        end
        return { vars = {} }
    end,
    calculate = function(self, back, context)
        if context.before and context.scoring_hand then
            for _, c in ipairs(context.scoring_hand) do
                local ok, hit = pcall(roll, 'cbuf_luck_score', c)
                if ok and not hit then
                    pcall(function()
                        c.cbuf_luck_missed = true
                        double_playing(c)
                        set_miss_debuff(c, true)
                        say(c, 'Miss! x2')
                    end)
                elseif ok and hit then
                    pcall(register_hit, c, undo_playing)
                end
            end
        elseif context.after and context.scoring_hand then
            for _, c in ipairs(context.scoring_hand) do
                if c.cbuf_luck_missed then
                    c.cbuf_luck_missed = nil
                    pcall(set_miss_debuff, c, false)
                end
            end
        end
    end,
}

log('info', 'loaded')
