-- Candy Buff — Halloween Night (Uncommon Joker, v1.26.84)
--
-- The pumpkin starts EMPTY. When a round starts it becomes one of two things (1 in 2 for Treat):
--
--   TREAT  (idea: TheDragonJaymer08)
--     For this round, the numbers of Enhancements and the Gold Seal grow by 25-50% (rolled at random):
--     Chips (Bonus, Stone), Mult (Mult, Lucky), X Mult (Glass, Steel), X Chips (Orange Juice), money (Gold, Lucky, Gold Seal).
--     Card values are changed in place and put back (from a saved copy) when the shop opens
--     (not at the end of the round: held-in-hand Gold cards still pay the boosted $ at cash-out).
--
--   TRICK  (idea: The REAL Nightmare)
--     Everything that happens when a card is DISCARDED happens one more time: Purple Seals, Hit the Road,
--     Mail-In Rebate, Faceless Joker, ... (every "discard" trigger, also Ramen / Yorick counters; "before a discard" effects like Burnt Joker
--     are not repeated). More Tricks = more repeats (max 3).
--     Done by running the "discard" calculation again (see the hook on SMODS.calculate_context).
--     The extra changes a repeat makes to Joker numbers are temporary: they are taken back when the round ends.
--
-- With an Egg Joker (j_egg, see CFG.egg_jokers) it is always Trick.
-- When the round ends the pumpkin is empty again (Treat boosts are removed when the shop opens). Art: 9 frames (see F_* below).
--
-- Written from reading Steamodded; it could NOT be run inside the game. If something fails the Lovely log
-- says "[CandyBuff] pumpkin".

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] pumpkin: ' .. msg, 'CandyBuff') end
end

local jd = _G.CBUF_API and _G.CBUF_API.jd

local CFG = {
    treat_odds = 2,          -- "1 in 2" for Treat
    min_pct = 25, max_pct = 50,
    max_repeats = 3,         -- Trick: at most this many extra runs of every discard effect
    anim_step = 0.14,        -- seconds per frame of the egg animation
    egg_jokers = { 'j_egg' },  -- owning one of these means the pumpkin is ALWAYS Trick (add 'j_cbuf_roundy' for Roundy)
}

-- art frames in cbuf_pumpkin.png
-- Halloween-night sheet, 9 frames (0-8): 0 yolk splat, 1 big egg, 2 egg, 3 small egg, 4 smaller egg,
-- 5 tiny egg (very small: the START of Trick), 6 empty red cup, 7 pumpkin face, 8 empty sky (the default).  Change the numbers here to re-map the art.
--   default (no mode): empty sky.  Treat: empty cup -> pumpkin face.  Trick: egg falls and splats.
local F_EMPTY, F_TREAT, F_EGG, F_TRICK = 8, 7, { 5, 4, 3, 2, 1, 0 }, 0
local F_TREAT_START = 6

local ORANGE = HEX and HEX('F2873A') or (G and G.C and G.C.ORANGE)

SMODS.Atlas { key = 'cbuf_pumpkin', path = 'cbuf_pumpkin.png', px = 71, py = 95, disable_mipmap = true }

-- helpers ---------------------------------------------------------------------------------------
local function set_frame(card, f)
    local c = card and card.children and card.children.center
    if c and c.set_sprite_pos then
        c:set_sprite_pos({ x = f, y = 0 })
        card.cbuf_pump_frame = f
    end
end

local function say(card, text, colour)
    pcall(function()
        card_eval_status_text(card, 'extra', nil, nil, nil, { message = text, colour = colour or ORANGE })
    end)
end

local function chance(card)
    if SMODS and type(SMODS.pseudorandom_probability) == 'function' then
        local ok, r = pcall(SMODS.pseudorandom_probability, card, 'cbuf_pumpkin', 1, CFG.treat_odds, 'cbuf_pumpkin')
        if ok then return r and true or false end
    end
    local normal = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return pseudorandom('cbuf_pumpkin') < math.min(1, normal / CFG.treat_odds)
end

local function odds_vars(card)
    if SMODS and type(SMODS.get_probability_vars) == 'function' then
        local ok, n, d = pcall(SMODS.get_probability_vars, card, 1, CFG.treat_odds, 'cbuf_pumpkin')
        if ok and n and d then return n, d end
    end
    return (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1, CFG.treat_odds
end

local function has_egg()
    if not (G and G.jokers and G.jokers.cards) then return false end
    for _, j in ipairs(G.jokers.cards) do
        local key = j.config and j.config.center and j.config.center.key
        if key and not j.debuff then
            for _, k in ipairs(CFG.egg_jokers) do
                if key == k then return true end
            end
        end
    end
    return false
end

-- the pumpkins that are in Trick mode right now
local function trick_count()
    local n = 0
    if G and G.jokers and G.jokers.cards then
        for _, j in ipairs(G.jokers.cards) do
            local ex = j.ability and j.ability.extra
            if j.config and j.config.center and j.config.center.key == 'j_cbuf_pumpkin'
                and type(ex) == 'table' and ex.mode == 'trick' and not j.debuff then
                n = n + 1
            end
        end
    end
    return math.min(n, CFG.max_repeats)
end

-- TREAT: scale the numbers of Enhancements -----------------------------------------------------
-- plain numbers grow by pct; X values grow only in their "extra" part (X2 with +50% = X2.5)
local PLAIN = { 'bonus', 'mult', 'h_mult', 'p_dollars', 'h_dollars' }
local XVALS = { 'x_mult', 'h_x_mult', 'x_chips', 'h_x_chips' }

local function round(v) return math.floor(v + 0.5) end

local function scale_cards(pct)
    local f = pct / 100
    for _, c in ipairs((G and G.playing_cards) or {}) do
        local ab = c.ability
        local center = c.config and c.config.center
        if ab and center and center.set == 'Enhanced' and not ab.cbuf_pump_orig then
            local orig = {}
            for _, k in ipairs(PLAIN) do
                local v = ab[k]
                if type(v) == 'number' and v > 0 then
                    orig[k] = v
                    local nv = v * (1 + f)
                    if k == 'bonus' or k == 'p_dollars' or k == 'h_dollars' then nv = round(nv) end
                    ab[k] = nv
                end
            end
            for _, k in ipairs(XVALS) do
                local v = ab[k]
                if type(v) == 'number' and v > 1 then
                    orig[k] = v
                    ab[k] = 1 + (v - 1) * (1 + f)
                end
            end
            -- X Chips kept inside "extra" (Orange Juice): it also grows during the round, so it is undone by
            -- dividing the boost out again instead of from a saved copy
            local ex = ab.extra
            if type(ex) == 'table' and type(ex.x_chips) == 'number' and ex.x_chips > 1 then
                ex.x_chips = 1 + (ex.x_chips - 1) * (1 + f)
                ab.cbuf_pump_xf = 1 + f
            end
            if next(orig) or ab.cbuf_pump_xf then ab.cbuf_pump_orig = orig end
        end
    end
end

local function restore_cards()
    for _, c in ipairs((G and G.playing_cards) or {}) do
        local ab = c.ability
        if ab and ab.cbuf_pump_orig then
            for k, v in pairs(ab.cbuf_pump_orig) do ab[k] = v end
            if ab.cbuf_pump_xf and type(ab.extra) == 'table' and type(ab.extra.x_chips) == 'number' then
                ab.extra.x_chips = 1 + (ab.extra.x_chips - 1) / ab.cbuf_pump_xf
            end
            ab.cbuf_pump_xf = nil
            ab.cbuf_pump_orig = nil
        end
    end
    if G and G.GAME then G.GAME.cbuf_pumpkin_pct = nil end
end

-- ART ANIMATION -------------------------------------------------------------------------------------
local function play_egg(card)
    card.cbuf_pump_anim = true
    for i, f in ipairs(F_EGG) do
        G.E_MANAGER:add_event(Event({
            trigger = 'after', delay = CFG.anim_step,
            func = function()
                pcall(function()
                    set_frame(card, f)
                    card:juice_up(0.25 + 0.05 * i, 0.15)
                    play_sound(i >= 3 and 'cardSlide2' or 'card1', 0.85 + 0.08 * i, 0.5)
                end)
                if i == #F_EGG then card.cbuf_pump_anim = false end
                return true
            end,
        }))
    end
end

-- MODES ---------------------------------------------------------------------------------------------
local function play_treat(card)
    card.cbuf_pump_anim = true
    set_frame(card, F_TREAT_START)
    G.E_MANAGER:add_event(Event({
        trigger = 'after', delay = CFG.anim_step * 3,
        func = function()
            pcall(function()
                if card.ability and card.ability.extra and card.ability.extra.mode == 'treat' then
                    set_frame(card, F_TREAT)
                    card:juice_up(0.3, 0.2)
                end
            end)
            card.cbuf_pump_anim = false
            return true
        end,
    }))
end

local function become_trick(card)
    local ex = card.ability.extra
    ex.mode, ex.pct = 'trick', nil
    say(card, 'Trick!', G.C.RED)
    play_egg(card)
end

local function become_treat(card)
    local ex = card.ability.extra
    ex.mode = 'treat'
    ex.pct = CFG.min_pct + math.floor(pseudorandom('cbuf_pumpkin_pct') * (CFG.max_pct - CFG.min_pct + 1))
    ex.pct = math.min(CFG.max_pct, ex.pct)
    G.GAME.cbuf_pumpkin_pct = math.max(G.GAME.cbuf_pumpkin_pct or 0, ex.pct)
    scale_cards(ex.pct)
    play_treat(card)
    card:juice_up(0.5, 0.3)
    play_sound('timpani', 1.2, 0.5)
    say(card, 'Treat! +' .. ex.pct .. '%', ORANGE)
end

local function become_empty(card)
    local ex = card.ability.extra
    if ex.mode == nil then return end
    ex.mode, ex.pct = nil, nil
    card.cbuf_pump_anim = false
    set_frame(card, F_EMPTY)
end

-- TEMPORARY: what a Trick repeat changes in a Joker's numbers is only lent for this round -------
-- Every repeat is measured (numbers in ability / ability.extra before and after) and the difference is
-- written down on the Joker; when the round ends the differences are taken back. The first, normal run of
-- an effect is never touched, so only the EXTRA part is temporary (Yorick's bonus Xmult, Ramen's extra loss...).
local function num_map(t, path, out, depth)
    out = out or {}
    path = path or {}
    depth = depth or 0
    if type(t) ~= 'table' or depth > 3 then return out end
    for k, v in pairs(t) do
        if type(k) == 'string' or type(k) == 'number' then
            if type(v) == 'number' and not (type(k) == 'string' and k:sub(1, 5) == 'cbuf_') then
                local np = {}
                for i = 1, #path do np[i] = path[i] end
                np[#np + 1] = k
                out[#out + 1] = { p = np, v = v }
            elseif type(v) == 'table' and not (type(k) == 'string' and k:sub(1, 5) == 'cbuf_') then
                local np = {}
                for i = 1, #path do np[i] = path[i] end
                np[#np + 1] = k
                num_map(v, np, out, depth + 1)
            end
        end
    end
    return out
end

local function key_of(p) return table.concat(p, '\1') end

local function joker_snap()
    local s = {}
    for _, j in ipairs((G and G.jokers and G.jokers.cards) or {}) do
        if j.ability and not (j.config and j.config.center and j.config.center.key == 'j_cbuf_pumpkin') then
            local m = {}
            for _, e in ipairs(num_map(j.ability)) do m[key_of(e.p)] = e end
            s[#s + 1] = { card = j, map = m }
        end
    end
    return s
end

local function note_loans(before)
    for _, e in ipairs(before) do
        pcall(function()
            local j = e.card
            if j.removed or j.getting_sliced or j.dissolve or not j.ability then return end
            j.ability.cbuf_trick_loan = j.ability.cbuf_trick_loan or {}
            local loan = j.ability.cbuf_trick_loan
            for _, now in ipairs(num_map(j.ability)) do
                local old = e.map[key_of(now.p)]
                if old and now.v ~= old.v then
                    local found
                    for _, l in ipairs(loan) do
                        if key_of(l.p) == key_of(now.p) then found = l break end
                    end
                    if found then found.d = found.d + (now.v - old.v) else loan[#loan + 1] = { p = now.p, d = now.v - old.v } end
                end
            end
        end)
    end
end

-- give back everything that was lent (round over, new round, pumpkin sold)
local function revert_trick()
    for _, j in ipairs((G and G.jokers and G.jokers.cards) or {}) do
        pcall(function()
            local loan = j.ability and j.ability.cbuf_trick_loan
            if not loan or #loan == 0 then return end
            for _, l in ipairs(loan) do
                local t = j.ability
                for i = 1, #l.p - 1 do t = t and t[l.p[i]] end
                local last = l.p[#l.p]
                if type(t) == 'table' and type(t[last]) == 'number' then t[last] = t[last] - l.d end
            end
            j.ability.cbuf_trick_loan = nil
            log('info', 'Trick loan returned to ' .. tostring(j.config and j.config.center and j.config.center.key))
        end)
    end
end

-- TRICK: run every "discard" effect once more ---------------------------------------------------------
-- Why the first version missed Ramen / Yorick: the repeat re-used the SAME context table, and the first
-- run had already written into it (context.cardarea, flags...), so jokers saw a "dirty" context.
-- Now every repeat gets a CLEAN COPY made before the first run, and its own result list.
local function shallow(t)
    local c = {}
    for k, v in pairs(t) do c[k] = v end
    return c
end

-- the "counter" jokers: if the repeat did not change them, we apply their discard step by hand
local function snap_scalers()
    local s = {}
    for _, j in ipairs((G and G.jokers and G.jokers.cards) or {}) do
        local ab = j.ability
        if ab and not j.debuff and (ab.name == 'Ramen' or ab.name == 'Yorick') then
            s[#s + 1] = { card = j, x = ab.x_mult, d = ab.yorick_discards }
        end
    end
    return s
end

local function fix_scalers(before)
    for _, e in ipairs(before) do
        pcall(function()
            local j, ab = e.card, e.card.ability
            if j.removed or j.getting_sliced or j.dissolve then return end
            if ab.x_mult ~= e.x or ab.yorick_discards ~= e.d then return end   -- it did repeat: nothing to do
            if ab.name == 'Ramen' then
                local loss = type(ab.extra) == 'number' and ab.extra or 0.01
                if ab.x_mult - loss <= 1 then
                    j:start_dissolve(nil, nil, 1.6)
                    log('info', 'Ramen eaten by a Trick repeat (manual)')
                else
                    ab.x_mult = ab.x_mult - loss
                    card_eval_status_text(j, 'extra', nil, nil, nil, { message = localize { type = 'variable', key = 'a_xmult_minus', vars = { loss } }, colour = G.C.RED })
                    log('info', 'Ramen repeated by hand')
                end
            else
                local ex = type(ab.extra) == 'table' and ab.extra or {}
                if (ab.yorick_discards or 0) <= 1 then
                    ab.yorick_discards = ex.discards or 23
                    ab.x_mult = ab.x_mult + (ex.xmult or 1)
                    card_eval_status_text(j, 'extra', nil, nil, nil, { message = localize { type = 'variable', key = 'a_xmult', vars = { ab.x_mult } }, colour = G.C.RED })
                else
                    ab.yorick_discards = ab.yorick_discards - 1
                end
                log('info', 'Yorick repeated by hand')
            end
        end)
    end
end

if SMODS and type(SMODS.calculate_context) == 'function' and not SMODS._cbuf_pumpkin_hooked then
    SMODS._cbuf_pumpkin_hooked = true
    local ref = SMODS.calculate_context
    local running = false
    SMODS.calculate_context = function(context, return_table, ...)
        local fresh
        local n = 0
        if type(context) == 'table' and context.discard and not running then
            n = trick_count()
            if n > 0 then fresh = shallow(context) end        -- copy BEFORE the first run dirties it
        end
        local r1, r2 = ref(context, return_table, ...)
        if n > 0 and fresh then
            running = true
            for _ = 1, n do
                local before = snap_scalers()
                local loans = joker_snap()
                local sink = return_table and {} or nil
                local ok, err = pcall(ref, shallow(fresh), sink, ...)
                if not ok then log('warn', 'repeat failed: ' .. tostring(err)) end
                if sink then                                    -- hand the repeat's results to the caller
                    for i = 1, #sink do return_table[#return_table + 1] = sink[i] end
                end
                fix_scalers(before)
                note_loans(loans)
            end
            running = false
        end
        return r1, r2
    end
else
    log('warn', 'SMODS.calculate_context not found: Trick will do nothing')
end

-- text of the two modes (they need their own description, so they are installed by hand) -----------
local ENTRIES = {
    j_cbuf_pumpkin_trick = { name = 'Halloween Night: Trick', text = {
        '{s:0.85,C:attention}Trick{s:0.85}: effects that happen',
        '{s:0.85}when a card is {s:0.85,C:attention}discarded',
        '{s:0.85}happen {s:0.85,C:attention}one more time',
        '{s:0.7,C:inactive}Idea: The REAL Nightmare',
    } },
    j_cbuf_pumpkin_treat = { name = 'Halloween Night: Treat', text = {
        '{s:0.85,C:attention}Treat{s:0.85}: Enhancement and Seal',
        '{s:0.85}effects (Chips, Mult, X Mult, X Chips, $)',
        '{s:0.85}are {s:0.85,C:attention}+#1#%{s:0.85} stronger this round',
        '{s:0.7,C:inactive}Idea: TheDragonJaymer08',
    } },
}

local function install_loc()
    pcall(function()
        local loc = G and G.localization
        if not (loc and loc.descriptions) or type(loc_parse_string) ~= 'function' then return end
        loc.descriptions.Joker = loc.descriptions.Joker or {}
        for key, e in pairs(ENTRIES) do
            local cur = loc.descriptions.Joker[key]
            if not (cur and cur.text_parsed and cur.name_parsed) then
                local entry = { name = e.name, text = e.text, name_parsed = { loc_parse_string(e.name) }, text_parsed = {} }
                for _, line in ipairs(e.text) do entry.text_parsed[#entry.text_parsed + 1] = loc_parse_string(line) end
                loc.descriptions.Joker[key] = entry
            end
        end
    end)
end
install_loc()
if type(init_localization) == 'function' and not _G._cbuf_pumpkin_loc then
    _G._cbuf_pumpkin_loc = true
    local ref = init_localization
    function init_localization(...)
        local r = ref(...)
        install_loc()
        return r
    end
end

local function has_entry(key)
    local d = G and G.localization and G.localization.descriptions and G.localization.descriptions.Joker
    local e = d and d[key]
    return e and e.text_parsed and e.name_parsed and true or false
end

-- the Joker -------------------------------------------------------------------------------------------
local MODE_LABEL = { trick = 'Trick', treat = 'Treat' }

SMODS.Joker {
    key = 'pumpkin',
    atlas = 'cbuf_pumpkin',
    pos = { x = 0, y = 0 },
    rarity = 2,
    cost = 6,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = { mode = nil, pct = nil } },
    joker_display_def = jd and jd('j_cbuf_pumpkin', function(JokerDisplay)
        return {
            reminder_text = { { ref_table = 'card.joker_display_values', ref_value = 'state' } },
            calc_function = function(card)
                local ex = card.ability and card.ability.extra or {}
                local label = MODE_LABEL[ex.mode] or 'Empty'
                if ex.mode == 'treat' and ex.pct then label = label .. ' +' .. ex.pct .. '%' end
                card.joker_display_values.state = '(' .. label .. ')'
            end,
        }
    end) or nil,
    loc_txt = {
        name = 'Halloween Night',
        text = {
            '{s:0.85}The pumpkin is {s:0.85,C:attention}empty{}',
            '{s:0.85}At round start it becomes',
            '{s:0.85,C:attention}Treat{s:0.85} ({s:0.85,C:green}#1# in #2#{s:0.85}) or {s:0.85,C:attention}Trick{}',
            '{s:0.7,C:inactive}With an {s:0.7,C:attention}Egg Joker{s:0.7,C:inactive}: always Trick',
            '{s:0.7,C:inactive}Ideas: TheDragonJaymer08,',
            '{s:0.7,C:inactive}The REAL Nightmare',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = card and card.ability and card.ability.extra or {}
        if ex.mode == 'trick' and has_entry('j_cbuf_pumpkin_trick') then
            return { key = 'j_cbuf_pumpkin_trick', vars = {} }
        elseif ex.mode == 'treat' and has_entry('j_cbuf_pumpkin_treat') then
            return { key = 'j_cbuf_pumpkin_treat', vars = { ex.pct or CFG.min_pct } }
        end
        local n, d = odds_vars(card)
        return { vars = { n, d } }
    end,
    -- keeps the art in sync with the mode (also right after loading a save)
    update = function(self, card, dt)
        local ex = card and card.ability and card.ability.extra
        local c = card and card.children and card.children.center
        if not (ex and c and c.set_sprite_pos) or card.cbuf_pump_anim then return end
        local want = (ex.mode == 'treat' and F_TREAT) or (ex.mode == 'trick' and F_TRICK) or F_EMPTY
        if card.cbuf_pump_frame ~= want then set_frame(card, want) end
    end,
    calculate = function(self, card, context)
        if context.blueprint then return end
        local ex = card.ability.extra

        -- a round starts: the empty pumpkin becomes Treat or Trick
        if context.setting_blind and not context.repetition then
            if ex.mode ~= nil then
                if ex.mode == 'treat' then restore_cards() end
                ex.mode, ex.pct = nil, nil
            end
            revert_trick()
            restore_cards()                       -- safety: nothing may still be scaled from the last round
            if has_egg() then
                become_trick(card)                -- an Egg Joker: always a Trick
            elseif chance(card) then
                become_treat(card)
            else
                become_trick(card)
            end
            return
        end

        -- the round is over: the pumpkin is empty again right away (art, text and Trick stop).
        -- Card values stay boosted until the shop opens, so the Treat still pays at cash-out.
        if context.end_of_round and not context.individual and not context.repetition and not context.game_over then
            become_empty(card)
            revert_trick()                        -- Trick's extra changes were only for this round
            return
        end

        -- the shop opens: every card gets its own numbers back
        if context.starting_shop then
            restore_cards()
            return
        end

        -- Treat also makes the Gold Seal's $3 bigger (it is not an Enhancement number)
        if ex.mode == 'treat' and context.individual and context.cardarea == G.play
            and context.other_card and context.other_card.seal == 'Gold' then
            local extra = round(3 * (ex.pct or CFG.min_pct) / 100)
            if extra > 0 then return { dollars = extra } end
        end
    end,
    remove_from_deck = function(self, card, from_debuff)
        if from_debuff then return end
        local ex = card.ability and card.ability.extra
        if ex and ex.mode == 'treat' then pcall(restore_cards) end
        if ex and ex.mode == 'trick' then pcall(revert_trick) end
    end,
}

log('info', 'loaded')
