-- Candy Buff — Golden seals (v1.26.72)
--
-- When an Orange Juice card with a seal wins its "becomes Gold Seal" roll (1 in 24), the seal turns into
-- the GOLDEN copy of itself (the Orange Juice enhancement is used up, like before):
--     Red -> Golden Red     Blue -> Golden Blue     Purple -> Golden Purple     Hot Wax -> Golden Hot Wax
--   * A golden seal keeps ALL the old ability of its seal.
--   * Plus: every time the seal triggers, 1 in 2 chance to earn $2 (follows Oops! All 6s).
--   * Art: a golden ring / coat; only those golden pixels shimmer (the "voucher" shine of a Gold Seal), the
--     rest of the seal stays matte. The golden pixels live in their own atlas (cbuf_golden_masks).
--   * A card with no seal still becomes a Gold Seal, and Gold / Fancy / golden seals are left alone.
--
-- Everything you may want to tweak is in CFG below.
-- Safety: failures go to the Lovely log (search "CandyBuff golden").

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] golden: ' .. msg, 'CandyBuff') end
end

local CFG = {
    pay = 2,        -- dollars earned on a successful roll
    odds = 2,       -- "1 in 2"
}

local NEW_CALC = type(SMODS.calculate_main_scoring) == 'function'
local GOLD_COL = HEX and HEX('F2B632') or (G and G.C and G.C.GOLD)

SMODS.Atlas { key = 'cbuf_golden_seals', path = 'cbuf_golden_seals.png', px = 71, py = 95, disable_mipmap = true }
SMODS.Atlas { key = 'cbuf_golden_masks', path = 'cbuf_golden_masks.png', px = 71, py = 95, disable_mipmap = true }

-- seal key -> golden seal key (read by Orange Juice in candy_core.lua)
_G.CBUF_GOLDEN = { map = {
    Red = 'cbuf_golden_red', Blue = 'cbuf_golden_blue', Purple = 'cbuf_golden_purple',
    cbuf_hot_wax = 'cbuf_golden_wax',
} }

-- the extra $2 ---------------------------------------------------------------------------------
local function gold_roll(card)
    if SMODS and type(SMODS.pseudorandom_probability) == 'function' then
        local ok, r = pcall(SMODS.pseudorandom_probability, card, 'cbuf_golden', 1, CFG.odds, 'cbuf_golden')
        if ok then return r and true or false end
    end
    local normal = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return pseudorandom('cbuf_golden') < math.min(1, normal / CFG.odds)
end

local function odds_vars(card)
    if SMODS and type(SMODS.get_probability_vars) == 'function' then
        local ok, n, d = pcall(SMODS.get_probability_vars, card, 1, CFG.odds, 'cbuf_golden')
        if ok and n and d then return n, d end
    end
    return (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1, CFG.odds
end

-- Call when the seal's own ability just triggered.
local function pay(card)
    if not gold_roll(card) then return end
    G.E_MANAGER:add_event(Event({
        trigger = 'after', delay = 0.2,
        func = function()
            pcall(function()
                ease_dollars(CFG.pay)
                play_sound('coin1')
                card:juice_up(0.3, 0.3)
                card_eval_status_text(card, 'extra', nil, nil, nil, { message = '$' .. CFG.pay, colour = G.C.MONEY or GOLD_COL })
            end)
            return true
        end,
    }))
end

-- Blue / Purple helpers (same as the vanilla seals) --------------------------------------------
local function add_consumable(set_name, key)
    if not (G and G.consumeables and G.GAME) then return false end
    local buffer = G.GAME.consumeable_buffer or 0
    if #G.consumeables.cards + buffer >= (G.consumeables.config.card_limit or 2) then return false end
    G.GAME.consumeable_buffer = buffer + 1
    G.E_MANAGER:add_event(Event({
        trigger = 'before', delay = 0.0,
        func = function()
            local ok, err = pcall(function()
                if key then SMODS.add_card({ key = key })
                else SMODS.add_card({ set = set_name, key_append = 'cbuf_golden' }) end
            end)
            if not ok then log('warn', 'consumable failed: ' .. tostring(err)) end
            G.GAME.consumeable_buffer = 0
            return true
        end,
    }))
    return true
end

local function last_hand_planet()
    local hand = G and G.GAME and G.GAME.last_hand_played
    if not hand or not (G.P_CENTER_POOLS and G.P_CENTER_POOLS.Planet) then return nil end
    for _, v in pairs(G.P_CENTER_POOLS.Planet) do
        if v.config and v.config.hand_type == hand then return v.key end
    end
    return nil
end

-- Drawing: the seal as usual, then the shimmer ONLY on the golden pixels -------------------------
local masks = {}
local function mask_sprite(idx)
    if masks[idx] then return masks[idx] end
    local at = G and G.ASSET_ATLAS and G.ASSET_ATLAS['cbuf_golden_masks']
    if not at then return nil end
    masks[idx] = Sprite(0, 0, G.CARD_W, G.CARD_H, at, { x = idx, y = 0 })
    return masks[idx]
end

local function make_draw(idx)
    return function(self, card, layer)
        local spr = G and G.shared_seals and card and card.seal and G.shared_seals[card.seal]
        if not spr then return end
        pcall(function()
            spr.role.draw_major = card
            spr:draw_shader('dissolve', nil, nil, nil, card.children.center)
            local m = mask_sprite(idx)
            if m then
                m.role.draw_major = card
                m:draw_shader('voucher', nil, card.ARGS.send_to_shader, nil, card.children.center)
            end
        end)
    end
end

local function again()
    return (type(localize) == 'function' and localize('k_again_ex')) or 'Again!'
end

local function loc_odds(self, info_queue, card)
    local n, d = odds_vars(card)
    return { vars = { n, d, CFG.pay } }
end

-- the four seals ---------------------------------------------------------------------------------
SMODS.Seal {
    key = 'golden_red', atlas = 'cbuf_golden_seals', pos = { x = 0, y = 0 },
    badge_colour = HEX('F2B632'),
    loc_txt = { label = 'Golden Red Seal', name = 'Golden Red Seal', text = {
        'Retrigger this card {C:attention}1{} time',
        '{C:green}#1# in #2#{} to earn {C:money}$#3#{} when it triggers' } },
    loc_vars = loc_odds,
    draw = make_draw(0),
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play then
            pay(card)
            return { repetitions = 1, message = again() }
        end
    end,
}

SMODS.Seal {
    key = 'golden_blue', atlas = 'cbuf_golden_seals', pos = { x = 1, y = 0 },
    badge_colour = HEX('F2B632'),
    loc_txt = { label = 'Golden Blue Seal', name = 'Golden Blue Seal', text = {
        'Creates the {C:planet}Planet{} card for your last',
        'played hand if held in hand at end of round',
        '{C:green}#1# in #2#{} to earn {C:money}$#3#{} when it triggers' } },
    loc_vars = loc_odds,
    draw = make_draw(1),
    calculate = function(self, card, context)
        if context.end_of_round and context.individual and context.cardarea == G.hand then
            if add_consumable('Planet', last_hand_planet()) then pay(card) end
        end
    end,
}

SMODS.Seal {
    key = 'golden_purple', atlas = 'cbuf_golden_seals', pos = { x = 2, y = 0 },
    badge_colour = HEX('F2B632'),
    loc_txt = { label = 'Golden Purple Seal', name = 'Golden Purple Seal', text = {
        'Creates a {C:tarot}Tarot{} card when discarded',
        '{C:green}#1# in #2#{} to earn {C:money}$#3#{} when it triggers' } },
    loc_vars = loc_odds,
    draw = make_draw(2),
    calculate = function(self, card, context)
        if context.discard and context.other_card == card then
            if add_consumable('Tarot', nil) then pay(card) end
        end
    end,
}

-- Golden Hot Wax: runs the real Hot Wax code (so any change to it carries over), plus the $2.
SMODS.Seal {
    key = 'golden_wax', atlas = 'cbuf_golden_seals', pos = { x = 3, y = 0 },
    badge_colour = HEX('F2B632'),
    loc_txt = { label = 'Golden Hot Wax', name = 'Golden Hot Wax', text = {
        '{s:0.85,X:mult,C:white}X#4#{s:0.85} Mult, grows each score',
        '{s:0.85}The wax may fall off',
        '{s:0.85,C:green}#1# in #2#{s:0.85} to earn {s:0.85,C:money}$#3#{s:0.85} when it triggers' } },
    loc_vars = function(self, info_queue, card)
        local n, d = odds_vars(card)
        local st = card and card.ability and card.ability.cbuf_wax
        return { vars = { n, d, CFG.pay, st and st.x or 1 } }
    end,
    draw = make_draw(3),
    calculate = function(self, card, context)
        local base = SMODS.Seals and SMODS.Seals['cbuf_hot_wax']
        if not (base and type(base.calculate) == 'function') then return end
        local ret = base.calculate(base, card, context)
        if ret then pay(card) end
        return ret
    end,
}

log('info', 'loaded')
