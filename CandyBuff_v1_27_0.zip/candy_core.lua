-- Candy Buff — Candy Sleeve / Candy Deck for Balatro (v1.18.0)
-- Requires Steamodded only. CardSleeves is optional: with it you get the Candy Sleeve,
-- and the standalone Candy Deck (works on the experimental Steamodded builds) is always added.

local MOD = SMODS.current_mod
local MOD_CONFIG = MOD.config or {}
MOD.config = MOD_CONFIG

-- Talisman / Amulet (needed by Cryptid) can turn money into a big-number table.
local function to_num(x)
    if type(to_number) == 'function' then
        local ok, v = pcall(to_number, x)
        if ok and type(v) == 'number' then return v end
    end
    return tonumber(x) or 0
end

local function clamp_int(value, lo, hi, default)
    value = math.floor(tonumber(value) or default)
    if value < lo then value = lo end
    if value > hi then value = hi end
    return value
end

-- v1.5.0: the default Food Joker spawn rate is now x2 (range x2-x10). Old saved
-- configs (which defaulted to x10) are reset to the new default once.
if (tonumber(MOD_CONFIG.cfg_ver) or 0) < 2 then
    MOD_CONFIG.spawn_multiplier = 2
end
-- v1.10.2: the devour chance is back to 50% by default (it only becomes 100% for a
-- hunger roll when there is no un-Spoiled Joker left to spoil instead).
if (tonumber(MOD_CONFIG.cfg_ver) or 0) < 4 then
    MOD_CONFIG.devour_chance = 50
end
MOD_CONFIG.cfg_ver = 4
MOD_CONFIG.spawn_multiplier = clamp_int(MOD_CONFIG.spawn_multiplier, 2, 10, 2)
-- Decay protection (%) for Food Jokers. 0-100, default 20.
MOD_CONFIG.decay_percent = clamp_int(MOD_CONFIG.decay_percent, 0, 100, 20)
-- Blinds The Licker may go without eating before it spoils a Joker.
MOD_CONFIG.licker_hunger = clamp_int(MOD_CONFIG.licker_hunger, 1, 6, 3)
if MOD_CONFIG.licker_start == nil then MOD_CONFIG.licker_start = true end
-- Chance (%) that a starving Licker devours an already Spoiled Joker. 0-100.
MOD_CONFIG.devour_chance = clamp_int(MOD_CONFIG.devour_chance, 0, 100, 50)

local function get_spawn_multiplier()
    return clamp_int(MOD_CONFIG.spawn_multiplier, 2, 10, 2)
end
local function get_decay_percent()
    return clamp_int(MOD_CONFIG.decay_percent, 0, 100, 20)
end
local function get_devour_chance()
    return clamp_int(MOD_CONFIG.devour_chance, 0, 100, 50)
end
local function get_licker_hunger()
    return clamp_int(MOD_CONFIG.licker_hunger, 1, 6, 3)
end

local SLEEVE_KEY = 'sleeve_cbuf_candy'

local function save_config()
    if type(SMODS.save_mod_config) == 'function' then
        SMODS.save_mod_config(MOD)
    end
end

-- Config page callbacks (cycles pick integers so Android UI stays simple).
G.FUNCS = G.FUNCS or {}
G.FUNCS.cbuf_set_spawn_multiplier = function(args)
    local option = args and args.cycle_config and tonumber(args.cycle_config.current_option)
    if not option then return end
    MOD_CONFIG.spawn_multiplier = clamp_int(option + 1, 2, 10, 2)
    save_config()
end
G.FUNCS.cbuf_set_decay_percent = function(args)
    local option = args and args.cycle_config and tonumber(args.cycle_config.current_option)
    if not option then return end
    MOD_CONFIG.decay_percent = clamp_int((option - 1) * 5, 0, 100, 20)
    save_config()
end
G.FUNCS.cbuf_set_devour_chance = function(args)
    local option = args and args.cycle_config and tonumber(args.cycle_config.current_option)
    if not option then return end
    MOD_CONFIG.devour_chance = clamp_int((option - 1) * 10, 0, 100, 50)
    save_config()
end
G.FUNCS.cbuf_set_licker_hunger = function(args)
    local option = args and args.cycle_config and tonumber(args.cycle_config.current_option)
    if not option then return end
    MOD_CONFIG.licker_hunger = clamp_int(option, 1, 6, 3)
    save_config()
end

local function make_cycle(label, options, current, callback)
    return {
        n = G.UIT.R,
        config = { align = 'cm', padding = 0.07 },
        nodes = {
            create_option_cycle({
                label = label,
                options = options,
                current_option = current,
                opt_callback = callback,
                colour = G.C.RED,
                w = 3.6,
                scale = 0.6,
                text_scale = 0.42,
                cycle_shoulders = true,
                no_pips = true,
            }),
        },
    }
end

-- A titled panel (one column of the settings page).
local function settings_panel(title, hint, rows)
    local nodes = {
        { n = G.UIT.R, config = { align = 'cm', padding = 0.06 }, nodes = {
            { n = G.UIT.T, config = { text = title, scale = 0.45, colour = G.C.ORANGE or G.C.FILTER, shadow = true } },
        } },
        { n = G.UIT.R, config = { align = 'cm', padding = 0.02 }, nodes = {
            { n = G.UIT.T, config = { text = hint, scale = 0.28, colour = G.C.UI.TEXT_INACTIVE or G.C.WHITE } },
        } },
    }
    for _, row in ipairs(rows) do nodes[#nodes + 1] = row end
    return {
        n = G.UIT.C,
        config = {
            align = 'tm', padding = 0.14, r = 0.12, minw = 4.4, minh = 3.6,
            colour = G.C.L_BLACK or G.C.BLACK, emboss = 0.05,
        },
        nodes = nodes,
    }
end

-- Discord button (icon from the supplied UI icon sheet, 32x32).
local DISCORD_URL = 'https://discord.gg/ush3YvnW9'
SMODS.Atlas { key = 'cbuf_discord', path = 'cbuf_discord.png', px = 32, py = 32, disable_mipmap = true }

G.FUNCS.cbuf_open_discord = function()
    local ok = false
    if love and love.system and love.system.openURL then ok = pcall(love.system.openURL, DISCORD_URL) end
    if not ok and G.E_MANAGER and attention_text then
        attention_text({ text = DISCORD_URL, scale = 0.5, hold = 4, align = 'cm', offset = { x = 0, y = 0 }, major = G.ROOM_ATTACH })
    end
end

local function discord_row()
    local atlas = G.ASSET_ATLAS and G.ASSET_ATLAS['cbuf_discord']
    if not atlas then return nil end
    local sp = Sprite(0, 0, 0.8, 0.8, atlas, { x = 0, y = 0 })
    return { n = G.UIT.R, config = { align = 'cm', padding = 0.06 }, nodes = {
        { n = G.UIT.C, config = { align = 'cm', padding = 0.05, r = 0.1, hover = true, shadow = true,
            button = 'cbuf_open_discord', colour = G.C.CLEAR }, nodes = {
            { n = G.UIT.O, config = { object = sp } },
        } },
        { n = G.UIT.C, config = { align = 'cl', padding = 0.12 }, nodes = {
            { n = G.UIT.R, config = { align = 'cl' }, nodes = {
                { n = G.UIT.T, config = { text = 'Join our Discord', scale = 0.4, colour = G.C.UI.TEXT_LIGHT, shadow = true } } } },
            { n = G.UIT.R, config = { align = 'cl' }, nodes = {
                { n = G.UIT.T, config = { text = 'Suggestions, bug reports and news', scale = 0.28, colour = G.C.UI.TEXT_INACTIVE or G.C.WHITE } } } },
        } },
    } }
end

MOD.config_tab = function()
    local spawn_opts, decay_opts, hunger_opts, devour_opts = {}, {}, {}, {}
    for m = 2, 10 do spawn_opts[#spawn_opts + 1] = 'x' .. m end
    for p = 0, 100, 5 do decay_opts[#decay_opts + 1] = p .. '%' end
    for p = 0, 100, 10 do devour_opts[#devour_opts + 1] = p .. '%' end
    for b = 1, 6 do hunger_opts[#hunger_opts + 1] = tostring(b) end

    local food_panel = settings_panel('Food Jokers', 'Candy Deck / Candy Sleeve', {
        make_cycle('Spawn rate', spawn_opts, get_spawn_multiplier() - 1, 'cbuf_set_spawn_multiplier'),
        make_cycle('Decay reduction', decay_opts, math.floor(get_decay_percent() / 5 + 0.5) + 1, 'cbuf_set_decay_percent'),
    })
    local licker_panel = settings_panel('The Licker', 'Hunger and appetite', {
        make_cycle('Hunger (blinds)', hunger_opts, get_licker_hunger(), 'cbuf_set_licker_hunger'),
        make_cycle('Devour chance', devour_opts, math.floor(get_devour_chance() / 10 + 0.5) + 1, 'cbuf_set_devour_chance'),
        { n = G.UIT.R, config = { align = 'cm', padding = 0.08 }, nodes = {
            create_toggle({
                label = 'Start with Rental Licker',
                label_scale = 0.38,
                scale = 0.8,
                ref_table = MOD_CONFIG,
                ref_value = 'licker_start',
                callback = function() save_config() end,
            }),
        } },
    })

    return {
        n = G.UIT.ROOT,
        config = { align = 'cm', colour = G.C.CLEAR, padding = 0.12, minw = 9.4, minh = 4.6 },
        nodes = {
            { n = G.UIT.R, config = { align = 'cm', padding = 0.1 }, nodes = {
                { n = G.UIT.T, config = { text = 'Candy Buff', scale = 0.6, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
            } },
            { n = G.UIT.R, config = { align = 'cm', padding = 0.05 }, nodes = {
                food_panel,
                { n = G.UIT.B, config = { w = 0.25, h = 0.1 } },
                licker_panel,
            } },
            discord_row(),
        },
    }
end

-- Vanilla Food Jokers. Food detection also checks explicit mod metadata and
-- common food words in a modded Joker's key/name (best-effort; mods do not share
-- a universal Food-Joker flag).
local FOOD_JOKERS = {
    j_egg = true,
    j_gros_michel = true,
    j_ice_cream = true,
    j_cavendish = true,
    j_turtle_bean = true,
    j_popcorn = true,
    j_ramen = true,
    j_seltzer = true,
    j_diet_cola = true,
}

local RANDOM_EXPIRY_FOOD = {
    j_gros_michel = true,
    j_cavendish = true,
}

local FOOD_WORDS = {
    'food', 'banana', 'egg', 'ice cream', 'icecream', 'gros michel', 'cavendish',
    'turtle bean', 'popcorn', 'ramen', 'seltzer', 'cola', 'soda', 'candy', 'sweet',
    'cookie', 'cake', 'pie', 'pizza', 'burger', 'hamburger', 'hotdog', 'hot dog',
    'sandwich', 'bread', 'cheese', 'milk', 'yogurt', 'yoghurt', 'donut', 'doughnut',
    'chocolate', 'fruit', 'apple', 'orange', 'grape', 'berry', 'strawberry', 'blueberry',
    'watermelon', 'melon', 'lemon', 'lime', 'coffee', 'tea', 'sushi', 'taco', 'potato',
    'fries', 'chicken', 'steak', 'fish', 'shrimp', 'honey', 'waffle', 'pancake', 'cereal',
    'muffin', 'cupcake', 'caramel', 'biscuit', 'pretzel', 'croissant', 'chili', 'pepper',
    'pickle', 'olive', 'jam', 'jelly', 'mango', 'pineapple', 'kiwi', 'pear', 'peach',
    'apricot', 'plum', 'cherry', 'soup', 'noodle', 'pasta', 'rice', 'sugar', 'syrup',
}

SMODS.Atlas {
    key = 'cbuf_candy',
    path = 'candy_sleeve.png',
    px = 71,
    py = 74,
    disable_mipmap = true,
}

local DECK_KEY = 'b_cbuf_candy_deck'

-- True when the run uses the Candy Sleeve (CardSleeves) OR the Candy Deck.
local function active_candy_sleeve()
    if not (G and G.GAME) then return false end
    local selected = G.GAME.selected_sleeve
    if selected == SLEEVE_KEY or selected == 'cbuf_candy' or selected == 'candy' then return true end
    local back = G.GAME.selected_back
    local center = back and back.effect and back.effect.center
    if center and center.key == DECK_KEY then return true end
    -- fallback: the deck name stored by Steamodded in the run
    return G.GAME.selected_back_key and G.GAME.selected_back_key.key == DECK_KEY or false
end

local function joker_key(card)
    if not (card and card.config and card.config.center) then return nil end
    return card.config.center.key
end

local function normalized_words(value)
    if type(value) ~= 'string' then return ' ' end
    value = value:lower():gsub('[^%a%d]+', ' ')
    return ' ' .. value .. ' '
end

local function contains_food_word(value)
    local words = normalized_words(value)
    for _, word in ipairs(FOOD_WORDS) do
        if words:find(' ' .. word .. ' ', 1, true) then return true end
    end
    return false
end

local function center_is_food(center, fallback_key)
    if type(center) ~= 'table' then
        return FOOD_JOKERS[fallback_key] == true or contains_food_word(fallback_key)
    end
    if center._cbuf_food_detected ~= nil then return center._cbuf_food_detected end

    local key = center.key or fallback_key
    local detected = false
    if FOOD_JOKERS[key] then
        detected = true
    elseif center.cbuf_food == true or center.food_joker == true or center.food == true then
        detected = true
    elseif type(center.pools) == 'table' then
        for pool, enabled in pairs(center.pools) do
            if enabled and (normalized_words(pool) == ' food ' or normalized_words(pool) == ' food joker ') then
                detected = true
                break
            end
        end
    end

    if not detected then
        detected = contains_food_word(key) or contains_food_word(center.name)
    end
    if not detected and type(center.loc_txt) == 'table' then
        detected = contains_food_word(center.loc_txt.name)
    end
    center._cbuf_food_detected = detected
    return detected
end

local function is_food_key(key)
    if type(key) ~= 'string' then return false end
    if FOOD_JOKERS[key] then return true end
    local center = G and G.P_CENTERS and G.P_CENTERS[key]
    return center_is_food(center, key)
end

local function is_food_joker(card)
    if not (card and card.config and card.config.center) then return false end
    return center_is_food(card.config.center, joker_key(card))
end

-- Shared with the optional Sagatro file (sagatro.lua).
_G.CBUF_API = _G.CBUF_API or {}
_G.CBUF_API.is_food_joker = is_food_joker

local function round2(x) return math.floor(x * 100 + 0.5) / 100 end

local function count_food_jokers()
    local count = 0
    if G and G.jokers and G.jokers.cards then
        for _, card in ipairs(G.jokers.cards) do
            if is_food_joker(card) then count = count + 1 end
        end
    end
    return count
end

-- Current decay protection: the configured flat percentage (0-100%).
local function get_decay_reduction()
    return get_decay_percent() / 100
end

-- Numeric-only snapshot of ability.extra (plus mult / x_mult, which Popcorn and
-- Ramen decay through). Do not rewrite unrelated ability fields.
local function numeric_snapshot(value)
    if type(value) == 'number' then return value end
    if type(value) ~= 'table' then return nil end
    local result = {}
    for k, v in pairs(value) do
        if type(v) == 'number' then
            result[k] = v
        elseif type(v) == 'table' then
            local nested = numeric_snapshot(v)
            if nested ~= nil then result[k] = nested end
        end
    end
    return result
end

local function card_snapshot(card)
    local ab = card.ability or {}
    return {
        extra = numeric_snapshot(ab.extra),
        mult = type(ab.mult) == 'number' and ab.mult or nil,
        x_mult = type(ab.x_mult) == 'number' and ab.x_mult or nil,
    }
end

local function soften_table(current, previous, reduction)
    local changed, rescued = false, false
    for k, v in pairs(current) do
        local old = previous[k]
        if type(v) == 'number' and type(old) == 'number' and v < old then
            local adjusted = round2(old - (old - v) * (1 - reduction))
            current[k] = adjusted
            changed = true
            if old > 0 and v <= 0 and adjusted > 0 then rescued = true end
        elseif type(v) == 'table' and type(old) == 'table' then
            local c, r = soften_table(v, old, reduction)
            changed = changed or c
            rescued = rescued or r
        end
    end
    return changed, rescued
end

-- Soften any decrease since the last snapshot. Returns changed, rescued.
local function soften_card(card, last, reduction)
    local ab = card.ability
    local changed, rescued = false, false
    if not (ab and last and reduction > 0) then return false, false end

    local extra = ab.extra
    if type(extra) == 'number' and type(last.extra) == 'number' and extra < last.extra then
        local adjusted = round2(last.extra - (last.extra - extra) * (1 - reduction))
        ab.extra = adjusted
        changed = true
        if last.extra > 0 and extra <= 0 and adjusted > 0 then rescued = true end
    elseif type(extra) == 'table' and type(last.extra) == 'table' then
        local c, r = soften_table(extra, last.extra, reduction)
        changed, rescued = c, r
    end

    for _, field in ipairs({ 'mult', 'x_mult' }) do
        local cur, old = ab[field], last[field]
        if type(cur) == 'number' and type(old) == 'number' and cur < old then
            ab[field] = round2(old - (old - cur) * (1 - reduction))
            changed = true
        end
    end
    return changed, rescued
end

local function show_message(card, text, colour)
    if card_eval_status_text and G and G.C then
        card_eval_status_text(card, 'extra', nil, nil, nil, {
            message = text,
            colour = colour or G.C.CHIPS or G.C.GREEN,
        })
    end
end

local function show_protection_message(card)
    show_message(card, 'Candy Guard!', G.C.CHIPS or G.C.GREEN)
end

-- ===================================================================
-- JokerDisplay support helpers.
-- Every Joker of this mod keeps its JokerDisplay definition function in JD_DEFS.
-- The Jokers also carry it as `joker_display_def` (the normal way), and at the end
-- of this file a fallback registers any definition JokerDisplay did not pick up.
-- ===================================================================
local JD_DEFS = {}
local function jd(key, fn)
    JD_DEFS[key] = fn
    return fn
end
_G.CBUF_API = _G.CBUF_API or {}
_G.CBUF_API.jd = jd      -- used by sagatro.lua

-- The Jokers a JokerDisplay retrigger_function should look at: the one it passes in
-- (newer JokerDisplay) or, failing that, every working copy of that Joker we own.
local function jd_jokers(key, joker_card)
    if type(joker_card) == 'table' and joker_card.ability then return { joker_card } end
    local list = {}
    if G and G.jokers and G.jokers.cards then
        for _, c in ipairs(G.jokers.cards) do
            if joker_key(c) == key and not c.debuff then list[#list + 1] = c end
        end
    end
    return list
end

local function jd_odds_text(odds)
    local num = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    if SMODS and type(SMODS.get_probability_vars) == 'function' then
        local ok, n, d = pcall(SMODS.get_probability_vars, nil, 1, odds, 'cbuf_jd')
        if ok and n and d then return math.floor(to_num(n)) .. ' in ' .. math.floor(to_num(d)) end
    end
    return math.floor(num) .. ' in ' .. odds
end

local function sweet_tooth_active()
    return G and G.GAME and G.GAME.used_vouchers and G.GAME.used_vouchers['v_cbuf_sweet_tooth'] and true or false
end

local function effective_spawn_multiplier()
    local m = 1
    if active_candy_sleeve() then m = get_spawn_multiplier() end
    if sweet_tooth_active() then m = m * 2 end
    return m
end

-- Triple eligible Food Jokers' relative weight in the ordinary Joker pool.
-- Only eligible entries already present in the pool are duplicated, so unlocks,
-- rarity and other original eligibility rules continue to apply.
if type(get_current_pool) == 'function' and not _G.CBUF_GET_CURRENT_POOL_WRAPPED then
    local original_get_current_pool = get_current_pool
    get_current_pool = function(_type, ...)
        local pool, pool_key = original_get_current_pool(_type, ...)
        if effective_spawn_multiplier() <= 1 or _type ~= 'Joker' or type(pool) ~= 'table' then
            return pool, pool_key
        end

        local extra_entries = {}
        for _, entry in ipairs(pool) do
            local key
            if type(entry) == 'string' then
                key = entry
            elseif type(entry) == 'table' then
                key = entry.key or (entry.config and entry.config.center and entry.config.center.key)
            end
            if is_food_key(key) then
                for _ = 1, effective_spawn_multiplier() - 1 do
                    extra_entries[#extra_entries + 1] = entry
                end
            end
        end
        for _, entry in ipairs(extra_entries) do pool[#pool + 1] = entry end
        return pool, pool_key
    end
    _G.CBUF_GET_CURRENT_POOL_WRAPPED = true
end

-- Fried Eggs: once unlocked (an Egg worth $12+ was sold) it is added to the Joker pool
-- several extra times, so it shows up more often than a single Common Joker.
-- Only works when the pool already contains it, so the unlock rule still applies.
-- Config: fried_eggs_boost = extra copies (0 = off, default 4).
if type(get_current_pool) == 'function' and not _G.CBUF_FRIED_POOL_WRAPPED then
    local previous_get_current_pool = get_current_pool
    get_current_pool = function(_type, ...)
        local pool, pool_key = previous_get_current_pool(_type, ...)
        local copies = math.floor(tonumber(MOD_CONFIG.fried_eggs_boost) or 4)
        if _type ~= 'Joker' or type(pool) ~= 'table' or copies <= 0 then
            return pool, pool_key
        end
        local found
        for _, entry in ipairs(pool) do
            local key = type(entry) == 'string' and entry
                or (type(entry) == 'table' and (entry.key or (entry.config and entry.config.center and entry.config.center.key)))
            if key == 'j_cbuf_fried_eggs' then found = entry break end
        end
        if found then
            for _ = 1, math.min(copies, 20) do pool[#pool + 1] = found end
        end
        return pool, pool_key
    end
    _G.CBUF_FRIED_POOL_WRAPPED = true
end

-- The Licker's tongue sprite lives outside card.children, so remove it together with the card.
if Card and type(Card.remove) == 'function' and not Card._cbuf_tongue_remove_wrapped then
    local remove_ref = Card.remove
    function Card:remove(...)
        local tongue = self.cbuf_tongue
        if tongue then
            self.cbuf_tongue = nil
            pcall(function() tongue:remove() end)
        end
        return remove_ref(self, ...)
    end
    Card._cbuf_tongue_remove_wrapped = true
end

-- Catch vanilla/modded Food Joker expiry after its end-of-round calculation.
-- Do not run this protection for a general/manual dissolve.
if Card and type(Card.calculate_joker) == 'function' and not Card._cbuf_calculate_wrapped then
    local original_calculate_joker = Card.calculate_joker
    function Card:calculate_joker(context)
        local previous_context = self._cbuf_calculation_context
        self._cbuf_calculation_context = context
        if active_candy_sleeve() and RANDOM_EXPIRY_FOOD[joker_key(self)]
            and context and context.end_of_round and not context.blueprint then
            self._cbuf_expiry_guard_until = ((G and G.TIMERS and G.TIMERS.REAL) or 0) + 0.75
        end
        local result = original_calculate_joker(self, context)
        self._cbuf_calculation_context = previous_context
        return result
    end
    Card._cbuf_calculate_wrapped = true
end

-- Reduce numeric losses of owned Food Jokers (ability.extra, mult, x_mult) by
-- the configured decay reduction (default 20%, up to 100%).
if Card and type(Card.update) == 'function' and not Card._cbuf_update_wrapped then
    local original_update = Card.update
    function Card:update(dt)
        original_update(self, dt)
        if not (active_candy_sleeve() and is_food_joker(self) and G and G.jokers
            and self.area == G.jokers and self.ability) then
            self._cbuf_last_extra = nil
            return
        end

        -- every 3rd frame is enough to notice a decay and avoids a new table per frame per Food Joker
        self._cbuf_tick = ((self._cbuf_tick or 0) + 1) % 3
        if self._cbuf_tick ~= 0 and self._cbuf_last_extra ~= nil then return end

        local reduction = get_decay_reduction()
        if self._cbuf_last_extra ~= nil and reduction > 0 then
            local _, rescued = soften_card(self, self._cbuf_last_extra, reduction)
            if rescued then
                self._cbuf_decay_rescue_until = ((G and G.TIMERS and G.TIMERS.REAL) or 0) + 0.35
            end
        end
        self._cbuf_last_extra = card_snapshot(self)
    end
    Card._cbuf_update_wrapped = true
end

-- Chance (= current decay protection) to survive the natural Gros Michel /
-- Cavendish expiry roll. Also lets a depleted decay counter be rescued; manual
-- selling or arbitrary destruction is never intercepted.
if Card and type(Card.start_dissolve) == 'function' and not Card._cbuf_dissolve_wrapped then
    local original_start_dissolve = Card.start_dissolve
    function Card:start_dissolve(...)
        if active_candy_sleeve() and is_food_joker(self) and G and G.jokers
            and not self._cbuf_force_dissolve
            and self.area == G.jokers and self.ability then
            local key = joker_key(self)
            local context = self._cbuf_calculation_context
            local now = (G.TIMERS and G.TIMERS.REAL) or 0
            local natural_expiry_context = context and context.end_of_round and not context.blueprint
            local deferred_expiry = self._cbuf_expiry_guard_until and now <= self._cbuf_expiry_guard_until
            local reduction = get_decay_reduction()

            if RANDOM_EXPIRY_FOOD[key] and (natural_expiry_context or deferred_expiry) then
                self._cbuf_expiry_guard_until = nil
                if reduction > 0 and pseudorandom('cbuf_food_guard_' .. key) < reduction then
                    show_protection_message(self)
                    return
                end
            elseif self._cbuf_expiry_guard_until and now > self._cbuf_expiry_guard_until then
                self._cbuf_expiry_guard_until = nil
            end

            if self._cbuf_last_extra ~= nil and reduction > 0 then
                local changed, rescued = soften_card(self, self._cbuf_last_extra, reduction)
                if changed then self._cbuf_last_extra = card_snapshot(self) end
                if rescued then
                    self._cbuf_decay_rescue_until = now + 0.35
                    show_protection_message(self)
                    return
                end
            end
            if self._cbuf_decay_rescue_until and now <= self._cbuf_decay_rescue_until then
                self._cbuf_decay_rescue_until = nil
                show_protection_message(self)
                return
            elseif self._cbuf_decay_rescue_until then
                self._cbuf_decay_rescue_until = nil
            end
        end
        return original_start_dissolve(self, ...)
    end
    Card._cbuf_dissolve_wrapped = true
end

-- ===================================================================
-- The Licker — starting Negative Joker of the Candy Sleeve.
-- Each blind it licks (halves the value of) one Food Joker and gains a random
-- bonus. No Food Joker to lick: it eats half your $ or your interest cap.
-- If it eats nothing for N blinds, it spoils a random Joker (Perishable).
-- ===================================================================
SMODS.Atlas {
    key = 'cbuf_licker',
    path = 'the_licker.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

local LICKER_KEY = 'j_cbuf_licker'
local LICK_REWARDS = { 'mult', 'chips', 'xmult', 'xchips', 'retrigger', 'money', 'xmoney' }
local XMONEY_CAP = 20

-- Halve the value of a Food Joker. Returns true if something was eaten.
local LICK_HANDLERS = {
    j_ice_cream = function(ab)
        if type(ab.extra) == 'table' and type(ab.extra.chips) == 'number' and ab.extra.chips > 1 then
            ab.extra.chips = math.max(1, math.floor(ab.extra.chips / 2))
            return true
        end
    end,
    j_popcorn = function(ab)
        if type(ab.mult) == 'number' and ab.mult > 1 then
            ab.mult = math.max(1, math.floor(ab.mult / 2))
            return true
        end
    end,
    j_ramen = function(ab)
        if type(ab.x_mult) == 'number' and ab.x_mult > 1.03 then
            ab.x_mult = round2(math.max(1.02, 1 + (ab.x_mult - 1) / 2))
            return true
        end
    end,
    j_seltzer = function(ab)
        if type(ab.extra) == 'number' and ab.extra > 1 then
            ab.extra = math.max(1, math.ceil(ab.extra / 2))
            return true
        end
    end,
    j_turtle_bean = function(ab)
        if type(ab.extra) == 'table' and type(ab.extra.h_size) == 'number' and ab.extra.h_size > 1 then
            local old = ab.extra.h_size
            ab.extra.h_size = math.max(1, math.floor(old / 2))
            if G and G.hand and G.hand.change_size then
                G.hand:change_size(ab.extra.h_size - old)
            end
            return true
        end
    end,
    j_gros_michel = function(ab)
        if type(ab.extra) == 'table' and type(ab.extra.mult) == 'number' and ab.extra.mult > 1 then
            ab.extra.mult = math.max(1, math.floor(ab.extra.mult / 2))
            return true
        end
    end,
    j_cavendish = function(ab)
        if type(ab.extra) == 'table' and type(ab.extra.Xmult) == 'number' and ab.extra.Xmult > 1.05 then
            ab.extra.Xmult = round2(1 + (ab.extra.Xmult - 1) / 2)
            return true
        end
    end,
    j_egg = function(ab, card)
        if type(ab.extra_value) == 'number' and ab.extra_value >= 1 then
            ab.extra_value = math.floor(ab.extra_value / 2)
            if card.set_cost then card:set_cost() end
            return true
        end
    end,
    j_cbuf_fried_eggs = function(ab, card)
        if type(ab.extra_value) == 'number' and ab.extra_value >= 1 then
            ab.extra_value = math.floor(ab.extra_value / 2)
            if card.set_cost then card:set_cost() end
            return true
        end
    end,
}

-- Swallow a whole Joker (Egg at $0, a drunk Cola).
local function swallow_joker(card, text)
    show_message(card, text, G.C.RED)
    card._cbuf_force_dissolve = true
    card:start_dissolve()
end

-- Egg / Fried Eggs: each lick halves the TOTAL sell value (rounded down);
-- when it reaches $0 the Licker eats the whole Joker.
local function lick_egg(ab, card)
    if ab.eternal then return false end
    local extra = type(ab.extra_value) == 'number' and ab.extra_value or 0
    local sell = tonumber(card.sell_cost) or 1
    local base = sell - extra
    local new_sell = math.floor(sell / 2)
    ab.extra_value = new_sell - base
    if card.set_cost then card:set_cost() end
    if new_sell <= 0 then
        swallow_joker(card, 'Eaten!')
    end
    return true
end
LICK_HANDLERS.j_egg = lick_egg
LICK_HANDLERS.j_cbuf_fried_eggs = lick_egg

-- Diet Cola: the Licker drinks it. Its hunger limit gets +1 blind, once,
-- until that extra hungry blind has run out (then it goes back to normal).
LICK_HANDLERS.j_diet_cola = function(ab, card, licker)
    if ab.eternal or not (licker and licker.ability and licker.ability.extra) then return false end
    local lex = licker.ability.extra
    if (lex.hunger_bonus or 0) >= 1 then return false end
    lex.hunger_bonus = 1
    swallow_joker(card, 'Drunk!')
    show_message(licker, '+1 calm blind', G.C.BLUE or G.C.CHIPS)
    return true
end

local function lick_food(target, licker)
    local ab = target.ability
    if not ab then return false end
    local handler = LICK_HANDLERS[joker_key(target)]
    local ate = false
    if handler then
        ate = handler(ab, target, licker) == true
    elseif type(ab.x_mult) == 'number' and ab.x_mult > 1.05 then
        ab.x_mult = round2(1 + (ab.x_mult - 1) / 2)
        ate = true
    elseif type(ab.mult) == 'number' and ab.mult > 1 then
        ab.mult = math.max(1, math.floor(ab.mult / 2))
        ate = true
    end
    if ate then target._cbuf_last_extra = card_snapshot(target) end
    return ate
end

local function lickable_food(licker)
    local list = {}
    if G and G.jokers and G.jokers.cards then
        for _, c in ipairs(G.jokers.cards) do
            if c ~= licker and is_food_joker(c) then
                -- Probe on a dry run: only count Jokers that still have value to lick.
                local ab = c.ability
                local key = joker_key(c)
                local ok = false
                if key == 'j_ice_cream' then ok = type(ab.extra) == 'table' and (ab.extra.chips or 0) > 1
                elseif key == 'j_popcorn' then ok = (ab.mult or 0) > 1
                elseif key == 'j_ramen' then ok = (ab.x_mult or 1) > 1.03
                elseif key == 'j_seltzer' then ok = type(ab.extra) == 'number' and ab.extra > 1
                elseif key == 'j_turtle_bean' then ok = type(ab.extra) == 'table' and (ab.extra.h_size or 0) > 1
                elseif key == 'j_gros_michel' then ok = type(ab.extra) == 'table' and (ab.extra.mult or 0) > 1
                elseif key == 'j_cavendish' then ok = type(ab.extra) == 'table' and (ab.extra.Xmult or 1) > 1.05
                elseif key == 'j_egg' or key == 'j_cbuf_fried_eggs' then ok = not ab.eternal
                elseif key == 'j_diet_cola' then
                    ok = not ab.eternal and ((licker.ability.extra.hunger_bonus or 0) < 1)
                elseif LICK_HANDLERS[key] == nil then
                    ok = (type(ab.x_mult) == 'number' and ab.x_mult > 1.05)
                        or (type(ab.mult) == 'number' and ab.mult > 1)
                end
                if ok then list[#list + 1] = c end
            end
        end
    end
    return list
end

-- Custom sticker: "Spoiled". After SPOIL_ROUNDS rounds the Joker is debuffed.
local SPOIL_ROUNDS = 3
local SPOIL_KEY = 'cbuf_spoiled'

SMODS.Atlas {
    key = 'cbuf_spoiled',
    path = 'cbuf_spoiled.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

SMODS.Sticker {
    key = 'spoiled',
    atlas = 'cbuf_spoiled',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('7A9A2A'),
    rate = 0,
    needs_enable_flag = false,
    default_compat = true,
    sets = { Joker = true },
    loc_txt = {
        name = 'Spoiled',
        label = 'Spoiled',
        text = {
            '{C:red}Debuffed{} in {C:attention}#1#{} rounds',
        },
    },
    loc_vars = function(self, info_queue, card)
        local left = card and card.ability and card.ability.cbuf_spoiled_tally or SPOIL_ROUNDS
        return { vars = { left } }
    end,
}

-- Custom sticker: "Glass". The Joker shatters at the end of the next round.
local GLASS_KEY = 'cbuf_glass'

SMODS.Atlas {
    key = 'cbuf_glass',
    path = 'cbuf_glass.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

SMODS.Sticker {
    key = 'glass',
    atlas = 'cbuf_glass',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('7FB8D0'),
    rate = 0,
    needs_enable_flag = false,
    default_compat = true,
    sets = { Joker = true },
    loc_txt = {
        name = 'Glass',
        label = 'Glass',
        text = {
            '{C:red}Shatters{} next round',
            '{C:inactive}Cannot be sold{}',
        },
    },
}

-- Glass Jokers cannot be sold.
if Card and type(Card.can_sell_card) == 'function' and not Card._cbuf_sell_wrapped then
    local original_can_sell = Card.can_sell_card
    function Card:can_sell_card(...)
        if self.ability and self.ability.cbuf_glass then return false end
        if self.config and self.config.center and self.config.center.key == 'j_cbuf_mika_7s' then return false end
        -- Pile of Rocks cannot be sold until 5 consumables / older Jokers were sold.
        if self.config and self.config.center and self.config.center.key == 'j_cbuf_pile_of_rocks' then
            local ex = self.ability and self.ability.extra
            if type(ex) == 'table' and (ex.sold or 0) < (ex.need or 5) then return false end
        end
        return original_can_sell(self, ...)
    end
    Card._cbuf_sell_wrapped = true
end

-- Keep spoiled-out Jokers debuffed.
if Card and type(Card.set_debuff) == 'function' and not Card._cbuf_debuff_wrapped then
    local original_set_debuff = Card.set_debuff
    function Card:set_debuff(should_debuff)
        if self.ability and (self.ability.cbuf_spoiled_rotten or self.ability.cbuf_silenced) then should_debuff = true end
        return original_set_debuff(self, should_debuff)
    end
    Card._cbuf_debuff_wrapped = true
end

-- Count down spoiled Jokers once per round.
local function tick_spoiled()
    if not (G and G.jokers and G.GAME) then return end
    for _, c in ipairs(G.jokers.cards) do
        local ab = c.ability
        if ab and ab[SPOIL_KEY] and not ab.cbuf_spoiled_rotten
            and ab.cbuf_spoiled_round ~= G.GAME.round then
            ab.cbuf_spoiled_round = G.GAME.round
            ab.cbuf_spoiled_tally = (ab.cbuf_spoiled_tally or SPOIL_ROUNDS) - 1
            if ab.cbuf_spoiled_tally <= 0 then
                ab.cbuf_spoiled_tally = 0
                ab.cbuf_spoiled_rotten = true
                c:set_debuff(true)
                show_message(c, 'Rotten!', G.C.RED)
            else
                show_message(c, ab.cbuf_spoiled_tally .. ' left', G.C.FILTER or G.C.ORANGE)
            end
        end
    end
end

local function tick_glass()
    if not (G and G.jokers and G.GAME) then return end
    local list = {}
    for _, c in ipairs(G.jokers.cards) do list[#list + 1] = c end
    for _, c in ipairs(list) do
        local ab = c.ability
        if ab and ab[GLASS_KEY] and not ab.cbuf_glass_breaking
            and ab.cbuf_glass_round ~= G.GAME.round then
            ab.cbuf_glass_breaking = true
            c._cbuf_force_dissolve = true
            if play_sound then play_sound('glass' .. math.random(1, 6), math.random() * 0.2 + 0.9, 0.6) end
            show_message(c, 'Shattered!', HEX('7FB8D0'))
            c:start_dissolve({ HEX('A8D8E8') }, nil, 1.6)
        end
    end
end

local tick_sweet_tooth -- defined further down (voucher section)
local tick_fancy_seal -- defined further down (Fancy Seal section)
local tick_crit -- defined further down (Critical Hit section)
local tick_rocks -- defined further down (Pile of Rocks section)
local tick_ice -- defined further down (Blue Ice section)

MOD.calculate = function(self, context)
    if context and context.end_of_round and not context.individual and not context.repetition
        and not context.game_over then
        tick_spoiled()
        tick_glass()
        if tick_sweet_tooth then tick_sweet_tooth() end
        if tick_crit then tick_crit() end
        if tick_rocks then tick_rocks() end
        if tick_ice then tick_ice() end
    end
    if context and context.ending_shop and tick_fancy_seal then
        tick_fancy_seal()
    end
end

local function spoil_random_joker(licker)
    local candidates = {}
    for _, c in ipairs(G.jokers.cards) do
        if c ~= licker and c.ability and not c.ability[SPOIL_KEY] and not c.ability[GLASS_KEY] then
            candidates[#candidates + 1] = c
        end
    end
    if #candidates == 0 then return false end
    local victim = pseudorandom_element(candidates, pseudoseed('cbuf_licker_spoil'))
    if type(victim.add_sticker) == 'function' then
        pcall(victim.add_sticker, victim, SPOIL_KEY, true)
    end
    victim.ability[SPOIL_KEY] = true
    victim.ability.cbuf_spoiled_tally = SPOIL_ROUNDS
    victim.ability.cbuf_spoiled_round = G.GAME.round
    victim.ability.cbuf_spoiled_rotten = nil
    victim:juice_up(0.6, 0.6)
    show_message(victim, 'Spoiled!', HEX('7A9A2A'))
    return true
end

-- Invert the "values" of a Joker: +5 Mult -> -5 Mult, X3 -> X0.33, +$ -> -$.
local function invert_table(t)
    for k, v in pairs(t) do
        if type(v) == 'number' then
            local lk = tostring(k):lower()
            if lk:find('odds', 1, true) or lk:find('chance', 1, true) then
                -- probabilities stay as they are
            elseif lk:find('x_mult', 1, true) or lk:find('xmult', 1, true)
                or lk:find('x_chips', 1, true) or lk:find('xchips', 1, true) then
                if v > 1 then t[k] = round2(1 / v) end
            elseif lk:find('mult', 1, true) or lk:find('chip', 1, true)
                or lk:find('dollar', 1, true) or lk:find('money', 1, true)
                or lk:find('bonus', 1, true) then
                t[k] = -v
            end
        elseif type(v) == 'table' then
            invert_table(v)
        end
    end
end

local function invert_ability(ab)
    local top = {}
    for _, f in ipairs({ 'mult', 't_mult', 't_chips', 'h_mult', 'h_chips', 'x_mult', 'h_x_mult', 'x_chips' }) do
        if type(ab[f]) == 'number' then top[f] = ab[f] end
    end
    invert_table(top)
    for f, v in pairs(top) do ab[f] = v end
    if type(ab.extra) == 'table' then invert_table(ab.extra) end
end

-- Destroy a Spoiled Joker and hand back its exact opposite, marked Glass.
local function devour_and_invert(licker, victim)
    local copy = copy_card(victim, nil, nil, nil, true)
    local ab = copy.ability
    ab[SPOIL_KEY] = nil
    ab.cbuf_spoiled_tally = nil
    ab.cbuf_spoiled_round = nil
    ab.cbuf_spoiled_rotten = nil
    invert_ability(ab)
    -- The Licker puts the Glass sticker on its creation right away.
    if type(copy.add_sticker) == 'function' then
        pcall(copy.add_sticker, copy, GLASS_KEY, true)
    end
    ab[GLASS_KEY] = true
    ab.cbuf_glass_round = G.GAME.round
    ab.cbuf_glass_breaking = nil
    copy.debuff = false

    show_message(victim, 'Devoured!', G.C.RED)
    victim._cbuf_force_dissolve = true
    victim:start_dissolve()

    G.E_MANAGER:add_event(Event({
        trigger = 'after',
        delay = 1.3,
        func = function()
            if G.jokers.config.card_limit <= #G.jokers.cards then
                if copy.set_edition then copy:set_edition({ negative = true }, true, true) end
            end
            if copy.set_cost then copy:set_cost() end
            copy:add_to_deck()
            G.jokers:emplace(copy)
            copy:juice_up(0.6, 0.6)
            show_message(copy, 'Inverted!', G.C.PURPLE or G.C.RED)
            return true
        end,
    }))
    return true
end

-- Hunger ran out: devour an existing Spoiled Joker (chance), otherwise spoil one.
local function starve_action(licker)
    local spoiled = {}
    for _, c in ipairs(G.jokers.cards) do
        if c ~= licker and c.ability and c.ability[SPOIL_KEY] then spoiled[#spoiled + 1] = c end
    end
    -- Normally the configured chance applies. If every other Joker is already
    -- Spoiled/Glass (nothing fresh left to spoil), the chance is 100% for this roll only.
    local fresh = 0
    for _, c in ipairs(G.jokers.cards) do
        if c ~= licker and c.ability and not c.ability[SPOIL_KEY] and not c.ability[GLASS_KEY] then
            fresh = fresh + 1
        end
    end
    local chance = get_devour_chance() / 100
    if fresh == 0 then chance = 1 end
    if #spoiled > 0 and (chance >= 1 or pseudorandom('cbuf_licker_devour') < chance) then
        local victim = pseudorandom_element(spoiled, pseudoseed('cbuf_licker_victim'))
        local ok, done = pcall(devour_and_invert, licker, victim)
        if ok and done then return true end
        -- If eating failed for any reason, fall back to spoiling another Joker.
    end
    return spoil_random_joker(licker)
end

-- Interest only exists if the run actually pays it (e.g. not on Green Deck).
local function interest_available()
    local g = G and G.GAME
    if not g then return false end
    if g.modifiers and g.modifiers.no_interest then return false end
    if (g.interest_amount or 1) <= 0 then return false end
    return (g.interest_cap or 25) > 5
end

-- Fallback meal when there is nothing to lick.
local function eat_money_or_interest(licker)
    local first_money = pseudorandom('cbuf_licker_meal') < 0.5
    for attempt = 1, 2 do
        local money = (attempt == 1) == first_money
        if money then
            local dollars = to_num(G.GAME.dollars)
            if dollars >= 1 then
                local take = math.max(1, math.floor(dollars / 2))
                ease_dollars(-take)
                show_message(licker, 'Ate $' .. take, G.C.MONEY or G.C.GOLD)
                return true
            end
        else
            local cap = G.GAME.interest_cap or 25
            if interest_available() then
                G.GAME.interest_cap = math.max(5, math.floor(cap / 2 / 5) * 5)
                show_message(licker, 'Ate Interest!', G.C.MONEY or G.C.GOLD)
                return true
            end
        end
    end
    return false
end

local function grant_reward(licker)
    local ex = licker.ability.extra
    local pick = pseudorandom_element(LICK_REWARDS, pseudoseed('cbuf_licker_reward'))
    local text, colour
    if pick == 'mult' then
        ex.mult = ex.mult + 4; text, colour = '+4 Mult', G.C.MULT
    elseif pick == 'chips' then
        ex.chips = ex.chips + 20; text, colour = '+20 Chips', G.C.CHIPS
    elseif pick == 'xmult' then
        ex.xmult = round2(ex.xmult + 0.1); text, colour = '+X0.1 Mult', G.C.MULT
    elseif pick == 'xchips' then
        ex.xchips = round2(ex.xchips + 0.1); text, colour = '+X0.1 Chips', G.C.CHIPS
    elseif pick == 'retrigger' then
        ex.reps = math.min(5, ex.reps + 1); text, colour = '+1 Retrigger', G.C.FILTER or G.C.ORANGE
    elseif pick == 'money' then
        ex.dollars = ex.dollars + 1; text, colour = '+$1 /round', G.C.MONEY or G.C.GOLD
    else
        ex.xmoney = round2(ex.xmoney + 0.05); text, colour = '+5% $ /round', G.C.MONEY or G.C.GOLD
    end
    show_message(licker, 'Lick! ' .. text, colour)
end

-- One feeding, run at the end of each blind.
local function licker_feed(card)
    local ex = card.ability.extra
    -- Once per round, even if the end-of-round context fires more than once.
    if G.GAME and ex.last_feed_round == G.GAME.round then return end
    if G.GAME then ex.last_feed_round = G.GAME.round end

    local licked = false
    local foods = lickable_food(card)
    if #foods > 0 then
        local target = pseudorandom_element(foods, pseudoseed('cbuf_licker_target'))
        licked = lick_food(target, card)
        if licked then target:juice_up(0.5, 0.5) end
    end

    -- Money / interest is only a side meal: it pays the scaling reward but
    -- does NOT satisfy hunger. Only licking a real Joker resets the hunger clock.
    local side_meal = false
    if not licked then side_meal = eat_money_or_interest(card) end

    if licked or side_meal then
        card:juice_up(0.5, 0.5)
        grant_reward(card)

    end

    if licked then
        ex.hunger = 0
    else
        ex.hunger = ex.hunger + 1
        local limit = get_licker_hunger() + (ex.hunger_bonus or 0)
        if ex.hunger >= limit then
            ex.hunger = 0
            ex.hunger_bonus = 0 -- the extra calm blind is used up: back to normal
            if not starve_action(card) then
                show_message(card, 'Hungry...', G.C.RED)
            end
        else
            show_message(card, 'Hungry... ' .. ex.hunger .. '/' .. limit, G.C.RED)
        end
    end
end

SMODS.Joker {
    key = 'licker',
    atlas = 'cbuf_licker',
    pos = { x = 0, y = 0 },
    -- Three layers (atlas frames): 1 = card background with the JOKER lettering (static),
    -- 2 = chains + lock (soul_pos, floats lightly like a Legendary Joker),
    -- 3.. = tongue: 12 pre-drawn frames of a pendulum swing hanging from the keyhole.
    soul_pos = {
        x = 1, y = 0,
        draw = function(card, scale_mod, rotate_mod)
            local sprite = card and card.children and card.children.floating_sprite
            if not sprite then return end
            local t = (G and G.TIMERS and G.TIMERS.REAL) or 0
            -- chains + lock: the Legendary motion at about 30% strength
            local s, r = (scale_mod or 0) * 0.3, (rotate_mod or 0) * 0.3
            sprite:draw_shader('dissolve', 0, nil, nil, card.children.center, s, r, nil,
                0.04 + 0.012 * math.sin(1.8 * t), nil, 0.6)
            sprite:draw_shader('dissolve', nil, nil, nil, card.children.center, s, r)
            -- tongue: its own sprite, created once, moving exactly with the lock.
            -- Kept in a plain field (NOT card.children): the game draws every unknown child by itself,
            -- which showed a second, static tongue.
            if not card.cbuf_tongue and sprite.atlas and Sprite then
                local ok, tongue = pcall(Sprite, card.T.x, card.T.y, card.T.w, card.T.h, sprite.atlas, { x = 2, y = 0 })
                if ok and tongue then
                    tongue.role.draw_major = card
                    tongue.states.hover.can = false
                    tongue.states.click.can = false
                    tongue.states.collide.can = false
                    card.cbuf_tongue = tongue
                end
            end
            local tongue = card.cbuf_tongue
            if tongue then
                local frame = math.floor(t / 0.22 + (card.sort_id or 0) % 12) % 12   -- ~2.6 s per swing
                if tongue.cbuf_frame ~= frame then
                    tongue.cbuf_frame = frame
                    tongue:set_sprite_pos({ x = 2 + frame, y = 0 })
                end
                tongue.VT.scale = card.VT.scale   -- not a child, so the game does not sync the size for us
                tongue:draw_shader('dissolve', nil, nil, nil, card.children.center, s, r)
            end
        end,
    },
    rarity = 3,
    cost = 8,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = false,
    config = { extra = {
        mult = 0, chips = 0, xmult = 1, xchips = 1,
        reps = 0, dollars = 0, xmoney = 0, hunger = 0, hunger_bonus = 0,
    } },
    -- Rare Joker: now also part of the normal Joker pool (the Candy Sleeve still starts you with one).
    loc_txt = {
        name = 'The Licker',
        text = {
            '{C:attention}Licks{} a Food Joker each blind',
            '(halves it) for a random bonus',
            'No food: eats {C:money}half{} your {C:money}$${} or {C:money}Interest{}',
            'No lick for {C:attention}#8#{} blinds ({C:red}#9#{}): {C:red}Spoils{} a Joker',
            '{C:mult}+#1#{} Mult  {C:chips}+#2#{} Chips',
            '{X:mult,C:white}X#3#{} Mult  {X:chips,C:white}X#4#{} Chips',
            '{C:attention}Retrigger #5#{}  {C:money}+$#6#{}  {C:money}+#7#%{} $',
            '{C:inactive}Likes Eggs and Diet Cola{}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = (card and card.ability and card.ability.extra) or self.config.extra
        return { vars = {
            ex.mult, ex.chips, ex.xmult, ex.xchips, ex.reps, ex.dollars,
            math.floor(ex.xmoney * 100 + 0.5), get_licker_hunger() + (ex.hunger_bonus or 0), ex.hunger or 0,
        } }
    end,
    -- JokerDisplay support (only used when the JokerDisplay mod is installed).
    joker_display_def = jd(LICKER_KEY, function(JokerDisplay)
        return {
            retrigger_function = function(playing_card, scoring_hand, held_in_hand, joker_card)
                local ok, n = pcall(function()
                    if held_in_hand or not scoring_hand or playing_card ~= scoring_hand[1] then return 0 end
                    local total = 0
                    for _, j in ipairs(jd_jokers(LICKER_KEY, joker_card)) do
                        total = total + (j.ability.extra.reps or 0)
                    end
                    return total
                end)
                return ok and n or 0
            end,
            text = {
                { ref_table = 'card.joker_display_values', ref_value = 'mult_text', colour = G.C.MULT },
                { ref_table = 'card.joker_display_values', ref_value = 'chips_text', colour = G.C.CHIPS },
                { ref_table = 'card.joker_display_values', ref_value = 'xmult_text', colour = G.C.MULT },
                { ref_table = 'card.joker_display_values', ref_value = 'xchips_text', colour = G.C.CHIPS },
            },
            reminder_text = {
                { text = '(' },
                { ref_table = 'card.joker_display_values', ref_value = 'hunger_text' },
                { text = ')' },
            },
            calc_function = function(card)
                local ex = card.ability.extra or {}
                local v = card.joker_display_values
                v.mult_text = (ex.mult or 0) > 0 and ('+' .. ex.mult .. ' ') or ''
                v.chips_text = (ex.chips or 0) > 0 and ('+' .. ex.chips .. ' ') or ''
                v.xmult_text = (ex.xmult or 1) > 1 and ('X' .. string.format('%.2f', ex.xmult) .. ' ') or ''
                v.xchips_text = (ex.xchips or 1) > 1 and ('X' .. string.format('%.2f', ex.xchips)) or ''
                v.hunger_text = (ex.hunger or 0) .. '/' .. (get_licker_hunger() + (ex.hunger_bonus or 0))
            end,
        }
    end),
    calculate = function(self, card, context)
        local ex = card.ability.extra
        if context.end_of_round and not context.individual and not context.repetition
            and not context.blueprint and not context.game_over
            and G.jokers and G.GAME then
            licker_feed(card)
            return
        end
        if context.repetition and context.cardarea == G.play and ex.reps > 0
            and context.scoring_hand and context.other_card == context.scoring_hand[1] then
            return { message = localize('k_again_ex'), repetitions = ex.reps, card = card }
        end
        if context.joker_main then
            local ret = {}
            if ex.mult > 0 then ret.mult = ex.mult end
            if ex.chips > 0 then ret.chips = ex.chips end
            if ex.xmult > 1 then ret.xmult = ex.xmult end
            if ex.xchips > 1 then ret.xchips = ex.xchips end
            if next(ret) then return ret end
        end
    end,
    calc_dollar_bonus = function(self, card)
        local ex = card.ability.extra
        local bonus = ex.dollars
        if ex.xmoney > 0 and G.GAME then
            bonus = bonus + math.min(XMONEY_CAP, math.floor(math.max(0, to_num(G.GAME.dollars)) * ex.xmoney))
        end
        if bonus > 0 then return bonus end
    end,
}

-- ===================================================================
-- Fried Eggs (Uncommon) — "Cavendish, but for the Egg".
-- Unlocked into the Joker pool for the rest of the run once you SELL an Egg
-- whose sell value is $12 or more. At the end of each round it adds the value
-- of your Interest to its own sell value. The Interest itself is untouched.
-- Fully deterministic (no RNG), so it is safe in Multiplayer.
-- ===================================================================
local EGG_SOLD_FLAG = 'cbuf_egg_sold'
local EGG_SELL_THRESHOLD = 12

SMODS.Atlas {
    key = 'cbuf_fried_eggs',
    path = 'fried_eggs.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

-- Pile of Rocks: 5 consumables sold, OR a single Joker older than the Pile, unlock it.
local PILE_KEY = 'j_cbuf_pile_of_rocks'
local function pile_count_sale(sold)
    if not (G and G.jokers and sold and sold.ability and not sold._cbuf_pile_counted) then return end
    sold._cbuf_pile_counted = true
    local set = sold.ability.set
    local is_consumable = sold.ability.consumeable or set == 'Tarot' or set == 'Planet' or set == 'Spectral'
    local is_joker = set == 'Joker'
    for _, p in ipairs(G.jokers.cards) do
        if p ~= sold and joker_key(p) == PILE_KEY and p.ability and type(p.ability.extra) == 'table' then
            local ex = p.ability.extra
            local need = ex.need or 5
            local older = is_joker and to_num(sold.sort_id) < to_num(p.sort_id)
            if (ex.sold or 0) < need then
                if older then
                    ex.sold = need -- one older Joker is enough
                    show_message(p, 'Sellable!', G.C.ORANGE or G.C.MONEY)
                elseif is_consumable then
                    ex.sold = (ex.sold or 0) + 1
                    show_message(p, ex.sold >= need and 'Sellable!' or (ex.sold .. '/' .. need), G.C.ORANGE or G.C.MONEY)
                end
            end
        end
    end
end

-- The sell value of an Egg at the moment it is sold. The shown sell_cost is used, and as a
-- safety net the value is also rebuilt from its cost + extra_value (the Egg's own growth),
-- so a stale/odd sell_cost can never hide a $12+ Egg.
local function egg_sell_value(card)
    local shown = to_num(card.sell_cost)
    local rebuilt = 0
    if card.ability then
        rebuilt = math.max(1, math.floor(to_num(card.cost) / 2)) + to_num(card.ability.extra_value)
    end
    return math.max(shown, rebuilt)
end

local function fried_eggs_unlocked()
    if not (G and G.GAME) then return false end
    if G.GAME.pool_flags and G.GAME.pool_flags[EGG_SOLD_FLAG] then return true end
    return G.GAME[EGG_SOLD_FLAG] == true
end

-- Remember that an Egg worth $12+ was sold (this is what "extinct" is for Gros Michel).
-- From then on Fried Eggs can show up in shops and Buffoon Packs for the rest of the run.
if Card and type(Card.sell_card) == 'function' and not Card._cbuf_egg_sell_wrapped then
    local original_sell_card = Card.sell_card
    function Card:sell_card(...)
        pcall(pile_count_sale, self)
        if G and G.GAME and joker_key(self) == 'j_egg'
            and not fried_eggs_unlocked()
            and egg_sell_value(self) >= EGG_SELL_THRESHOLD then
            G.GAME.pool_flags = G.GAME.pool_flags or {}
            G.GAME.pool_flags[EGG_SOLD_FLAG] = true
            G.GAME[EGG_SOLD_FLAG] = true
            pcall(show_message, self, 'Fried Eggs!', G.C.ORANGE or G.C.MONEY)
        end
        return original_sell_card(self, ...)
    end
    Card._cbuf_egg_sell_wrapped = true
end

-- The Interest the game will pay at the end of this round (same formula as vanilla).
local function fried_interest_value()
    local g = G and G.GAME
    if not g then return 0 end
    if g.modifiers and g.modifiers.no_interest then return 0 end
    local dollars = to_num(g.dollars)
    if dollars < 5 then return 0 end
    local amount = g.interest_amount or 1
    local cap = g.interest_cap or 25
    return math.max(0, math.floor(amount * math.min(math.floor(dollars / 5), cap / 5)))
end

SMODS.Joker {
    key = 'fried_eggs',
    atlas = 'cbuf_fried_eggs',
    pos = { x = 0, y = 0 },
    rarity = 2, -- Uncommon
    cost = 6,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = true,
    pools = { Food = true },
    cbuf_food = true,
    config = { extra = { last_round = 0 } },
    in_pool = function(self, args)
        return fried_eggs_unlocked()
    end,
    loc_txt = {
        name = 'Fried Eggs',
        text = {
            'End of round: gains your',
            '{C:money}Interest{} as {C:money}sell value{}',
            '{C:inactive}(Currently {C:money}+$#1#{C:inactive}){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local v = (card and card.ability and card.ability.extra_value) or 0
        return { vars = { v } }
    end,
    -- Credit badge under the card.
    set_badges = function(self, card, badges)
        if type(create_badge) == 'function' then
            badges[#badges + 1] = create_badge('Idea: Z-Leon', G.C.CLEAR or { 0, 0, 0, 0 }, G.C.WHITE, 1.0)
        end
    end,
    -- JokerDisplay support: shows the sell value it will gain this round.
    joker_display_def = jd('j_cbuf_fried_eggs', function(JokerDisplay)
        return {
            text = {
                { text = '+$' },
                { ref_table = 'card.joker_display_values', ref_value = 'gain' },
            },
            text_config = { colour = G.C.GOLD },
            reminder_text = {
                { text = '(Interest)' },
            },
            calc_function = function(card)
                card.joker_display_values.gain = fried_interest_value()
            end,
        }
    end),
    calculate = function(self, card, context)
        if context.end_of_round and not context.individual and not context.repetition
            and not context.blueprint and not context.game_over and G.GAME then
            local ex = card.ability.extra
            if ex.last_round == G.GAME.round then return end -- once per round
            ex.last_round = G.GAME.round
            local gain = fried_interest_value()
            if gain > 0 then
                card.ability.extra_value = (card.ability.extra_value or 0) + gain
                if card.set_cost then card:set_cost() end
                show_message(card, '+$' .. gain .. ' value', G.C.MONEY or G.C.GOLD)
            end
        end
    end,
}

-- ===================================================================
-- Menos (Epic) — retriggers every scored card once more for each 8 of Spades
-- in your full deck, with a 1 in 2 chance per hand.
-- Epic is a rarity added by this mod (rarer than Rare, like Cryptid's Epic).
-- ===================================================================
-- With Cryptid installed, Menos uses Cryptid's own Epic rarity (same badge, colour and
-- shop rate as every other Epic Joker). Without Cryptid, this mod adds its own Epic rarity.
local CRYPTID_LOADED = SMODS.Mods and SMODS.Mods.Cryptid and SMODS.Mods.Cryptid.can_load and true or false
local MENOS_RARITY = 'cbuf_epic'
if CRYPTID_LOADED then
    MENOS_RARITY = 'cry_epic'
else
    SMODS.Rarity {
        key = 'epic',
        loc_txt = { name = 'Epic' },
        badge_colour = HEX('B04CFF'),
        default_weight = 0.005, -- Rare is 0.05: Epic is now much rarer than Rare (was 0.01, v1.26.22)
        pools = { ['Joker'] = true },
        get_weight = function(self, weight, object_type)
            return weight
        end,
    }
end

SMODS.Atlas {
    key = 'cbuf_menos',
    path = 'menos.png',
    -- v1.26.16: 142x190 frames (the supplied art is double resolution), so no file is ever resampled
    px = 142,
    py = 190,
    disable_mipmap = true,
}

-- A Wild Card counts as every suit, so a Wild 8 counts as an 8 of Spades for Menos.
local function is_wild_card(c)
    if not c then return false end
    if c.ability and c.ability.name == 'Wild Card' then return true end
    if c.config and c.config.center and c.config.center.key == 'm_wild' then return true end
    if SMODS and type(SMODS.has_enhancement) == 'function' then
        local ok, r = pcall(SMODS.has_enhancement, c, 'm_wild')
        if ok and r then return true end
    end
    return false
end

-- 8 of Spades + Wild 8s (any suit) in the full deck.
local function count_eights_of_spades()
    local n = 0
    if G and G.playing_cards then
        for _, c in ipairs(G.playing_cards) do
            if c.base and c.base.id == 8 and not (c.ability and c.ability.effect == 'Stone Card')
                and (c.base.suit == 'Spades' or is_wild_card(c)) then
                n = n + 1
            end
        end
    end
    return n
end

local function menos_roll(card)
    if SMODS and type(SMODS.pseudorandom_probability) == 'function' then
        return SMODS.pseudorandom_probability(card, 'cbuf_menos', 1, 2, 'cbuf_menos') and true or false
    end
    local num = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return pseudorandom('cbuf_menos') < num / 2
end

SMODS.Joker {
    key = 'menos',
    atlas = 'cbuf_menos',
    pos = { x = 0, y = 0 },
    -- v1.26.13: the duck is a floating layer above the red card, like a Legendary Joker
    -- frame 1 = big duck (default), frame 2 = small duck; choose with menos_duck = 'big' / 'small' in config.lua
    soul_pos = { x = (MOD_CONFIG.menos_duck == 'small') and 2 or 1, y = 0 },
    rarity = MENOS_RARITY,
    cost = 10,
    unlocked = true,
    discovered = true,
    -- v1.26.22: Menos is much rarer in a normal run: only 1 in 4 of the times he could appear does he
    -- actually enter the pool (was 3 in 4). Works with or without Cryptid, because it only thins
    -- Menos itself and not the whole Epic rarity.
    in_pool = function(self, args)
        return pseudorandom('cbuf_menos_pool') < 0.25
    end,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = { active = false } },
    loc_txt = {
        name = 'Menos',
        text = {
            'Scored cards retrigger {C:attention}+1{} time',
            'per {C:attention}8 of Spades{} or {C:attention}Wild 8{} in deck',
            '{C:green}#2# in #3#{} chance each hand',
            '{C:inactive}(Currently {C:attention}#1#{C:inactive}){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local num = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
        return { vars = { count_eights_of_spades(), num, 2 } }
    end,
    -- Credit badge under the card.
    set_badges = function(self, card, badges)
        if type(create_badge) == 'function' then
            badges[#badges + 1] = create_badge('Idea: menos', G.C.CLEAR or { 0, 0, 0, 0 }, G.C.WHITE, 1.0)
        end
    end,
    -- JokerDisplay support: extra retriggers and the activation odds.
    joker_display_def = jd('j_cbuf_menos', function(JokerDisplay)
        return {
            -- Every scored card is retriggered once per 8 of Spades / Wild 8 (shown optimistically;
            -- the 1 in 2 chance is displayed next to the count).
            retrigger_function = function(playing_card, scoring_hand, held_in_hand, joker_card)
                local ok, n = pcall(function()
                    if held_in_hand then return 0 end
                    if #jd_jokers('j_cbuf_menos', joker_card) == 0 then return 0 end
                    return count_eights_of_spades()
                end)
                return ok and n or 0
            end,
            text = {
                { text = '+' },
                { ref_table = 'card.joker_display_values', ref_value = 'count' },
            },
            text_config = { colour = G.C.ORANGE },
            extra = {
                {
                    { text = '(' },
                    { ref_table = 'card.joker_display_values', ref_value = 'odds' },
                    { text = ')' },
                },
            },
            extra_config = { colour = G.C.GREEN, scale = 0.3 },
            calc_function = function(card)
                local num = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
                card.joker_display_values.count = count_eights_of_spades()
                card.joker_display_values.odds = jd_odds_text(2)
            end,
        }
    end),
    calculate = function(self, card, context)
        local ex = card.ability.extra
        if context.before and not context.blueprint then
            ex.active = menos_roll(card)
            if ex.active then show_message(card, 'Menos!', HEX('B04CFF')) end
            return
        end
        if context.repetition and context.cardarea == G.play and ex.active then
            local n = count_eights_of_spades()
            if n > 0 then
                return { message = localize('k_again_ex'), repetitions = n, card = card }
            end
            return
        end
        if context.after and not context.blueprint then
            ex.active = false
        end
    end,
}

-- ===================================================================
-- Fancy Seal + the Tarot "Tolape".
-- Fancy Seal: at the end of every shop, each Fancy Seal card has a 1 in 2 chance to pay $1.
-- Tolape: turns the Gold Seal on 1 selected card into a Fancy Seal.
-- ===================================================================
local FANCY_SEAL = 'cbuf_fancy'

local function fancy_vars()
    local num = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return { num, 2 }
end

local function fancy_roll(card)
    if SMODS and type(SMODS.pseudorandom_probability) == 'function' then
        return SMODS.pseudorandom_probability(card, 'cbuf_fancy', 1, 2, 'cbuf_fancy') and true or false
    end
    local num = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return pseudorandom('cbuf_fancy') < num / 2
end

SMODS.Atlas {
    key = 'cbuf_fancy_seal',
    path = 'fancy_seal.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

SMODS.Seal {
    key = 'fancy',
    atlas = 'cbuf_fancy_seal',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('F2B632'),
    loc_txt = {
        label = 'Fancy Seal',
        name = 'Fancy Seal',
        text = {
            'Earn {C:money}$3{} when scored',
            '{C:green}#1# in #2#{} for {C:money}+$1{} more when scored',
            '{C:green}#1# in #2#{} for {C:money}$1{} at shop end',
            '{C:inactive}Idea: {C:attention}menos{}',
        },
    },
    loc_vars = function(self, info_queue, card)
        return { vars = fancy_vars() }
    end,
    -- When the card is played and scores: $3 like a Gold Seal, plus a 1 in 2 chance for $1 more.
    -- Paid through calculate(), the same route Gold Seal uses, so the card shakes and shows
    -- the gold "$" popup with the coin sound exactly like a Gold Seal.
    -- Same look as the Gold Seal: the normal seal draw plus the shiny "voucher" shader overlay
    -- (the shimmer you see on a Gold Seal when it moves or is hovered).
    draw = function(self, card, layer)
        local spr = G and G.shared_seals and card and card.seal and G.shared_seals[card.seal]
        if not spr then return end
        pcall(function()
            spr.role.draw_major = card
            spr:draw_shader('dissolve', nil, nil, nil, card.children.center)
            spr:draw_shader('voucher', nil, card.ARGS.send_to_shader, nil, card.children.center)
        end)
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            local pay = 3
            if fancy_roll(card) then pay = pay + 1 end
            return { dollars = pay }
        end
    end,
}

-- Fancy Seal payout: runs once when you leave the shop.
-- Every Fancy Seal card in the full deck has a 1 in 2 chance to give $1
-- (it also rolls the same 1 in 2 chance whenever the card scores).
tick_fancy_seal = function()
    if not (G and G.GAME and G.playing_cards) then return end
    if G.GAME.cbuf_fancy_round == G.GAME.round then return end
    G.GAME.cbuf_fancy_round = G.GAME.round
    local pay = 0
    for _, c in ipairs(G.playing_cards) do
        if c.seal == FANCY_SEAL and not c.debuff and fancy_roll(c) then
            pay = pay + 1
        end
    end
    if pay > 0 then
        ease_dollars(pay)
        if play_sound then play_sound('coin1') end
    end
end

-- ===================================================================
-- Orange Juice (Enhancement). Only obtained through the Tarot "Tolape".
-- When it scores (every roll is independent):
--   * 1 in 10: earn $3
--   * 1 in 15: permanently evolve, +X0.1 Chips (stacks, kept for good)
--   * 1 in 24: the enhancement turns into a Gold Seal (or the Golden copy of its seal, see golden_seals.lua);
--              if the seal is already golden it retriggers the card instead
-- ===================================================================
local OJ_KEY = 'm_cbuf_orange_juice'
local OJ_MONEY_ODDS, OJ_GROW_ODDS, OJ_GOLD_ODDS = 10, 15, 24

-- Probability helpers that follow Oops! All 6s / other probability mods when SMODS has them.
local function prob_vars(card, odds, id)
    if SMODS and type(SMODS.get_probability_vars) == 'function' then
        local ok, n, d = pcall(SMODS.get_probability_vars, card, 1, odds, id)
        if ok and n and d then return n, d end
    end
    local num = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return num, odds
end

local function prob_roll(card, odds, id)
    if SMODS and type(SMODS.pseudorandom_probability) == 'function' then
        return SMODS.pseudorandom_probability(card, id, 1, odds, id) and true or false
    end
    local num = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return pseudorandom(id) < num / odds
end

-- What the 1 in 24 does depends on the card's seal:
--   'gold'       no seal or a Red / Blue / Purple / Hot Wax seal: the seal becomes (Golden) Gold (golden_seals.lua)
--   'retrigger'  the seal is ALREADY golden (Gold, Fancy, Golden Red / Blue / Purple / Hot Wax) or comes from another
--                mod (nothing we can make golden): the card is retriggered
local function oj_mode(card)
    local seal = card and card.seal
    if not seal then return 'gold' end
    if seal == 'Gold' or seal == 'cbuf_fancy' then return 'retrigger' end
    local gmap = _G.CBUF_GOLDEN and _G.CBUF_GOLDEN.map
    if gmap then
        if gmap[seal] then return 'gold' end
        for _, v in pairs(gmap) do if v == seal then return 'retrigger' end end
    end
    return 'retrigger'      -- a seal from another mod
end

SMODS.Atlas {
    key = 'cbuf_orange_juice',
    path = 'orange_juice.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

SMODS.Enhancement {
    key = 'orange_juice',
    atlas = 'cbuf_orange_juice',
    pos = { x = 0, y = 0 },
    config = { extra = { x_chips = 1, gain = 0.1, money = 3 } },
    -- Never appears at random (Standard Packs etc.): Tolape is the only source.
    weight = 0,
    in_pool = function(self, args) return false end,
    loc_txt = {
        name = 'Orange Juice',
        text = {
            '{C:green}#1# in #2#{}: earn {C:money}$3{}',
            '{C:green}#3# in #4#{}: permanent {X:chips,C:white}X0.1{} Chips',
            '{C:green}#5# in #6#{}: #8#',
            '{s:0.85,C:inactive}#9#{}',
            '{C:inactive}(Currently {X:chips,C:white}X#7#{C:inactive}){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = (card and card.ability and type(card.ability.extra) == 'table' and card.ability.extra)
            or self.config.extra
        local n1, d1 = prob_vars(card, OJ_MONEY_ODDS, 'cbuf_oj_money')
        local n2, d2 = prob_vars(card, OJ_GROW_ODDS, 'cbuf_oj_grow')
        local n3, d3 = prob_vars(card, OJ_GOLD_ODDS, 'cbuf_oj_gold')
        info_queue[#info_queue + 1] = { key = 'gold_seal', set = 'Other', vars = {} }
        local mode = oj_mode(card)
        local t8, t9
        if mode == 'retrigger' then
            local golden = card.seal == 'Gold' or card.seal == 'cbuf_fancy' or tostring(card.seal):find('golden', 1, true)
            t8, t9 = 'retrigger this card', golden and '(seal already golden)' or '(this seal stays as it is)'
        elseif card and card.seal then t8, t9 = 'seal turns Golden', '(keeps its old ability)'
        else t8, t9 = 'becomes Gold Seal', '(card has no seal)' end
        return { vars = { n1, d1, n2, d2, n3, d3, string.format('%.2f', ex.x_chips or 1), t8, t9 } }
    end,
    calculate = function(self, card, context)
        -- Seal already golden: the 1 in 24 retriggers the card instead.
        if context.repetition and context.cardarea == G.play and oj_mode(card) == 'retrigger' then
            if prob_roll(card, OJ_GOLD_ODDS, 'cbuf_oj_retrigger') then
                return { repetitions = 1, message = (type(localize) == 'function' and localize('k_again_ex')) or 'Again!' }
            end
            return
        end
        if not (context.main_scoring and context.cardarea == G.play) then return end
        if type(card.ability.extra) ~= 'table' then
            card.ability.extra = { x_chips = 1, gain = 0.1, money = 3 }
        end
        local ex = card.ability.extra
        local ret = {}
        -- Extra popups are chained under `extra` so they show after the main effect.
        local last = ret
        local function add_message(text, colour)
            local e = { message = text, colour = colour }
            last.extra = e
            last = e
        end

        -- 1 in 15: evolve forever (+X0.1 Chips).
        if prob_roll(card, OJ_GROW_ODDS, 'cbuf_oj_grow') then
            ex.x_chips = round2((ex.x_chips or 1) + (ex.gain or 0.1))
            add_message('Evolved! X' .. string.format('%.2f', ex.x_chips), G.C.CHIPS)
        end
        if (ex.x_chips or 1) > 1 then ret.x_chips = ex.x_chips end

        -- 1 in 10: $3.
        if prob_roll(card, OJ_MONEY_ODDS, 'cbuf_oj_money') then
            ret.dollars = ex.money or 3
        end

        -- 1 in 24: the enhancement turns into a seal (after this card has finished scoring):
        --   no seal -> Gold Seal;  Red / Blue / Purple / Hot Wax -> the GOLDEN copy of that seal (golden_seals.lua);
        --   Gold / Fancy / already golden -> nothing to improve, so no roll.
        local gmap = _G.CBUF_GOLDEN and _G.CBUF_GOLDEN.map
        local new_seal = (card.seal == nil) and 'Gold' or (gmap and gmap[card.seal])   -- golden seals: see 'retrigger' above
        if new_seal and prob_roll(card, OJ_GOLD_ODDS, 'cbuf_oj_gold') then
            add_message(new_seal == 'Gold' and 'Gold Seal!' or 'Golden!', G.C.GOLD or G.C.MONEY)
            G.E_MANAGER:add_event(Event({
                func = function()
                    -- Queue the change behind the score popups that are already waiting.
                    G.E_MANAGER:add_event(Event({
                        trigger = 'after', delay = 0.3,
                        func = function()
                            if card and not card.removed and card.config and card.config.center
                                and card.config.center.key == OJ_KEY then
                                card:juice_up(0.6, 0.6)
                                card:set_ability(G.P_CENTERS.c_base, nil, true)
                                card:set_seal(new_seal, nil, true)
                            end
                            return true
                        end,
                    }))
                    return true
                end,
            }))
        end

        if next(ret) then return ret end
    end,
}

SMODS.Atlas {
    key = 'cbuf_tolape',
    path = 'tolape.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

SMODS.Consumable {
    key = 'tolape',
    set = 'Tarot',
    atlas = 'cbuf_tolape',
    pos = { x = 0, y = 0 },
    cost = 3,
    unlocked = true,
    discovered = true,
    config = { max_highlighted = 1 },
    loc_txt = {
        name = 'Tolape',
        text = {
            '{C:attention}Gold Seal{} on {C:attention}1{} card',
            'becomes {C:attention}Fancy Seal{}',
            'No seal: {C:green}#1# in #2#{} for {C:attention}Orange Juice{}',
        },
    },
    loc_vars = function(self, info_queue, card)
        info_queue[#info_queue + 1] = { key = 'gold_seal', set = 'Other', vars = {} }
        info_queue[#info_queue + 1] = { key = 'cbuf_fancy_seal', set = 'Other', vars = fancy_vars() }
        if G and G.P_CENTERS and G.P_CENTERS[OJ_KEY] then
            info_queue[#info_queue + 1] = G.P_CENTERS[OJ_KEY]
        end
        local n, d = prob_vars(card, 5, 'cbuf_tolape')
        return { vars = { n, d } }
    end,
    -- Credit badge under the card (same idea as the Fancy Seal's creator).
    set_badges = function(self, card, badges)
        if type(create_badge) == 'function' then
            badges[#badges + 1] = create_badge('Idea: menos', G.C.CLEAR or { 0, 0, 0, 0 }, G.C.WHITE, 1.0)
        end
    end,
    -- Gold Seal card -> Fancy Seal. Any other card -> 1 in 5 chance of Orange Juice.
    can_use = function(self, card)
        if not (G.hand and #G.hand.highlighted == 1) then return false end
        local target = G.hand.highlighted[1]
        if not target then return false end
        if target.seal == 'Gold' then return true end
        return not (target.config and target.config.center and target.config.center.key == OJ_KEY)
    end,
    use = function(self, card, area, copier)
        local used = copier or card
        local target = G.hand.highlighted[1]
        local to_fancy = target.seal == 'Gold'
        -- The 1 in 5 roll is made once, up front.
        local juice_ok = (not to_fancy) and prob_roll(used, 5, 'cbuf_tolape')

        G.E_MANAGER:add_event(Event({
            trigger = 'after', delay = 0.4,
            func = function()
                play_sound('tarot1')
                used:juice_up(0.3, 0.5)
                return true
            end,
        }))

        if to_fancy or juice_ok then
            G.E_MANAGER:add_event(Event({
                trigger = 'after', delay = 0.15,
                func = function()
                    target:flip()
                    play_sound('card1', 1.15)
                    target:juice_up(0.3, 0.3)
                    return true
                end,
            }))
            delay(0.2)
            G.E_MANAGER:add_event(Event({
                trigger = 'after', delay = 0.1,
                func = function()
                    if to_fancy then
                        target:set_seal(FANCY_SEAL, nil, true)
                    else
                        target:set_ability(G.P_CENTERS[OJ_KEY])
                    end
                    return true
                end,
            }))
            G.E_MANAGER:add_event(Event({
                trigger = 'after', delay = 0.15,
                func = function()
                    target:flip()
                    play_sound('tarot2', 0.85, 0.6)
                    target:juice_up(0.3, 0.3)
                    return true
                end,
            }))
        else
            -- No Gold Seal and the 1 in 5 failed: the juice was sour.
            G.E_MANAGER:add_event(Event({
                trigger = 'after', delay = 0.2,
                func = function()
                    show_message(used, 'Nope!', G.C.RED)
                    return true
                end,
            }))
        end

        G.E_MANAGER:add_event(Event({
            trigger = 'after', delay = 0.2,
            func = function()
                G.hand:unhighlight_all()
                return true
            end,
        }))
        delay(0.5)
    end,
}

-- ===================================================================
-- Critical Hit sticker  ->  Broken Sword sticker.  (Idea: Sun fall)
--   Critical Hit : the Joker's effects are x1.5 until the end of the round,
--                  then the sticker turns into Broken Sword.
--   Broken Sword : the Joker's effects are x0.75 until the end of the next
--                  round, then the sticker disappears.
-- The tarot "Broken Sword" puts Critical Hit on a selected Joker.
-- The scaling is applied to the effect the Joker RETURNS (mult, chips, X mult,
-- X chips, dollars), so the Joker's own stored values are never rewritten.
-- ===================================================================
local CRIT_KEY = 'cbuf_critical_hit'
local BROKEN_KEY = 'cbuf_broken_sword'
local CRIT_FACTOR = 1.5
local BROKEN_FACTOR = 0.75

SMODS.Atlas {
    key = 'cbuf_critical_hit',
    path = 'cbuf_critical_hit.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

SMODS.Atlas {
    key = 'cbuf_broken_sword',
    path = 'cbuf_broken_sword.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

SMODS.Sticker {
    key = 'critical_hit',
    atlas = 'cbuf_critical_hit',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('C9304B'),
    rate = 0,
    needs_enable_flag = false,
    default_compat = true,
    sets = { Joker = true },
    loc_txt = {
        name = 'Critical Hit',
        label = 'Critical Hit',
        text = {
            'Effects {C:attention}1.5X{} this round,',
            'then becomes {C:red}Broken Sword{}',
        },
    },
}

SMODS.Sticker {
    key = 'broken_sword',
    atlas = 'cbuf_broken_sword',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('3F8FE0'),
    rate = 0,
    needs_enable_flag = false,
    default_compat = true,
    sets = { Joker = true },
    loc_txt = {
        name = 'Broken Sword',
        label = 'Broken Sword',
        text = {
            'Effects {C:red}0.75X{}',
            'until end of next round',
        },
    },
}

local function crit_factor(card)
    local ab = card and card.ability
    if not ab then return 1 end
    if ab[CRIT_KEY] then return CRIT_FACTOR end
    if ab[BROKEN_KEY] then return BROKEN_FACTOR end
    return 1
end

-- Effect keys returned by Jokers (old Balatro names and Steamodded names).
local CRIT_ADD_KEYS = {
    mult = true, mult_mod = true, h_mult = true,
    chips = true, chip_mod = true, h_chips = true,
    dollars = true, p_dollars = true,
}
local CRIT_X_KEYS = {
    xmult = true, x_mult = true, Xmult = true, Xmult_mod = true, h_x_mult = true,
    xchips = true, x_chips = true, Xchip_mod = true, h_x_chips = true,
}

local function scale_effect(ret, f, depth)
    depth = depth or 0
    if type(ret) ~= 'table' or depth > 4 then return end
    for k, v in pairs(ret) do
        if type(v) == 'number' then
            if CRIT_ADD_KEYS[k] then
                if k == 'dollars' or k == 'p_dollars' then
                    ret[k] = math.floor(v * f + 0.5)
                else
                    ret[k] = round2(v * f)
                end
            elseif CRIT_X_KEYS[k] then
                ret[k] = round2(1 + (v - 1) * f)
            end
        elseif k == 'extra' and type(v) == 'table' then
            scale_effect(v, f, depth + 1)
        end
    end
    -- Keep the floating message in step with the new number.
    if type(ret.message) == 'string' and type(localize) == 'function' then
        pcall(function()
            if ret.Xmult_mod then
                ret.message = localize { type = 'variable', key = 'a_xmult', vars = { ret.Xmult_mod } }
            elseif ret.mult_mod then
                ret.message = localize { type = 'variable', key = 'a_mult', vars = { ret.mult_mod } }
            elseif ret.chip_mod then
                ret.message = localize { type = 'variable', key = 'a_chips', vars = { ret.chip_mod } }
            end
        end)
    end
end

-- Wraps whatever calculate_joker is installed at this point (including this mod's own
-- earlier wrapper) and passes every return value through.
if Card and type(Card.calculate_joker) == 'function' and not Card._cbuf_crit_wrapped then
    local previous_calculate_joker = Card.calculate_joker
    function Card:calculate_joker(...)
        local ret, trig = previous_calculate_joker(self, ...)
        local f = crit_factor(self)
        if f ~= 1 and type(ret) == 'table' then scale_effect(ret, f) end
        return ret, trig
    end
    Card._cbuf_crit_wrapped = true
end

-- End-of-round money from a Joker (e.g. Golden Joker) is scaled too.
if Card and type(Card.calculate_dollar_bonus) == 'function' and not Card._cbuf_crit_dollar_wrapped then
    local original_dollar_bonus = Card.calculate_dollar_bonus
    function Card:calculate_dollar_bonus(...)
        local v = original_dollar_bonus(self, ...)
        local f = crit_factor(self)
        if f ~= 1 and type(v) == 'number' then v = math.floor(v * f + 0.5) end
        return v
    end
    Card._cbuf_crit_dollar_wrapped = true
end

-- One tick per finished round. G.GAME.cbuf_rounds_done counts finished rounds, so
-- "until the end of the round" is exact whether the tarot was used in the shop (the
-- buff covers the whole next round) or in the middle of a Blind (it covers the rest of it).
tick_crit = function()
    if not (G and G.GAME and G.jokers) then return end
    if G.GAME.cbuf_crit_last ~= G.GAME.round then
        G.GAME.cbuf_crit_last = G.GAME.round
        G.GAME.cbuf_rounds_done = (G.GAME.cbuf_rounds_done or 0) + 1
    end
    local done = G.GAME.cbuf_rounds_done
    for _, j in ipairs(G.jokers.cards) do
        local ab = j.ability
        if ab then
            if ab[CRIT_KEY] and done > (ab.cbuf_crit_start or -1) then
                ab[CRIT_KEY] = nil
                ab[BROKEN_KEY] = true
                ab.cbuf_broken_start = done
                j:juice_up(0.5, 0.5)
                show_message(j, 'Broken Sword...', HEX('3F8FE0'))
            elseif ab[BROKEN_KEY] and done > (ab.cbuf_broken_start or -1) then
                ab[BROKEN_KEY] = nil
                ab.cbuf_broken_start = nil
                show_message(j, 'Sword gone', G.C.UI and G.C.UI.TEXT_INACTIVE or G.C.WHITE)
            end
        end
    end
end

SMODS.Atlas {
    key = 'cbuf_blade',
    path = 'cbuf_blade.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

local function can_take_crit(j)
    return j and j.ability and j.ability.set == 'Joker'
        and not j.ability[CRIT_KEY] and not j.ability[BROKEN_KEY]
end

SMODS.Consumable {
    key = 'blade',
    set = 'Tarot',
    atlas = 'cbuf_blade',
    pos = { x = 0, y = 0 },
    cost = 3,
    unlocked = true,
    discovered = true,
    config = {},
    loc_txt = {
        name = 'Broken Sword',
        text = {
            'Gives {C:attention}Critical Hit{}',
            'to {C:attention}1{} selected Joker',
        },
    },
    loc_vars = function(self, info_queue, card)
        info_queue[#info_queue + 1] = { key = 'cbuf_critical_hit', set = 'Other', vars = {} }
        info_queue[#info_queue + 1] = { key = 'cbuf_broken_sword', set = 'Other', vars = {} }
        return { vars = {} }
    end,
    -- Credit badge under the card.
    set_badges = function(self, card, badges)
        if type(create_badge) == 'function' then
            badges[#badges + 1] = create_badge('Idea: Sun fall', G.C.CLEAR or { 0, 0, 0, 0 }, G.C.WHITE, 1.0)
        end
    end,
    can_use = function(self, card)
        return G.jokers and #G.jokers.highlighted == 1 and can_take_crit(G.jokers.highlighted[1]) and true or false
    end,
    use = function(self, card, area, copier)
        local used = copier or card
        local target = G.jokers.highlighted[1]
        G.E_MANAGER:add_event(Event({
            trigger = 'after', delay = 0.4,
            func = function()
                play_sound('tarot1')
                used:juice_up(0.3, 0.5)
                if can_take_crit(target) then
                    target.ability[CRIT_KEY] = true
                    target.ability.cbuf_crit_start = (G.GAME and G.GAME.cbuf_rounds_done) or 0
                    target:juice_up(0.6, 0.6)
                    play_sound('multhit2', 1, 0.7)
                    show_message(target, 'Critical Hit!', HEX('C9304B'))
                end
                if G.jokers then G.jokers:unhighlight_all() end
                return true
            end,
        }))
        delay(0.5)
    end,
}

-- ===================================================================
-- Pile of Rocks (Joker) and the Tarot "Rock Pile".
-- Rock Pile:  2 in 4 nothing happens. Otherwise 1 in 6: the selected Joker is destroyed
--             and a Joker of a higher rarity is created. If that fails: Pile of Rocks.
-- Pile of Rocks (only comes from Rock Pile):
--   * 2 in 4 to steal 20-120 Chips, 1 in 2 to steal 1-21 Mult (every hand)
--   * 1 in 8 to silence the nearest Joker until the end of the round
--   * 1 in 20 at end of round: pays what it stole this round ($1 per 10 Chips + $1 per Mult)
--   * cannot be sold until 5 consumables, or 1 Joker older than it, were sold
--   * when sold: 1 in 32 for a random Edition on a Joker or a deck card, but 5 deck
--     cards are destroyed
-- ===================================================================
local function prob_vars_n(card, num, den, id)
    if SMODS and type(SMODS.get_probability_vars) == 'function' then
        local ok, n, d = pcall(SMODS.get_probability_vars, card, num, den, id)
        if ok and n and d then return n, d end
    end
    local normal = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return num * normal, den
end
local function prob_roll_n(card, num, den, id)
    if SMODS and type(SMODS.pseudorandom_probability) == 'function' then
        local ok, r = pcall(SMODS.pseudorandom_probability, card, id, num, den, id)
        if ok then return r and true or false end
    end
    local normal = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return pseudorandom(id) < (num * normal) / den
end

SMODS.Atlas {
    key = 'cbuf_pile_of_rocks',
    path = 'pile_of_rocks.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

local function silence_nearest(card)
    if not (G and G.jokers) then return end
    local idx
    for i, c in ipairs(G.jokers.cards) do if c == card then idx = i break end end
    if not idx then return end
    local target = G.jokers.cards[idx + 1] or G.jokers.cards[idx - 1]
    if target and target.ability and not target.ability.cbuf_silenced then
        target.ability.cbuf_silenced = true
        if target.set_debuff then target:set_debuff(true) end
        target:juice_up(0.4, 0.4)
        show_message(target, 'Silenced!', G.C.RED)
    end
end

-- 1 in 32 when the Pile is sold: an Edition for a random Joker or deck card, and 5 deck cards die.
local function rock_sale_surprise(card)
    if not prob_roll_n(card, 1, 32, 'cbuf_rock_sell') then return end
    local targets = {}
    for _, j in ipairs(G.jokers.cards) do
        if j ~= card and not j.edition then targets[#targets + 1] = j end
    end
    for _, c in ipairs(G.playing_cards or {}) do
        if not c.edition then targets[#targets + 1] = c end
    end
    local chosen
    if #targets > 0 then
        chosen = pseudorandom_element(targets, pseudoseed('cbuf_rock_target'))
        local ed = type(poll_edition) == 'function' and poll_edition('cbuf_rock_edition', nil, false, true)
        if ed and chosen.set_edition then
            chosen:set_edition(ed, true)
            show_message(chosen, 'Edition!', G.C.DARK_EDITION or G.C.PURPLE)
        end
    end
    -- 5 random cards of the deck are destroyed (never the one that just got the Edition).
    local pool = {}
    for _, c in ipairs(G.playing_cards or {}) do
        if c ~= chosen then pool[#pool + 1] = c end
    end
    local victims = {}
    for _ = 1, math.min(5, #pool) do
        local pick = pseudorandom_element(pool, pseudoseed('cbuf_rock_destroy'))
        for k, c in ipairs(pool) do if c == pick then table.remove(pool, k) break end end
        victims[#victims + 1] = pick
    end
    if #victims > 0 then
        if SMODS and type(SMODS.destroy_cards) == 'function' then
            pcall(SMODS.destroy_cards, victims, true)
        else
            for _, c in ipairs(victims) do
                if c.start_dissolve then c:start_dissolve(nil, true) end
            end
        end
    end
end

SMODS.Joker {
    key = 'pile_of_rocks',
    atlas = 'cbuf_pile_of_rocks',
    pos = { x = 0, y = 0 },
    rarity = 1, -- Common (only created by the Rock Pile tarot)
    cost = 2,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = false,
    config = { extra = { sold = 0, need = 5, round_chips = 0, round_mult = 0 } },
    in_pool = function() return false end,
    loc_txt = {
        name = 'Pile of Rocks',
        text = {
            'Steals {C:chips}20-120{} Chips ({C:green}#1# in #2#{})',
            'and {C:mult}1-21{} Mult ({C:green}#3# in #4#{})',
            '{C:green}#5# in #6#{}: {C:attention}silences{} nearest Joker',
            '{C:green}#7# in #8#{}: pays stolen as {C:money}$${}',
            'Sold: {C:green}#9# in #10#{} {C:dark_edition}Edition{}, destroys 5 cards',
            '{C:inactive}Sell 5 consumables or 1 older Joker first ({C:attention}#11#{C:inactive}/5){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = (card and card.ability and card.ability.extra) or self.config.extra
        local n1, d1 = prob_vars_n(card, 2, 4, 'cbuf_rock_chips')
        local n2, d2 = prob_vars_n(card, 1, 2, 'cbuf_rock_mult')
        local n3, d3 = prob_vars_n(card, 1, 8, 'cbuf_rock_silence')
        local n4, d4 = prob_vars_n(card, 1, 20, 'cbuf_rock_pay')
        local n5, d5 = prob_vars_n(card, 1, 32, 'cbuf_rock_sell')
        return { vars = { n1, d1, n2, d2, n3, d3, n4, d4, n5, d5, ex.sold or 0 } }
    end,
    -- JokerDisplay support: how many of the 5 sales are done.
    joker_display_def = jd('j_cbuf_pile_of_rocks', function(JokerDisplay)
        return {
            text = {
                { ref_table = 'card.joker_display_values', ref_value = 'progress' },
            },
            text_config = { colour = G.C.ORANGE },
            reminder_text = { { text = '(sold)' } },
            calc_function = function(card)
                local ex = card.ability.extra or {}
                card.joker_display_values.progress = (ex.sold or 0) .. '/' .. (ex.need or 5)
            end,
        }
    end),
    calculate = function(self, card, context)
        local ex = card.ability.extra
        if context.blueprint then return end

        -- Every scored hand: steal Chips / Mult, maybe silence the nearest Joker.
        if context.joker_main then
            local ret = {}
            local cur_chips = to_num(rawget(_G, 'hand_chips'))
            local cur_mult = to_num(rawget(_G, 'mult'))
            if prob_roll_n(card, 2, 4, 'cbuf_rock_chips') then
                local amt = pseudorandom('cbuf_rock_chips_amt', 20, 120)
                if cur_chips > 0 then amt = math.min(amt, math.floor(cur_chips)) end
                if amt > 0 then
                    ret.chips = -amt
                    ex.round_chips = ex.round_chips + amt
                end
            end
            if prob_roll_n(card, 1, 2, 'cbuf_rock_mult') then
                local amt = pseudorandom('cbuf_rock_mult_amt', 1, 21)
                if cur_mult > 1 then amt = math.min(amt, math.floor(cur_mult - 1)) end
                if amt > 0 then
                    ret.mult = -amt
                    ex.round_mult = ex.round_mult + amt
                end
            end
            if prob_roll_n(card, 1, 8, 'cbuf_rock_silence') then silence_nearest(card) end
            if next(ret) then return ret end
            return
        end

        -- End of round: 1 in 20 to pay out what it stole this round.
        if context.end_of_round and not context.individual and not context.repetition
            and not context.game_over and G.GAME and ex.last_round ~= G.GAME.round then
            ex.last_round = G.GAME.round
            if (ex.round_chips + ex.round_mult) > 0 and prob_roll_n(card, 1, 20, 'cbuf_rock_pay') then
                local value = math.floor(ex.round_chips / 10) + ex.round_mult
                if value > 0 then
                    ease_dollars(value)
                    show_message(card, '+$' .. value, G.C.MONEY or G.C.GOLD)
                end
            end
            ex.round_chips, ex.round_mult = 0, 0
            return
        end

        -- Sold: the 1 in 32 surprise.
        if context.selling_self then
            rock_sale_surprise(card)
        end
    end,
}

-- Silence only lasts until the end of the round.
tick_rocks = function()
    if not (G and G.jokers) then return end
    for _, j in ipairs(G.jokers.cards) do
        if j.ability and j.ability.cbuf_silenced then
            j.ability.cbuf_silenced = nil
            if j.set_debuff then j:set_debuff(false) end
        end
    end
end

SMODS.Atlas {
    key = 'cbuf_rock_pile',
    path = 'rock_pile.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

-- The rarity one step above a Joker (nil if it is already the top).
local ROCK_RARITY_NUMBER = { Common = 1, Uncommon = 2, Rare = 3, Legendary = 4 }
local function higher_rarity_of(j)
    local r = j and j.config and j.config.center and j.config.center.rarity
    if type(r) == 'string' then r = ROCK_RARITY_NUMBER[r] or 3 end
    r = tonumber(r) or 1
    if r >= 4 then return nil end
    return r + 1
end

local function rock_create_higher(rarity_number, slot_free)
    local spec = {
        set = 'Joker',
        area = G.jokers,
        key_append = 'cbuf_rock_up',
        edition = (not slot_free) and 'e_negative' or nil,
    }
    if rarity_number >= 4 then
        spec.legendary = true
    else
        spec.rarity = (rarity_number == 2) and 'Uncommon' or 'Rare'
    end
    local ok = pcall(SMODS.add_card, spec)
    if not ok and type(create_card) == 'function' then
        pcall(function()
            local c = create_card('Joker', G.jokers, rarity_number >= 4, rarity_number == 2 and 0.8 or 0.96,
                nil, nil, nil, 'cbuf_rock_up')
            if not slot_free and c.set_edition then c:set_edition({ negative = true }, true, true) end
            c:add_to_deck()
            G.jokers:emplace(c)
        end)
    end
end

local function rock_create_pile(slot_free)
    local spec = { set = 'Joker', key = PILE_KEY, area = G.jokers }
    if not slot_free then spec.edition = 'e_negative' end -- no room: the Rocks come Negative
    pcall(SMODS.add_card, spec)
end

local function rock_target_ok(j)
    return j and j.ability and j.ability.set == 'Joker' and not j.ability.eternal
end

SMODS.Consumable {
    key = 'rock_pile',
    set = 'Tarot',
    atlas = 'cbuf_rock_pile',
    pos = { x = 0, y = 0 },
    cost = 3,
    unlocked = true,
    discovered = true,
    config = {},
    loc_txt = {
        name = 'Rock Pile',
        text = {
            '{C:green}#1# in #2#{}: nothing. Else {C:green}#3# in #4#{}:',
            'destroy {C:attention}1{} Joker, create a',
            '{C:attention}higher rarity{} one',
            'Fail: {C:attention}Pile of Rocks{}',
        },
    },
    loc_vars = function(self, info_queue, card)
        if G and G.P_CENTERS and G.P_CENTERS[PILE_KEY] then
            info_queue[#info_queue + 1] = G.P_CENTERS[PILE_KEY]
        end
        local n1, d1 = prob_vars_n(card, 2, 4, 'cbuf_rock_nothing')
        local n2, d2 = prob_vars_n(card, 1, 6, 'cbuf_rock_success')
        return { vars = { n1, d1, n2, d2 } }
    end,
    can_use = function(self, card)
        return G.jokers and #G.jokers.highlighted == 1 and rock_target_ok(G.jokers.highlighted[1]) and true or false
    end,
    use = function(self, card, area, copier)
        local used = copier or card
        local target = G.jokers.highlighted[1]
        G.E_MANAGER:add_event(Event({
            trigger = 'after', delay = 0.4,
            func = function()
                play_sound('tarot1')
                used:juice_up(0.3, 0.5)
                if prob_roll_n(card, 2, 4, 'cbuf_rock_nothing') then
                    show_message(used, 'Nope!', G.C.RED)
                else
                    local higher = higher_rarity_of(target)
                    if higher and rock_target_ok(target) and prob_roll_n(card, 1, 6, 'cbuf_rock_success') then
                        -- Success: the selected Joker is destroyed, a higher-rarity one takes its place.
                        target:start_dissolve({ G.C.RED }, nil, 1.6)
                        G.E_MANAGER:add_event(Event({
                            trigger = 'after', delay = 1.0,
                            func = function()
                                rock_create_higher(higher, #G.jokers.cards < G.jokers.config.card_limit)
                                return true
                            end,
                        }))
                    else
                        rock_create_pile(#G.jokers.cards < G.jokers.config.card_limit)
                    end
                end
                if G.jokers then G.jokers:unhighlight_all() end
                return true
            end,
        }))
        delay(0.5)
    end,
}

-- ===================================================================
-- Mika 7s (Rare) — idea by Mika3.0.
-- Every scored 7 has a 1 in 7 chance to earn the reward ($20 at most).
-- The reward drops $7 after every round with no 7 played, and grows $3
-- after every round in which a 7 was played (never above $20). Cannot be sold.
-- ===================================================================
SMODS.Atlas {
    key = 'cbuf_mika_7s',
    path = 'mika_7s.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

local function mika_roll(card)
    if SMODS and type(SMODS.pseudorandom_probability) == 'function' then
        return SMODS.pseudorandom_probability(card, 'cbuf_mika', 1, 7, 'cbuf_mika') and true or false
    end
    local num = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
    return pseudorandom('cbuf_mika') < num / 7
end

SMODS.Joker {
    key = 'mika_7s',
    atlas = 'cbuf_mika_7s',
    pos = { x = 0, y = 0 },
    rarity = 3, -- Rare
    cost = 8,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = { reward = 20, max = 20, gain = 3, loss = 7, played = false } },
    loc_txt = {
        name = 'Mika 7s',
        text = {
            'Scored {C:attention}7{}: {C:green}#1# in #2#{} to earn {C:money}$#3#{}',
            '{C:red}-$#4#{} per round without a {C:attention}7{}',
            '{C:money}+$#5#{} per round with one (max {C:money}$#6#{})',
            '{C:inactive}Cannot be sold{}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = (card and card.ability and card.ability.extra) or self.config.extra
        local num = (G and G.GAME and G.GAME.probabilities and G.GAME.probabilities.normal) or 1
        return { vars = { num, 7, ex.reward, ex.loss, ex.gain, ex.max } }
    end,
    -- Credit badge under the card.
    set_badges = function(self, card, badges)
        if type(create_badge) == 'function' then
            badges[#badges + 1] = create_badge('Idea: Mika3.0', G.C.CLEAR or { 0, 0, 0, 0 }, G.C.WHITE, 1.0)
        end
    end,
    -- JokerDisplay support.
    joker_display_def = jd('j_cbuf_mika_7s', function(JokerDisplay)
        return {
            text = {
                { text = '$' },
                { ref_table = 'card.joker_display_values', ref_value = 'reward' },
            },
            text_config = { colour = G.C.GOLD },
            reminder_text = {
                { text = '(7s: ' },
                { ref_table = 'card.joker_display_values', ref_value = 'odds' },
                { text = ')' },
            },
            calc_function = function(card)
                local ex = card.ability.extra or {}
                card.joker_display_values.reward = ex.reward or 0
                card.joker_display_values.odds = jd_odds_text(7)
            end,
        }
    end),
    calculate = function(self, card, context)
        local ex = card.ability.extra
        -- A 7 was played this round?
        if context.before and context.full_hand and not context.blueprint then
            for _, c in ipairs(context.full_hand) do
                if c.get_id and c:get_id() == 7 then
                    ex.played = true
                    break
                end
            end
            return
        end
        -- Each scored 7: 1 in 7 chance for the reward.
        if context.individual and context.cardarea == G.play and context.other_card
            and not context.blueprint then
            local c = context.other_card
            if c.get_id and c:get_id() == 7 and ex.reward > 0 and mika_roll(card) then
                return { dollars = ex.reward, card = card }
            end
            return
        end
        -- End of round: adjust the reward.
        if context.end_of_round and not context.individual and not context.repetition
            and not context.blueprint and not context.game_over then
            if ex.played then
                if ex.reward < ex.max then
                    ex.reward = math.min(ex.max, ex.reward + ex.gain)
                    show_message(card, 'Reward $' .. ex.reward, G.C.MONEY or G.C.GOLD)
                end
            else
                if ex.reward > 0 then
                    ex.reward = math.max(0, ex.reward - ex.loss)
                    show_message(card, 'Reward $' .. ex.reward, G.C.RED)
                end
            end
            ex.played = false
        end
    end,
}

-- ===================================================================
-- Royal Balloon Crown (Uncommon) — idea by Alex.
-- Every Royal Flush you play adds +1 retrigger to the FIRST scored Ace.
-- Defeating a Boss Blind removes 1 of those retriggers. Starts at 0, max 5.
-- ===================================================================
SMODS.Atlas {
    key = 'cbuf_royal_balloon_crown',
    path = 'royal_balloon_crown.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

-- Vanilla calls a Straight Flush whose lowest scoring card is a 10 a Royal Flush.
local function is_royal_flush(context)
    if context.scoring_name ~= 'Straight Flush' or not context.scoring_hand then return false end
    local lowest = 99
    for _, c in ipairs(context.scoring_hand) do
        local id = c.get_id and c:get_id() or 0
        if id < lowest then lowest = id end
    end
    return lowest == 10
end

SMODS.Joker {
    key = 'royal_balloon_crown',
    atlas = 'cbuf_royal_balloon_crown',
    pos = { x = 0, y = 0 },
    rarity = 2, -- Uncommon
    cost = 6,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = { retriggers = 0, loss = 1, max = 5 } },
    loc_txt = {
        name = 'Royal Balloon Crown',
        text = {
            '{C:attention}Royal Flush{}: first scored {C:attention}Ace{}',
            'gets {C:attention}+1{} retrigger',
            '{C:red}-#2#{} when a {C:attention}Boss Blind{} is beaten',
            '{C:inactive}(Max {C:attention}#3#{C:inactive}, currently {C:attention}#1#{C:inactive}){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = (card and card.ability and card.ability.extra) or self.config.extra
        return { vars = { ex.retriggers or 0, 1, 5 } }
    end,
    -- Credit badge under the card.
    set_badges = function(self, card, badges)
        if type(create_badge) == 'function' then
            badges[#badges + 1] = create_badge('Idea: Alex', G.C.CLEAR or { 0, 0, 0, 0 }, G.C.WHITE, 1.0)
        end
    end,
    -- JokerDisplay support.
    joker_display_def = jd('j_cbuf_royal_balloon_crown', function(JokerDisplay)
        return {
            -- The first scored Ace is retriggered by the stored amount.
            retrigger_function = function(playing_card, scoring_hand, held_in_hand, joker_card)
                local ok, n = pcall(function()
                    if held_in_hand or not scoring_hand then return 0 end
                    for _, c in ipairs(scoring_hand) do
                        if c.get_id and c:get_id() == 14 then
                            if c ~= playing_card then return 0 end
                            local total = 0
                            for _, j in ipairs(jd_jokers('j_cbuf_royal_balloon_crown', joker_card)) do
                                total = total + (j.ability.extra.retriggers or 0)
                            end
                            return total
                        end
                    end
                    return 0
                end)
                return ok and n or 0
            end,
            text = {
                { text = '+' },
                { ref_table = 'card.joker_display_values', ref_value = 'retriggers' },
            },
            text_config = { colour = G.C.ORANGE },
            reminder_text = { { text = '(first Ace)' } },
            calc_function = function(card)
                local ex = card.ability.extra or {}
                card.joker_display_values.retriggers = ex.retriggers or 0
            end,
        }
    end),
    calculate = function(self, card, context)
        local ex = card.ability.extra
        -- A Royal Flush was played: +1 retrigger (it already helps this hand).
        if context.before and not context.blueprint then
            if is_royal_flush(context) and ex.retriggers < 5 then
                ex.retriggers = math.min(5, ex.retriggers + 1)
                show_message(card, '+1', G.C.ORANGE)
            end
            return
        end
        -- Retrigger the first scored Ace.
        if context.repetition and context.cardarea == G.play and ex.retriggers > 0
            and context.other_card and context.scoring_hand then
            for _, c in ipairs(context.scoring_hand) do
                if c.get_id and c:get_id() == 14 then
                    if c == context.other_card then
                        return { message = localize('k_again_ex'), repetitions = ex.retriggers, card = card }
                    end
                    break -- only the first Ace counts
                end
            end
            return
        end
        -- Boss Blind defeated: -1 retrigger.
        if context.end_of_round and not context.individual and not context.repetition
            and not context.blueprint and not context.game_over
            and G.GAME and G.GAME.blind and G.GAME.blind.boss then
            if ex.retriggers > 0 then
                ex.retriggers = math.max(0, ex.retriggers - 1)
                show_message(card, 'Crown -1', G.C.RED)
            end
        end
    end,
}

-- ===================================================================
-- Enhancement: Blue Ice. Only made by the Joker "Blue Glass Wave" (never random).
--   * X1.75 Mult when scored.
--   * 4 in 5 chance not to break when played; if the roll fails the card shatters.
--   * 4 in 5 chance to retrigger; the roll repeats after each success until it fails or the counter
--     is full (max 2 per round, x/2), reset when the round ends.
-- ===================================================================
local ICE_KEY = 'm_cbuf_blue_ice'
local ICE_XMULT, ICE_NUM, ICE_DEN, ICE_MAX_RETRIGGERS = 1.75, 4, 5, 2

SMODS.Atlas {
    key = 'cbuf_blue_ice',
    path = 'blue_ice.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

SMODS.Enhancement {
    key = 'blue_ice',
    atlas = 'cbuf_blue_ice',
    pos = { x = 0, y = 0 },
    config = { extra = { x_mult = ICE_XMULT, used = 0, max = ICE_MAX_RETRIGGERS } },
    shatters = true,
    -- Never appears at random: Blue Glass Wave is the only source.
    weight = 0,
    in_pool = function(self, args) return false end,
    loc_txt = {
        name = 'Blue Ice',
        text = {
            '{X:mult,C:white}X#1#{} Mult',
            '{C:green}#2#/#3#{} to survive and retrigger',
            '{C:inactive}(#4#/#5#){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = (card and card.ability and type(card.ability.extra) == 'table' and card.ability.extra)
            or self.config.extra
        local n, d = prob_vars_n(card, ICE_NUM, ICE_DEN, 'cbuf_ice_break')
        return { vars = {
            string.format('%.2f', ex.x_mult or ICE_XMULT), n, d, ex.used or 0, ex.max or ICE_MAX_RETRIGGERS,
        } }
    end,
    calculate = function(self, card, context)
        if type(card.ability.extra) ~= 'table' then
            card.ability.extra = { x_mult = ICE_XMULT, used = 0, max = ICE_MAX_RETRIGGERS }
        end
        local ex = card.ability.extra

        -- X Mult every time the card scores (retriggers included).
        if context.main_scoring and context.cardarea == G.play then
            return { x_mult = ex.x_mult or ICE_XMULT }
        end

        -- One extra trigger, limited by the counter.
        if context.repetition and context.cardarea == G.play
            and (context.other_card == nil or context.other_card == card) then
            local reps = 0
            while (ex.used or 0) < (ex.max or ICE_MAX_RETRIGGERS)
                and prob_roll_n(card, ICE_NUM, ICE_DEN, 'cbuf_ice_retrigger') do
                ex.used = (ex.used or 0) + 1
                reps = reps + 1
            end
            if reps > 0 then
                return { message = localize('k_again_ex'), repetitions = reps, card = card }
            end
            return
        end

        -- After scoring: if the "does not break" roll fails, the card shatters.
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card then
            if not prob_roll_n(card, ICE_NUM, ICE_DEN, 'cbuf_ice_break') then
                card.glass_trigger = true
                return { remove = true }
            end
        end
    end,
}

-- End of every round: the (x/2) retrigger counter of every Blue Ice card goes back to 0.
tick_ice = function()
    if not G or not G.playing_cards then return end
    for _, c in ipairs(G.playing_cards) do
        local ex = c.ability and c.ability.extra
        if c.config and c.config.center and c.config.center.key == ICE_KEY
            and type(ex) == 'table' and (ex.used or 0) ~= 0 then
            ex.used = 0
        end
    end
end

-- ===================================================================
-- Enhancement: Black Plastic. A blend of Glass and Steel. Never random.
-- How to get it: put Steel on a card, then Glass on top of it (or Glass, then Steel).
--   * X1.75 Mult when scored (Glass is X2).
--   * X1.5 Mult while held in hand (same as Steel).
--   * 1 in 8 chance to break when played (Glass is 1 in 4).
--   * Counts as both Glass and Steel for Jokers that look for them.
-- Tune the numbers in the line below.
-- ===================================================================
local BP_KEY = 'm_cbuf_black_plastic'
local BP_XMULT_PLAY, BP_XMULT_HELD, BP_BREAK_NUM, BP_BREAK_DEN = 1.75, 1.5, 1, 8

SMODS.Atlas {
    key = 'cbuf_black_plastic',
    path = 'black_plastic.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

SMODS.Enhancement {
    key = 'black_plastic',
    atlas = 'cbuf_black_plastic',
    pos = { x = 0, y = 0 },
    config = { extra = { x_mult = BP_XMULT_PLAY, h_x_mult = BP_XMULT_HELD } },
    shatters = true,
    -- Never appears at random: it only comes from mixing Steel and Glass.
    weight = 0,
    in_pool = function(self, args) return false end,
    loc_txt = {
        name = 'Black Plastic',
        text = {
            '{X:mult,C:white}X#1#{} Mult when scored',
            '{X:mult,C:white}X#2#{} Mult held in hand',
            '{C:green}#3# in #4#{} to break',
            '{C:inactive}(Steel + Glass){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local n, d = prob_vars_n(card, BP_BREAK_NUM, BP_BREAK_DEN, 'cbuf_bp_break')
        return { vars = {
            string.format('%.2f', BP_XMULT_PLAY),
            string.format('%.2f', BP_XMULT_HELD),
            n, d,
        } }
    end,
    calculate = function(self, card, context)
        -- Counts as Glass and Steel (Glass Joker, Steel Joker, ...). Steamodded sends this
        -- context while checking ANY card, so answer only for this Black Plastic card itself;
        -- otherwise every card in hand would suddenly count as Steel and Glass.
        if context.check_enhancement then
            if context.other_card == card then
                return { m_glass = true, m_steel = true }
            end
            return
        end

        -- Scored: Glass side.
        if context.main_scoring and context.cardarea == G.play then
            return { x_mult = BP_XMULT_PLAY }
        end

        -- Held in hand at scoring time: Steel side.
        if context.individual and context.cardarea == G.hand and not context.end_of_round
            and context.other_card == card then
            return { x_mult = BP_XMULT_HELD }
        end

        -- After being played: small chance to shatter.
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card then
            if prob_roll_n(card, BP_BREAK_NUM, BP_BREAK_DEN, 'cbuf_bp_break') then
                card.glass_trigger = true
                return { remove = true }
            end
        end
    end,
}

-- Steel + Glass (either order) -> Black Plastic. Hooks the moment an enhancement is applied
-- (The Chariot / Justice / any mod doing the same), but only on a card that already has the
-- other one, and never while the card is first being created.
do
    local orig_set_ability = Card.set_ability
    function Card:set_ability(center, initial, delay_sprites)
        if not initial and type(center) == 'table' and self.config and self.config.center
            and G and G.P_CENTERS and G.P_CENTERS[BP_KEY] then
            local old, new = self.config.center.key, center.key
            if (old == 'm_steel' and new == 'm_glass') or (old == 'm_glass' and new == 'm_steel') then
                center = G.P_CENTERS[BP_KEY]
            end
        end
        return orig_set_ability(self, center, initial, delay_sprites)
    end
end

-- ===================================================================
-- Joker: Blue Glass Wave (Uncommon).
--   * Gains X0.1 Chips when the first scoring card of the played hand is a 10.
--   * If that hand also contains a Straight, it gains X0.4 Chips instead.
--   * Also gains X0.05 Chips every time a scoring 10 triggers (retriggers included).
--   * Applies its stored X Chips every hand.
--   * When a Glass 10 breaks, a Blue Ice 10 (same suit) is added to your deck,
--     1 in 3 for one extra copy. Every Blue Ice 10 made costs this Joker X0.6 Chips (min X1).
-- ===================================================================
SMODS.Atlas {
    key = 'cbuf_blue_glass_wave',
    path = 'blue_glass_wave.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

local BGW_KEY = 'j_cbuf_blue_glass_wave'
local BGW_COPY_ODDS = 3

-- True when the first scoring card is a 10.
local function bgw_first_is_ten(context)
    local first = context.scoring_hand and context.scoring_hand[1]
    return first ~= nil and first.get_id and first:get_id() == 10
end

-- True when the played hand is (or contains) a Straight.
local function bgw_is_straight(context)
    if context.poker_hands and context.poker_hands['Straight']
        and next(context.poker_hands['Straight']) then
        return true
    end
    return context.scoring_name == 'Straight' or context.scoring_name == 'Straight Flush'
end

-- Was this removed playing card a Glass 10 that shattered?
local function bgw_is_broken_glass_ten(c)
    if not (c and c.get_id and c:get_id() == 10) then return false end
    if not (c.shattered or c.glass_trigger) then return false end
    local center = c.config and c.config.center
    return center ~= nil and center.key == 'm_glass'
end

-- Add one Blue Ice 10 of the given suit to the deck (queued behind the current effects).
local function bgw_make_blue_ice_ten(suit)
    G.E_MANAGER:add_event(Event({
        func = function()
            local ok, err = pcall(function()
                local sk = SMODS and SMODS.Suits and SMODS.Suits[suit] and SMODS.Suits[suit].card_key
                    or tostring(suit):sub(1, 1)
                local front = G.P_CARDS[sk .. '_T'] or G.P_CARDS['S_T']
                local created = create_playing_card({
                    front = front, center = G.P_CENTERS[ICE_KEY],
                }, G.deck, nil, nil, { G.C.SECONDARY_SET.Enhanced })
                if G.deck and G.deck.config and G.playing_cards then
                    G.deck.config.card_limit = math.max(G.deck.config.card_limit or 0, #G.playing_cards)
                end
                if created and type(playing_card_joker_effects) == 'function' then
                    playing_card_joker_effects({ created })
                end
            end)
            if not ok and type(sendWarnMessage) == 'function' then
                pcall(sendWarnMessage, '[CandyBuff] Blue Ice 10 not created: ' .. tostring(err), 'CandyBuff')
            end
            return true
        end,
    }))
end

SMODS.Joker {
    key = 'blue_glass_wave',
    atlas = 'cbuf_blue_glass_wave',
    pos = { x = 0, y = 0 },
    rarity = 2, -- Uncommon
    cost = 6,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    config = { extra = { xchips = 1, gain = 0.1, gain_straight = 0.4, loss = 0.6, gain_ten = 0.05 } },
    loc_txt = {
        name = 'Blue Glass Wave',
        text = {
            'Gains {X:chips,C:white}X#1#{} Chips if first scored card',
            'is a {C:attention}10{} ({X:chips,C:white}X#2#{} if {C:attention}Straight{})',
            'Each scoring {C:attention}10{} triggered: {X:chips,C:white}X#7#{} Chips',
            'Broken {C:attention}Glass 10{} makes {C:attention}Blue Ice 10{}',
            '({C:green}#4# in #5#{} for extra): {X:chips,C:white}-X#6#{} Chips each',
            '{C:inactive}(Currently {X:chips,C:white}X#3#{C:inactive}){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local ex = (card and card.ability and type(card.ability.extra) == 'table' and card.ability.extra)
            or self.config.extra
        local n, d = prob_vars_n(card, 1, BGW_COPY_ODDS, 'cbuf_bgw_copy')
        info_queue[#info_queue + 1] = G.P_CENTERS[ICE_KEY]
        return { vars = {
            string.format('%.1f', ex.gain or 0.1),
            string.format('%.1f', ex.gain_straight or 0.4),
            string.format('%.2f', ex.xchips or 1),
            n, d,
            string.format('%.1f', ex.loss or 0.6),
            string.format('%.2f', ex.gain_ten or 0.05),
        } }
    end,
    -- JokerDisplay support.
    joker_display_def = jd(BGW_KEY, function(JokerDisplay)
        return {
            text = {
                {
                    border_nodes = {
                        { text = 'X' },
                        { ref_table = 'card.joker_display_values', ref_value = 'xchips' },
                    },
                    border_colour = G.C.CHIPS,
                },
            },
            calc_function = function(card)
                local ex = card.ability.extra or {}
                card.joker_display_values.xchips = string.format('%.2f', ex.xchips or 1)
            end,
        }
    end),
    calculate = function(self, card, context)
        local ex = card.ability.extra
        -- Grow before scoring so this hand already benefits.
        if context.before and not context.blueprint then
            if bgw_first_is_ten(context) then
                local gain = bgw_is_straight(context) and (ex.gain_straight or 0.4) or (ex.gain or 0.1)
                ex.xchips = round2((ex.xchips or 1) + gain)
                show_message(card, '+X' .. string.format('%.1f', gain), G.C.CHIPS)
            end
            return
        end
        -- Every time a scoring 10 triggers (retriggers count): +X0.05 Chips.
        if context.individual and context.cardarea == G.play and not context.blueprint
            and context.other_card and not context.other_card.debuff
            and context.other_card.get_id and context.other_card:get_id() == 10 then
            local g = ex.gain_ten or 0.05
            ex.xchips = round2((ex.xchips or 1) + g)
            return { message = '+X' .. string.format('%.2f', g), colour = G.C.CHIPS, card = card }
        end
        -- A Glass 10 broke: it comes back as Blue Ice 10 (maybe two), at a cost of X Chips each.
        if context.remove_playing_cards and context.removed and not context.blueprint then
            local made = 0
            for _, c in ipairs(context.removed) do
                if bgw_is_broken_glass_ten(c) then
                    local suit = c.base and c.base.suit or 'Spades'
                    bgw_make_blue_ice_ten(suit)
                    made = made + 1
                    if prob_roll_n(card, 1, BGW_COPY_ODDS, 'cbuf_bgw_copy') then
                        bgw_make_blue_ice_ten(suit)
                        made = made + 1
                    end
                end
            end
            if made > 0 then
                local loss = (ex.loss or 0.6) * made
                ex.xchips = math.max(1, round2((ex.xchips or 1) - loss))
                show_message(card, 'Blue Ice x' .. made .. '  -X' .. string.format('%.1f', loss), G.C.CHIPS)
            end
            return
        end
        -- Apply the stored X Chips.
        if context.joker_main and (ex.xchips or 1) > 1 then
            return { xchips = ex.xchips }
        end
    end,
}

-- ===================================================================
-- Joker: Freespins in 20s (Uncommon). Idea: 20 freespins na swit.
--   * Every Shop reroll: 1 in 5 that your NEXT reroll is free.
--   * When the reroll that just happened was free: 1 in 4 that the first item in the
--     shop gets a random Edition, and 1 in 8 that this first item becomes free ($0).
--   Odds follow Oops! All 6s and similar (SMODS probability helpers).
-- ===================================================================
SMODS.Atlas {
    key = 'cbuf_freespins20',
    path = 'freespins20.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

local FS_FREE_ODDS, FS_EDITION_ODDS, FS_COUPON_ODDS = 5, 4, 8

SMODS.Joker {
    key = 'freespins20',
    atlas = 'cbuf_freespins20',
    pos = { x = 0, y = 0 },
    rarity = 2, -- Uncommon
    cost = 6,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    config = { extra = {} },
    loc_txt = {
        name = 'Freespins in 20s',
        text = {
            '{C:green}#1# in #2#{} on Reroll: next is {C:attention}free{}',
            'Free Reroll: {C:green}#3# in #4#{} {C:dark_edition}Edition{} on',
            'first item, {C:green}#5# in #6#{} for it {C:attention}free{}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local n1, d1 = prob_vars(card, FS_FREE_ODDS, 'cbuf_fs_free')
        local n2, d2 = prob_vars(card, FS_EDITION_ODDS, 'cbuf_fs_edition')
        local n3, d3 = prob_vars(card, FS_COUPON_ODDS, 'cbuf_fs_coupon')
        return { vars = { n1, d1, n2, d2, n3, d3 } }
    end,
    -- Credit badge under the card.
    set_badges = function(self, card, badges)
        if type(create_badge) == 'function' then
            badges[#badges + 1] = create_badge('Idea: 20 freespins na swit', G.C.CLEAR or { 0, 0, 0, 0 }, G.C.WHITE, 1.0)
        end
    end,
    calculate = function(self, card, context)
        if not context.reroll_shop or context.blueprint then return end
        if not (G and G.GAME and G.GAME.current_round) then return end

        -- This reroll was free (cost 0): maybe Edition / free price on the first shop item.
        if (to_num(context.cost) or 0) <= 0 then
            local first = G.shop_jokers and G.shop_jokers.cards and G.shop_jokers.cards[1]
            if first then
                if prob_roll(card, FS_EDITION_ODDS, 'cbuf_fs_edition') and not first.edition
                    and type(poll_edition) == 'function' and first.set_edition then
                    local ed = poll_edition('cbuf_fs_edition_poll', nil, false, true)
                    if ed then
                        first:set_edition(ed, true)
                        show_message(card, 'Edition!', G.C.DARK_EDITION or G.C.PURPLE)
                    end
                end
                if prob_roll(card, FS_COUPON_ODDS, 'cbuf_fs_coupon') and first.ability
                    and not first.ability.couponed then
                    first.ability.couponed = true
                    if first.set_cost then first:set_cost() end
                    show_message(card, 'Free!', G.C.MONEY or G.C.GOLD)
                end
            end
        end

        -- Maybe make the next reroll free.
        if prob_roll(card, FS_FREE_ODDS, 'cbuf_fs_free') then
            G.GAME.current_round.free_rerolls = (G.GAME.current_round.free_rerolls or 0) + 1
            if type(calculate_reroll_cost) == 'function' then calculate_reroll_cost(true) end
            show_message(card, 'Free Reroll!', G.C.GREEN)
        end
    end,
}

-- ===================================================================
-- Voucher: Sweet Tooth
-- ===================================================================
SMODS.Atlas {
    key = 'cbuf_voucher',
    path = 'sweet_tooth.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

SMODS.Voucher {
    key = 'sweet_tooth',
    atlas = 'cbuf_voucher',
    pos = { x = 0, y = 0 },
    cost = 10,
    unlocked = true,
    discovered = true,
    loc_txt = {
        name = 'Sweet Tooth',
        text = {
            'Food Jokers appear {C:attention}2X{} often',
            '{C:money}$1{} per Food Joker at round end',
        },
    },
}

tick_sweet_tooth = function()
    if not (sweet_tooth_active() and G.GAME and G.jokers) then return end
    if G.GAME.cbuf_sweet_round == G.GAME.round then return end
    G.GAME.cbuf_sweet_round = G.GAME.round
    local n = count_food_jokers()
    if n > 0 then
        ease_dollars(n)
        for _, c in ipairs(G.jokers.cards) do
            if is_food_joker(c) then
                show_message(c, '+$' .. n, G.C.MONEY or G.C.GOLD)
                break
            end
        end
    end
end

-- ===================================================================
-- Starting Licker (shared by the Candy Sleeve and the Candy Deck)
-- ===================================================================
local function give_starting_licker()
    if not MOD_CONFIG.licker_start then return end
    G.E_MANAGER:add_event(Event({
        func = function()
            if not (G.jokers and G.GAME) then return false end
            if not G.GAME.cbuf_licker_given then
                G.GAME.cbuf_licker_given = true
                -- Rental (not Negative): costs $ each round, takes a Joker slot.
                local licker = SMODS.add_card({ set = 'Joker', key = LICKER_KEY })
                if licker then
                    if type(licker.set_rental) == 'function' then
                        licker:set_rental(true)
                    elseif licker.ability then
                        licker.ability.rental = true
                        if licker.set_cost then licker:set_cost() end
                    end
                end
            end
            return true
        end,
    }))
end

local function candy_loc_vars()
    return { vars = {
        get_spawn_multiplier(),
        get_decay_percent(),
        MOD_CONFIG.licker_start and 'Rental The Licker' or 'nothing extra',
    } }
end

-- ===================================================================
-- Candy Deck: standalone alternative that needs no CardSleeves.
-- ===================================================================
SMODS.Atlas {
    key = 'cbuf_candy_deck',
    path = 'candy_deck.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

SMODS.Back {
    key = 'candy_deck',
    name = 'Candy Deck',
    atlas = 'cbuf_candy_deck',
    pos = { x = 0, y = 0 },
    unlocked = true,
    discovered = true,
    config = {},
    loc_txt = {
        name = 'Candy Deck',
        text = {
            'Food Jokers {C:attention}#1#X{} more common',
            'Decay {C:attention}-#2#%{}',
            'Start with {C:attention}#3#{}',
        },
    },
    loc_vars = function(self, info_queue, back)
        return candy_loc_vars()
    end,
    apply = function(self, back)
        give_starting_licker()
    end,
}

-- ===================================================================
-- Rock Deck: starts with two Rock Pile tarots, and 10-30% of the deck (random) starts as Stone cards.
-- ===================================================================
SMODS.Atlas {
    key = 'cbuf_rock_deck',
    path = 'rock_deck.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

SMODS.Back {
    key = 'rock_deck',
    name = 'Rock Deck',
    atlas = 'cbuf_rock_deck',
    pos = { x = 0, y = 0 },
    unlocked = true,
    discovered = true,
    config = {},
    loc_txt = {
        name = 'Rock Deck',
        text = {
            'Start with two {C:tarot}Rock Piles{}',
            '{C:attention}10-30%{} of the deck are',
            'random {C:attention}Stone{} cards',
        },
    },
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                if not (G.consumeables and G.GAME) then return false end
                if not G.GAME.cbuf_rock_given then
                    G.GAME.cbuf_rock_given = true
                    for _ = 1, 2 do
                        pcall(SMODS.add_card, { set = 'Tarot', key = 'c_cbuf_rock_pile', area = G.consumeables })
                    end
                end
                return true
            end,
        }))
        -- A random 10-30% of the deck turns into Stone cards (once per run).
        G.E_MANAGER:add_event(Event({
            func = function()
                if not (G.playing_cards and #G.playing_cards > 0 and G.GAME) then return false end
                if G.GAME.cbuf_rock_stoned then return true end
                G.GAME.cbuf_rock_stoned = true
                pcall(function()
                    local stone = G.P_CENTERS and G.P_CENTERS.m_stone
                    if not stone then return end
                    local pool = {}
                    for _, c in ipairs(G.playing_cards) do pool[#pool + 1] = c end
                    local frac = 0.10 + 0.20 * pseudorandom('cbuf_rock_frac')
                    local n = math.max(1, math.floor(#pool * frac + 0.5))
                    pseudoshuffle(pool, pseudoseed('cbuf_rock_stone'))
                    for i = 1, math.min(n, #pool) do pool[i]:set_ability(stone, nil, true) end
                end)
                return true
            end,
        }))
    end,
}

-- Spade Deck: Hearts and Diamonds start as Spades, and every played card that is not a
-- Spade is destroyed after it is played (Wild cards count as Spades).
-- ===================================================================
SMODS.Atlas {
    key = 'cbuf_critical_deck',
    path = 'critical_deck.png',
    px = 71,
    py = 95,
    disable_mipmap = true,
}

SMODS.Back {
    key = 'spade_deck',
    name = 'Spade Deck',
    atlas = 'cbuf_critical_deck',
    pos = { x = 0, y = 0 },
    unlocked = true,
    discovered = true,
    config = {},
    loc_txt = {
        name = 'Spade Deck',
        text = {
            '{C:hearts}Hearts{} and {C:diamonds}Diamonds{} become {C:spades}Spades{}',
            'Non-{C:spades}Spade{} cards are',
            '{C:red}destroyed{} after play',
        },
    },
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                if not (G.playing_cards and G.GAME) then return false end
                if not G.GAME.cbuf_spade_deck_done then
                    G.GAME.cbuf_spade_deck_done = true
                    for _, c in ipairs(G.playing_cards) do
                        local suit = c.base and c.base.suit
                        if suit == 'Hearts' or suit == 'Diamonds' then
                            if SMODS and type(SMODS.change_base) == 'function' then
                                SMODS.change_base(c, 'Spades')
                            elseif c.change_suit then
                                c:change_suit('Spades')
                            end
                        end
                    end
                end
                return true
            end,
        }))
    end,
    calculate = function(self, back, context)
        if context.destroy_card and context.cardarea == G.play then
            local c = context.destroy_card
            local is_spade = c and c.is_suit and c:is_suit('Spades', true)
            if c and not is_spade then
                return { remove = true }
            end
        end
    end,
}

-- ===================================================================
-- Candy Sleeve: only registered when CardSleeves is installed (optional).
-- ===================================================================
if rawget(_G, 'CardSleeves') and CardSleeves.Sleeve then
    CardSleeves.Sleeve {
        key = 'candy',
        name = 'Candy Sleeve',
        atlas = 'cbuf_candy',
        pos = { x = 0, y = 0 },
        unlocked = true,
        loc_txt = {
            name = 'Candy Sleeve',
            text = {
                'Food Jokers {C:attention}#1#X{} more common',
                'Decay {C:attention}-#2#%{}',
                'Start with {C:attention}#3#{}',
            },
        },
        loc_vars = function(self)
            return candy_loc_vars()
        end,
        apply = function(self, sleeve)
            give_starting_licker()
        end,
    }
end

-- ===================================================================
-- JokerDisplay fallback: if JokerDisplay is installed but did not pick up a definition
-- from `joker_display_def`, register ours directly (never overwrites an existing one).
-- Safe when JokerDisplay is not installed: nothing happens.
-- ===================================================================
local function cbuf_register_jokerdisplay()
    local JD = rawget(_G, 'JokerDisplay')
    if type(JD) ~= 'table' or type(JD.Definitions) ~= 'table' then return end
    for key, fn in pairs(JD_DEFS) do
        if JD.Definitions[key] == nil then
            local ok, def = pcall(fn, JD)
            if ok and type(def) == 'table' then JD.Definitions[key] = def end
        end
    end
end

cbuf_register_jokerdisplay()
if Game and type(Game.start_run) == 'function' and not Game._cbuf_jd_wrapped then
    local original_start_run = Game.start_run
    function Game:start_run(...)
        pcall(cbuf_register_jokerdisplay)
        return original_start_run(self, ...)
    end
    Game._cbuf_jd_wrapped = true
end
