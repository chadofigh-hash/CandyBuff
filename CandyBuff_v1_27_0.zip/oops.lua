-- Candy Buff — Oops! All 6s: Perishable + Rare (v1.26.68)
--
--   * Oops! All 6s always comes with the Perishable sticker (debuffed after 5 rounds, like vanilla).
--   * It also carries the new "Rare" sticker. Rare Jokers show up 25% less often EVERYWHERE:
--     shop, Buffoon / Joker of Luck packs, Judgement, The Soul-type creators, Riff-Raff, and so on.
--     (Every one of them picks its Joker through get_current_pool, so we hook that one function.)
--
-- Want another card to be Rare too? Add its key to RARE below, e.g.  j_blueprint = 0.25.
-- Safety: all hooks are inside pcall; failures go to the Lovely log (search "CandyBuff oops").

local function log(level, msg)
    local fn = (level == 'error' and sendErrorMessage) or (level == 'warn' and sendWarnMessage) or sendInfoMessage
    if type(fn) == 'function' then pcall(fn, '[CandyBuff] oops: ' .. msg, 'CandyBuff') end
end

-- center key -> how much LESS often it appears (0.25 = a quarter less)
local RARE = {
    j_oops = 0.25,
}

_G.CBUF_RARE = RARE   -- luck_pack.lua reads this too (its packs don't use get_current_pool)

SMODS.Atlas { key = 'cbuf_rare', path = 'cbuf_rare.png', px = 71, py = 95, disable_mipmap = true }

SMODS.Sticker {
    key = 'rare',
    atlas = 'cbuf_rare',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('E0A92E'),
    rate = 0,
    needs_enable_flag = false,
    default_compat = true,
    sets = { Joker = true },
    loc_txt = {
        name = 'Rare',
        label = 'Rare',
        text = {
            'Appears {C:attention}25%{} less often',
            'in shops, packs and Tarots',
        },
    },
}

-- Appearance: every pool pick goes through get_current_pool ------------------------------
-- For each Rare key in the pool we flip a coin weighted by RARE[key]; on "removed" the entry becomes
-- 'UNAVAILABLE' (the game already skips those), so that pick can't land on it. Net effect: the card is
-- chosen about 25% less often than before.
if type(get_current_pool) == 'function' and not _G._cbuf_rare_pool_hooked then
    _G._cbuf_rare_pool_hooked = true
    local ref = get_current_pool
    function get_current_pool(...)
        local pool, pool_key = ref(...)
        pcall(function()
            if type(pool) ~= 'table' then return end
            for i, key in ipairs(pool) do
                local cut = RARE[key]
                if cut and pseudorandom('cbuf_rare' .. key .. i .. tostring(pool_key)) < cut then
                    pool[i] = 'UNAVAILABLE'
                end
            end
        end)
        return pool, pool_key
    end
else
    log('warn', 'get_current_pool not found: Oops! All 6s will not be rarer')
end

-- Stickers: Rare + Perishable on Oops! All 6s, in EVERY deck ------------------------------------
-- Not tied to any deck. ensure() is safe to call any number of times: each sticker is added once per card
-- (flags in card.ability, which is saved with the run) and it is called from every place such a card can
-- appear: when it is made (shop, packs, Tarots, Judgement ...), when it is bought / added to your Jokers,
-- when a saved run is loaded, and when a run starts (cards already in the shop / in your Jokers).
local function put_sticker(card, key)
    local st = SMODS.Stickers and SMODS.Stickers[key]
    if st and type(st.apply) == 'function' then
        st:apply(card, true)
    else
        card.ability[key] = true
    end
end

local function ensure(card)
    local ab = card and card.ability
    local center = card and card.config and card.config.center
    if not (ab and center and RARE[center.key] and ab.set == 'Joker') then return end
    if not ab.cbuf_rare_done then
        ab.cbuf_rare_done = true
        put_sticker(card, 'cbuf_rare')
    end
    if center.key == 'j_oops' and not ab.cbuf_oops_perish_done then
        ab.cbuf_oops_perish_done = true
        if not ab.perishable then
            put_sticker(card, 'perishable')
            ab.perishable = true                                  -- in case the sticker object is missing
            ab.perish_tally = ab.perish_tally or (G and G.GAME and G.GAME.perishable_rounds) or 5
        end
    end
end

local function safe_ensure(card)
    local ok, err = pcall(ensure, card)
    if not ok then log('warn', 'could not add stickers: ' .. tostring(err)) end
end

local function hook(cls, name, after)
    if cls and type(cls[name]) == 'function' and not cls['_cbuf_oops_' .. name] then
        cls['_cbuf_oops_' .. name] = true
        local ref = cls[name]
        cls[name] = function(self, ...)
            local r1, r2 = ref(self, ...)
            after(self)
            return r1, r2
        end
    end
end

hook(Card, 'set_ability', safe_ensure)      -- made: shop, packs, Tarots, Judgement ...
hook(Card, 'add_to_deck', safe_ensure)      -- bought / taken into your Jokers
hook(Card, 'load', safe_ensure)             -- saved run loaded

-- a run starts / a run is continued: fix cards that are already around
if Game and type(Game.start_run) == 'function' and not Game._cbuf_oops_run_hooked then
    Game._cbuf_oops_run_hooked = true
    local ref = Game.start_run
    function Game:start_run(...)
        local r = ref(self, ...)
        pcall(function()
            for _, area in ipairs({ G.jokers, G.shop_jokers, G.pack_cards }) do
                if area and area.cards then
                    for _, c in ipairs(area.cards) do safe_ensure(c) end
                end
            end
        end)
        return r
    end
end

log('info', 'loaded')
